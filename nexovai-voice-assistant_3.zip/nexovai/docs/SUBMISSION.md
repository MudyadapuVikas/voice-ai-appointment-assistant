# Submission notes

Form: https://docs.google.com/forms/d/e/1FAIpQLSdruhcgKFC4LjnlwHfYDRZoGsa0r-qy4k68SJ8RsmxsPbYxpg/viewform

## Before recording

- [ ] `.env` has both keys; `GET http://localhost:7860/api/health` shows `"voice_enabled": true`
- [ ] Reset demo data (sidebar) so the board is clean
- [ ] Headphones on, Chrome, mic allowed
- [ ] One test call done end to end

## Video script (≈ 2½ minutes)

1. **0:00** Dashboard overview: stats, today's schedule, activity. One sentence on the stack.
2. **0:15** Doctors page: pick Friday so the open slots are visible.
3. **0:25** Click **Try call**: ringing, then connected; Mira greets you.
4. **0:35** "I'd like to see a cardiologist on Friday." "Checking the schedule…" appears and she offers 2–3 times.
5. **0:55** Pick a time and give your name.
6. **1:05** Say your number. She reads it back; say **"no"** once and correct it, which shows the confirmation rule. Then say yes.
7. **1:30** Confirmation card in the phone; toast and highlighted row on the dashboard.
8. **1:45** (optional) "Actually, cancel that appointment." Number confirmed, booking confirmed, cancelled.
9. **2:10** End call. Show Appointments and Activity updated.

## Pipeline description (rewrite in your own words before submitting)

> The browser streams mic audio to a FastAPI backend over WebRTC using Pipecat's SmallWebRTC transport. Each call runs its own Pipecat pipeline: Silero VAD handles turn-taking, ElevenLabs Scribe turns speech into text, Gemini decides what to say or which tool to call, and ElevenLabs Flash speaks the reply. There are three tools: check availability, book, and cancel. They call the same service layer as the dashboard, backed by SQLite. The caller is identified only by the number they say. Booking and cancelling are refused until the agent has read the number back and the caller has confirmed it, and a unique index blocks double booking. Every change publishes an event that the dashboard receives over Server-Sent Events, so it updates while the call is still going on.
