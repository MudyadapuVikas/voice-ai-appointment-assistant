import pytest

from app.services import appointments, availability
from app.services.errors import AppointmentError
from app.services.phone import normalize_phone

MONDAY, TUESDAY, WEDNESDAY = "2026-11-23", "2026-11-24", "2026-11-25"
CALLER = "98480 12345"


def book(**overrides):
    args = dict(
        patient_name="Srinithya", phone_number=CALLER, phone_confirmed=True,
        doctor_id="D2", date=TUESDAY, time="10:30",
    )
    args.update(overrides)
    return appointments.book(**args)


# ---------------------------------------------------------------- phone numbers


@pytest.mark.parametrize(
    "spoken, expected",
    [
        ("98480 12345", "9848012345"),
        ("+91 98480-12345", "9848012345"),
        ("09848012345", "9848012345"),
        ("nine eight four eight zero one two three four five", "9848012345"),
        ("double nine eight seven six five four three two one", "9987654321"),
        ("98480 1234", None),          # too short
        ("12345 67890", None),         # not a mobile number
        ("my number is", None),
        ("", None),
    ],
)
def test_normalize_phone(spoken, expected):
    assert normalize_phone(spoken) == expected


# ---------------------------------------------------------------- availability


def test_find_cardiologists_by_spoken_specialty(conn):
    found = availability.find_doctors(conn, specialty="cardiologists")
    assert {d["name"] for d in found} == {"Dr. Vikram Mehta", "Dr. Priya Nair"}


def test_find_doctor_by_partial_name(conn):
    assert [d["id"] for d in availability.find_doctors(conn, doctor="Dr. Mehta")] == ["D2"]


def test_availability_only_returns_real_free_slots(conn):
    result = availability.check_availability(conn, specialty="cardiology", day=TUESDAY)
    mehta = next(d for d in result["doctors"] if d["doctor_id"] == "D2")
    slots = mehta["availability"][0]["free_slots"]
    assert slots[0] == "10:00" and "13:30" in slots
    seeded = conn.execute("SELECT time FROM appointments WHERE doctor_id='D2' AND date=?", (TUESDAY,)).fetchall()
    assert all(r["time"] not in slots for r in seeded)


def test_no_slots_when_doctor_is_off_and_next_day_is_suggested(conn):
    # Dr. Priya Nair (D3) works Tue/Thu/Sat only
    result = availability.check_availability(conn, doctor="Nair", day=MONDAY)
    nair = result["doctors"][0]
    assert result["any_free"] is False
    assert nair["works_that_day"] is False
    assert nair["next_available"]["date"] == TUESDAY


def test_unknown_specialty(conn):
    with pytest.raises(AppointmentError) as e:
        availability.check_availability(conn, specialty="neurosurgery")
    assert e.value.code == "no_matching_doctor"
    assert "Cardiology" in e.value.details["specialties"]


@pytest.mark.parametrize("bad", ["next blursday", "2026-13-40", "2026-11-01", "2026-12-25"])
def test_invalid_or_out_of_range_dates(conn, bad):
    with pytest.raises(AppointmentError):
        availability.check_availability(conn, specialty="cardiology", day=bad)


# ---------------------------------------------------------------- booking


def test_booking_happy_path():
    appt = book()
    assert appt["status"] == "booked"
    assert appt["phone"] == "9848012345"
    assert appt["doctor_name"] == "Dr. Vikram Mehta"
    assert (appt["date"], appt["time"]) == (TUESDAY, "10:30")


def test_booking_refused_until_phone_confirmed():
    with pytest.raises(AppointmentError) as e:
        book(phone_confirmed=False)
    assert e.value.code == "phone_not_confirmed"
    assert e.value.details["phone_to_read_back"] == "98480 12345"


def test_booking_refuses_invalid_phone():
    with pytest.raises(AppointmentError) as e:
        book(phone_number="1234")
    assert e.value.code == "invalid_phone"


def test_double_booking_is_prevented():
    book()
    with pytest.raises(AppointmentError) as e:
        book(patient_name="Someone Else", phone_number="9000000001")
    assert e.value.code == "slot_unavailable"
    assert "10:30" not in e.value.details["free_slots_that_day"]


def test_booking_outside_working_hours():
    with pytest.raises(AppointmentError) as e:
        book(time="18:00")
    assert e.value.code == "slot_unavailable"


def test_booking_requires_name():
    with pytest.raises(AppointmentError) as e:
        book(patient_name=" ")
    assert e.value.code == "missing_name"


def test_booking_unknown_doctor():
    with pytest.raises(AppointmentError) as e:
        book(doctor_id="D99")
    assert e.value.code == "unknown_doctor"


def test_booking_accepts_12h_time():
    assert book(time="1:30 PM")["time"] == "13:30"


# ---------------------------------------------------------------- cancelling


def test_cancel_is_two_step():
    appt = book()
    first = appointments.cancel(phone_number=CALLER, phone_confirmed=True)
    assert first["needs_confirmation"] is True and first["cancelled"] is None
    assert [a["id"] for a in first["appointments"]] == [appt["id"]]

    second = appointments.cancel(phone_number=CALLER, phone_confirmed=True, appointment_id=appt["id"], cancel_confirmed=True)
    assert second["cancelled"]["status"] == "cancelled"


def test_cancelled_slot_becomes_free_again(conn):
    appt = book()
    appointments.cancel(phone_number=CALLER, phone_confirmed=True, appointment_id=appt["id"], cancel_confirmed=True)
    assert "10:30" in availability.free_slots(conn, "D2", availability.parse_date(TUESDAY))
    book(patient_name="Next Patient", phone_number="9000000002")  # re-bookable


def test_cancel_refused_until_phone_confirmed():
    book()
    with pytest.raises(AppointmentError) as e:
        appointments.cancel(phone_number=CALLER, phone_confirmed=False)
    assert e.value.code == "phone_not_confirmed"


def test_cancel_with_no_appointments():
    with pytest.raises(AppointmentError) as e:
        appointments.cancel(phone_number="9000000003", phone_confirmed=True)
    assert e.value.code == "no_appointments"


def test_cannot_cancel_someone_elses_appointment():
    mine = book()
    other = book(patient_name="Other Caller", phone_number="9000000004", time="12:00")
    other_id = other["id"]
    assert other_id != mine["id"]
    with pytest.raises(AppointmentError) as e:
        appointments.cancel(phone_number=CALLER, phone_confirmed=True, appointment_id=other_id, cancel_confirmed=True)
    assert e.value.code == "unknown_appointment"


def test_activity_log_records_both_events(conn):
    appt = book()
    appointments.cancel(phone_number=CALLER, phone_confirmed=True, appointment_id=appt["id"], cancel_confirmed=True)
    kinds = [a["kind"] for a in appointments.activity(conn)[:2]]
    assert kinds == ["cancelled", "booked"]


def test_stats(conn):
    before = appointments.stats(conn)
    book()
    after = appointments.stats(conn)
    assert after["total"] == before["total"] + 1
    assert after["doctors_today"] >= 1
