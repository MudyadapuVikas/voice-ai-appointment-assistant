from fastapi.testclient import TestClient

from app.main import app

TUESDAY = "2026-11-24"


def client() -> TestClient:
    return TestClient(app)


def test_health_reports_voice_credentials():
    with client() as c:
        body = c.get("/api/health").json()
    assert body["ok"] is True
    assert isinstance(body["voice_enabled"], bool)
    assert isinstance(body["missing_credentials"], list)


def test_dashboard_endpoints():
    with client() as c:
        assert len(c.get("/api/schedule").json()["doctors"]) == 7
        assert len(c.get("/api/appointments").json()) >= 5
        overview = c.get("/api/overview").json()
        assert {"total", "today", "cancelled", "doctors_today"} <= overview["stats"].keys()


def test_demo_booking_and_cancel_roundtrip():
    with client() as c:
        r = c.post("/api/appointments", json={
            "patient_name": "Demo Patient", "phone_number": "98480 12345",
            "doctor_id": "D2", "date": TUESDAY, "time": "10:30",
        })
        assert r.status_code == 201, r.text
        appt = r.json()

        dup = c.post("/api/appointments", json={
            "patient_name": "Other", "phone_number": "9000000009",
            "doctor_id": "D2", "date": TUESDAY, "time": "10:30",
        })
        assert dup.status_code == 409 and dup.json()["error"] == "slot_unavailable"

        lookup = c.post("/api/appointments/cancel", json={"phone_number": "9848012345"}).json()
        assert lookup["needs_confirmation"]

        done = c.post("/api/appointments/cancel", json={
            "phone_number": "9848012345", "appointment_id": appt["id"], "confirm": True,
        }).json()
        assert done["cancelled"]["status"] == "cancelled"

        feed = c.get("/api/activity").json()
        assert feed[0]["kind"] == "cancelled" and feed[0]["source"] == "dashboard"


def test_invalid_requests():
    with client() as c:
        assert c.post("/api/appointments", json={"patient_name": "A"}).status_code == 422
        bad_phone = c.post("/api/appointments", json={
            "patient_name": "A B", "phone_number": "123", "doctor_id": "D2", "date": TUESDAY, "time": "10:30",
        })
        assert bad_phone.status_code == 422 and bad_phone.json()["error"] == "invalid_phone"
        assert c.get("/api/availability", params={"specialty": "astrology"}).status_code == 404


def test_offer_refused_without_credentials(monkeypatch):
    import dataclasses

    from app.api import webrtc
    from app.config import settings

    monkeypatch.setattr(webrtc, "settings", dataclasses.replace(settings, elevenlabs_api_key="", google_api_key=""))
    with client() as c:
        r = c.post("/api/offer", json={"sdp": "x", "type": "offer"})
    assert r.status_code == 503
    assert "ELEVENLABS_API_KEY" in r.json()["detail"]
