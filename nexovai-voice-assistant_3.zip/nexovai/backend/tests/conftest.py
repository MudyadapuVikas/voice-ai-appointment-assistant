"""Every test gets a fresh SQLite file and a frozen clock (Monday 23 Nov 2026, 08:00 IST)."""

import dataclasses
from datetime import datetime

import pytest

from app import config
from app.database import db
from app.services import appointments, availability

FROZEN = datetime(2026, 11, 23, 8, 0, tzinfo=config.settings.tz)  # a Monday


@pytest.fixture(autouse=True)
def fresh_db(tmp_path, monkeypatch):
    test_settings = dataclasses.replace(config.settings, db_path=str(tmp_path / "test.db"))
    monkeypatch.setattr(db, "settings", test_settings)
    for module in (db, availability, appointments):
        monkeypatch.setattr(module, "now", lambda: FROZEN)
    monkeypatch.setattr(db, "DEMO_FILL", ())  # tests see only the fixed seed bookings
    db.init_db(reset=True)
    yield


@pytest.fixture
def conn():
    with db.get_conn() as c:
        yield c


class FakeParams:
    """Stands in for Pipecat's FunctionCallParams: captures what the tool returns to the LLM."""

    def __init__(self):
        self.result = None

    async def result_callback(self, result, **_):
        self.result = result


@pytest.fixture
def params():
    return FakeParams()
