"""The voice tools, driven the way Gemini drives them during a call.

These don't call Gemini or ElevenLabs: they replay the function calls the LLM
makes in each scenario and check what the tool hands back to it, plus the
event the dashboard receives.
"""

import asyncio

from app.services.events import bus
from app.tools.appointment_tools import book_appointment, cancel_appointment, check_doctor_availability
from tests.conftest import FakeParams

TUESDAY = "2026-11-24"


def call(tool, **kwargs) -> dict:
    params = FakeParams()
    asyncio.run(tool(params, **kwargs))
    return params.result


def test_full_booking_call_updates_dashboard():
    async def scenario():
        bus.bind(asyncio.get_running_loop())
        events = bus.subscribe()
        p = FakeParams()

        # 1-3. "Any cardiologists on Tuesday?" -> real slots
        await check_doctor_availability(p, specialty="cardiologist", date=TUESDAY)
        assert p.result["ok"] and p.result["any_free"]
        mehta = next(d for d in p.result["doctors"] if d["doctor_id"] == "D2")
        slot = mehta["availability"][0]["free_slots"][1]

        # 4-5. caller says a number; agent tries to book before reading it back -> refused
        await book_appointment(p, patient_name="Srinithya", phone_number="nine eight four eight zero one two three four five",
                               phone_confirmed=False, doctor_id="D2", date=TUESDAY, time=slot)
        assert p.result["error"] == "phone_not_confirmed"
        assert p.result["phone_to_read_back"] == "98480 12345"

        # 6-7. caller confirms -> booked
        await book_appointment(p, patient_name="Srinithya", phone_number="98480 12345",
                               phone_confirmed=True, doctor_id="D2", date=TUESDAY, time=slot)
        assert p.result["ok"] and p.result["appointment"]["time"] == slot

        # 8. dashboard gets the live event
        message = await asyncio.wait_for(events.get(), timeout=2)
        assert '"appointment.booked"' in message and "Srinithya" in message
        bus.unsubscribe(events)

    asyncio.run(scenario())


def test_wrong_number_then_corrected():
    # caller said a wrong number, agent read it back, caller said "no": agent asks again.
    # Only the corrected number is ever sent with phone_confirmed=True.
    first = call(book_appointment, patient_name="Asha", phone_number="98480 12354", phone_confirmed=False,
                 doctor_id="D2", date=TUESDAY, time="12:30")
    assert first["error"] == "phone_not_confirmed"
    booked = call(book_appointment, patient_name="Asha", phone_number="98480 12345", phone_confirmed=True,
                  doctor_id="D2", date=TUESDAY, time="12:30")
    assert booked["appointment"]["phone"] == "9848012345"


def test_double_booking_through_voice():
    args = dict(patient_name="Anil Kumar", phone_number="9000000001", phone_confirmed=True, doctor_id="D2", date=TUESDAY, time="12:00")
    assert call(book_appointment, **args)["ok"]
    again = call(book_appointment, **{**args, "patient_name": "Bina Roy", "phone_number": "9000000002"})
    assert again["ok"] is False and again["error"] == "slot_unavailable"
    assert "12:00" not in again["free_slots_that_day"]


def test_no_available_slots_suggests_next_day():
    result = call(check_doctor_availability, doctor="Priya Nair", date="2026-11-23")  # she doesn't work Mondays
    assert result["any_free"] is False
    assert result["doctors"][0]["next_available"]["date"] == TUESDAY


def test_cancel_with_confirmed_phone():
    call(book_appointment, patient_name="Ravi", phone_number="9812300000", phone_confirmed=True,
         doctor_id="D2", date=TUESDAY, time="13:00")
    lookup = call(cancel_appointment, phone_number="98123 00000", phone_confirmed=True)
    assert lookup["needs_confirmation"] and len(lookup["appointments"]) == 1
    done = call(cancel_appointment, phone_number="98123 00000", phone_confirmed=True,
                appointment_id=lookup["appointments"][0]["id"], cancel_confirmed=True)
    assert done["cancelled"]["status"] == "cancelled"


def test_cancel_unknown_appointment():
    result = call(cancel_appointment, phone_number="9777777777", phone_confirmed=True)
    assert result["ok"] is False and result["error"] == "no_appointments"


def test_invalid_input_is_reported_not_raised():
    assert call(check_doctor_availability, specialty="astrology")["error"] == "no_matching_doctor"
    assert call(check_doctor_availability, specialty="cardiology", date="someday")["error"] == "invalid_date"
    assert call(book_appointment, patient_name="X Y", phone_number="12", phone_confirmed=True,
                doctor_id="D2", date=TUESDAY, time="10:00")["error"] == "invalid_phone"
    assert call(book_appointment, patient_name="X Y", phone_number="9000000005", phone_confirmed=True,
                doctor_id="D2", date=TUESDAY, time="lunchtime")["error"] == "invalid_time"
