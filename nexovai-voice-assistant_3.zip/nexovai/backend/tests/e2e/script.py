"""The caller's side of the end-to-end test call, in order.

The browser test speaks each line into the (synthetic) microphone with
espeak-ng; the STT emulator returns the same line as the transcript once it
has received that utterance's audio.
"""

# Written without full stops inside a line: espeak-ng pauses long enough at a
# full stop for the VAD to split the line in two.
CALLER_TURNS = [
    "Hi I would like to see a cardiologist on Friday",
    "Doctor Mehta at the second time please",
    "My name is Srinithya Saindla",
    "It is 98480 12354",                  # wrong on purpose: last two digits swapped
    "No that is wrong it is 98480 12345",
    "Yes that is right",
    "Actually please cancel that appointment",
    "Yes please cancel it",
]

CORRECT_PHONE = "9848012345"
PATIENT = "Srinithya Saindla"
