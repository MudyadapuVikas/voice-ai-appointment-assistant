"""Local stand-ins for the three external APIs, for the end-to-end call test.

They speak the same wire protocols the real Pipecat service clients use, so the
test exercises the real ElevenLabsRealtimeSTTService, GoogleLLMService and
ElevenLabsTTSService code paths, plus Pipecat function calling and our tools.
What they do NOT do is real AI:

* STT  (wss, /v1/speech-to-text/realtime): checks that real speech audio arrived
  for each turn, then returns the scripted caller line for that turn.
* LLM  (http, /v1beta/models/*:streamGenerateContent): a deterministic script
  that makes the same tool calls a good model would, using the real tool results.
* TTS  (ws, /v1/text-to-speech/*/multi-stream-input): real speech audio made
  with espeak-ng, plus character alignment, in the ElevenLabs message format.

Run:  python -m tests.e2e.vendor_emulator   (from backend/)
"""

import asyncio
import base64
import io
import json
import re
import ssl
import subprocess
import wave
from datetime import date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
from aiohttp import WSMsgType, web

from tests.e2e.script import CALLER_TURNS

HERE = Path(__file__).parent
TZ = ZoneInfo("Asia/Kolkata")
HTTP_PORT = 8790  # Gemini (http) + ElevenLabs TTS (ws)
TLS_PORT = 8791  # ElevenLabs STT (Pipecat always uses wss:// for it)

log: list[str] = []


def note(msg: str) -> None:
    line = f"[emulator {datetime.now():%H:%M:%S}] {msg}"
    log.append(line)
    print(line, flush=True)


# ---------------------------------------------------------------- audio helpers


def espeak_pcm(text: str, rate: int) -> bytes:
    """Speak `text` with espeak-ng and return 16-bit mono PCM at `rate` Hz."""
    wav_bytes = subprocess.run(["espeak-ng", "-v", "en-us", "-s", "170", "--stdout", text], capture_output=True, check=True).stdout
    with wave.open(io.BytesIO(wav_bytes)) as w:
        src_rate = w.getframerate()
        samples = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32)
    if src_rate != rate:
        n = int(len(samples) * rate / src_rate)
        samples = np.interp(np.linspace(0, len(samples) - 1, n), np.arange(len(samples)), samples)
    return samples.astype(np.int16).tobytes()


def rms(pcm: bytes) -> float:
    if not pcm:
        return 0.0
    a = np.frombuffer(pcm[: len(pcm) // 2 * 2], dtype=np.int16).astype(np.float32)
    return float(np.sqrt(np.mean(a * a))) if a.size else 0.0


# ---------------------------------------------------------------- ElevenLabs STT


async def stt_socket(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    assert request.headers.get("xi-api-key"), "STT: missing xi-api-key header"
    note(f"STT connected  {request.query_string[:80]}")
    await ws.send_json({"message_type": "session_started", "session_id": "emulated"})

    expected = request.app["stt_expected"]
    buffer = bytearray()
    async for msg in ws:
        if msg.type != WSMsgType.TEXT:
            continue
        data = json.loads(msg.data)
        if data.get("message_type") != "input_audio_chunk":
            continue
        if data.get("audio_base_64"):
            buffer += base64.b64decode(data["audio_base_64"])
        if data.get("commit"):
            seconds = len(buffer) / 2 / int(data.get("sample_rate") or 16000)
            level = rms(bytes(buffer))
            # One caller line can reach us as several VAD segments (pauses at full
            # stops). The line's text is returned once, on its first segment with speech.
            if level > 300 and expected.get("text") and not expected.get("delivered"):
                text = expected["text"]
                expected["delivered"] = True
                note(f"STT commit: {seconds:.1f}s audio, rms {level:.0f} -> {text!r}")
                await ws.send_json({"message_type": "partial_transcript", "text": text[: len(text) // 2]})
                await ws.send_json({"message_type": "committed_transcript", "text": text})
            else:
                note(f"STT commit: {seconds:.1f}s audio, rms {level:.0f} (no new text)")
            buffer.clear()
    note("STT closed")
    return ws


# ---------------------------------------------------------------- ElevenLabs TTS


async def tts_socket(request: web.Request) -> web.WebSocketResponse:
    ws = web.WebSocketResponse()
    await ws.prepare(request)
    assert request.headers.get("xi-api-key"), "TTS: missing xi-api-key header"
    rate = int(request.query.get("output_format", "pcm_24000").split("_")[1])
    note(f"TTS connected  voice={request.match_info['voice']} {request.query_string[:70]}")
    pending: dict[str, str] = {}

    async def speak(ctx: str) -> None:
        text = pending.pop(ctx, "").strip()
        if not text:
            return
        pcm = espeak_pcm(text, rate)
        duration_ms = len(pcm) / 2 / rate * 1000
        per_char = duration_ms / max(len(text), 1)
        note(f"TTS speak [{ctx[:6]}] {duration_ms / 1000:.1f}s: {text[:70]!r}")
        await ws.send_json(
            {
                "audio": base64.b64encode(pcm).decode(),
                "contextId": ctx,
                "alignment": {
                    "chars": list(text),
                    "charStartTimesMs": [round(i * per_char) for i in range(len(text))],
                    "charDurationsMs": [round(per_char)] * len(text),
                },
            }
        )

    async for msg in ws:
        if msg.type != WSMsgType.TEXT:
            continue
        data = json.loads(msg.data)
        ctx = data.get("context_id", "default")
        if data.get("text", "").strip():
            pending[ctx] = pending.get(ctx, "") + data["text"]
        if data.get("flush"):
            await speak(ctx)
        if data.get("close_context"):
            await speak(ctx)
            await ws.send_json({"isFinal": True, "contextId": ctx})
    note("TTS closed")
    return ws


# ---------------------------------------------------------------- Gemini


def _upcoming_friday() -> date:
    today = datetime.now(TZ).date()
    for i in range(1, 7):
        if (today + timedelta(days=i)).weekday() == 4:
            return today + timedelta(days=i)
    return today + timedelta(days=1)


def _say_time(hhmm: str) -> str:
    h, m = map(int, hhmm.split(":"))
    return f"{(h + 11) % 12 + 1}{':%02d' % m if m else ''} {'in the morning' if h < 12 else 'in the afternoon'}"


def _say_digits(number: str) -> str:
    words = "zero one two three four five six seven eight nine".split()
    digits = re.sub(r"\D", "", number)
    return f"{' '.join(words[int(d)] for d in digits[:5])}, {' '.join(words[int(d)] for d in digits[5:])}"


def _parts(contents: list[dict]):
    for c in contents:
        for p in c.get("parts", []):
            yield c.get("role"), p


def _tool_results(contents: list[dict], name: str) -> list[dict]:
    out = []
    for _, p in _parts(contents):
        fr = p.get("functionResponse") or p.get("function_response")
        if fr and fr.get("name") == name:
            out.append(_unwrap(fr.get("response")))
    return out


def _unwrap(value):
    """Pipecat may wrap tool results ({"value": "<json>"}); dig out the dict."""
    if isinstance(value, str):
        try:
            return _unwrap(json.loads(value))
        except ValueError:
            return value
    if isinstance(value, dict) and len(value) == 1 and next(iter(value)) in ("value", "result", "output", "response"):
        return _unwrap(next(iter(value.values())))
    return value


def brain(body: dict) -> dict:
    """Return one Gemini 'part': either {"text": ...} or {"functionCall": ...}."""
    contents = body.get("contents", [])
    system = json.dumps(body.get("systemInstruction") or body.get("system_instruction") or "")
    assert "Mira" in system, "system prompt missing"
    tools = [d["name"] for t in body.get("tools", []) for d in t.get("functionDeclarations", t.get("function_declarations", []))]
    assert set(tools) >= {"check_doctor_availability", "book_appointment", "cancel_appointment"}, f"tools: {tools}"

    role, last = list(_parts(contents))[-1]
    friday = _upcoming_friday()

    # ---- reply to a tool result
    fr = last.get("functionResponse") or last.get("function_response")
    if fr:
        result = _unwrap(fr.get("response"))
        name = fr["name"]
        if not isinstance(result, dict) or result.get("ok") is False:
            return {"text": f"I'm sorry, {result.get('message', 'that did not work') if isinstance(result, dict) else result}"}
        if name == "check_doctor_availability":
            offers = []
            for d in result["doctors"]:
                if d["availability"]:
                    slots = d["availability"][0]["free_slots"]
                    offers.append(f"{d['name']} has {' or '.join(_say_time(s) for s in slots[:2])}")
            return {"text": f"On Friday, {' and '.join(offers)}. Which would you like?"}
        if name == "book_appointment":
            a = result["appointment"]
            return {"text": f"You're all set. {a['patient_name']} is booked with {a['doctor_name']} on Friday at {_say_time(a['time'])}. Is there anything else?"}
        if name == "cancel_appointment":
            if result.get("needs_confirmation"):
                a = result["appointments"][0]
                return {"text": f"I can see your appointment with {a['doctor_name']} on Friday at {_say_time(a['time'])}. Shall I cancel it?"}
            return {"text": "Done. That appointment is cancelled. Take care, goodbye."}

    # ---- reply to the caller
    text = (last.get("text") or "").strip()
    if text not in CALLER_TURNS:
        if any(t["role"] == "model" for t in contents):
            note(f"LLM called without a new caller line; last part ({role}): {json.dumps(last)[:120]}")
        return {"text": "Hello, you've reached Halcyon Clinic, this is Mira. How can I help you today?"}
    turn = CALLER_TURNS.index(text)

    if turn == 0:
        return {"functionCall": {"name": "check_doctor_availability", "args": {"specialty": "cardiology", "date": friday.isoformat()}}}
    if turn == 1:
        return {"text": "Of course. May I have the patient's full name?"}
    if turn == 2:
        return {"text": "Thank you. And what's your mobile number?"}
    if turn in (3, 4):
        number = " ".join(re.findall(r"\d+", text))
        return {"text": f"Let me read that back. {_say_digits(number)}. Is that right?"}
    if turn == 5:
        availability = _tool_results(contents, "check_doctor_availability")[-1]
        mehta = next(d for d in availability["doctors"] if d["doctor_id"] == "D2")
        second_slot = mehta["availability"][0]["free_slots"][1]
        corrected = " ".join(re.findall(r"\d+", CALLER_TURNS[4]))
        name = CALLER_TURNS[2].split("is", 1)[1].strip(" .")
        return {
            "functionCall": {
                "name": "book_appointment",
                "args": {
                    "patient_name": name,
                    "phone_number": corrected,
                    "phone_confirmed": True,
                    "doctor_id": "D2",
                    "date": friday.isoformat(),
                    "time": second_slot,
                },
            }
        }
    if turn == 6:
        return {"functionCall": {"name": "cancel_appointment", "args": {"phone_number": "9848012345", "phone_confirmed": True}}}
    if turn == 7:
        found = _tool_results(contents, "cancel_appointment")[-1]["appointments"][0]
        return {
            "functionCall": {
                "name": "cancel_appointment",
                "args": {"phone_number": "9848012345", "phone_confirmed": True, "appointment_id": found["id"], "cancel_confirmed": True},
            }
        }
    return {"text": "Okay."}


def _response(parts: list[dict], finish: bool) -> dict:
    out = {"candidates": [{"content": {"role": "model", "parts": parts}, "index": 0}], "modelVersion": "emulated"}
    if finish:
        out["candidates"][0]["finishReason"] = "STOP"
        out["usageMetadata"] = {"promptTokenCount": 100, "candidatesTokenCount": 20, "totalTokenCount": 120}
    return out


async def gemini(request: web.Request) -> web.StreamResponse:
    assert request.headers.get("x-goog-api-key") or request.query.get("key"), "Gemini: missing API key"
    body = await request.json()
    model, _, method = request.match_info["target"].partition(":")
    part = brain(body)
    note(f"Gemini {model} {method}: {json.dumps(part)[:140]}")

    # stream text in two chunks like the real API; a function call comes whole
    chunks = [part]
    if "text" in part and len(part["text"]) > 20:
        cut = part["text"].find(". ") + 2 or len(part["text"]) // 2
        chunks = [{"text": part["text"][:cut]}, {"text": part["text"][cut:]}]

    if method.startswith("streamGenerateContent"):
        resp = web.StreamResponse(headers={"Content-Type": "text/event-stream"})
        await resp.prepare(request)
        for i, c in enumerate(chunks):
            await resp.write(f"data: {json.dumps(_response([c], i == len(chunks) - 1))}\r\n\r\n".encode())
            await asyncio.sleep(0.05)
        await resp.write_eof()
        return resp
    return web.json_response(_response([part], True))


# ---------------------------------------------------------------- servers


def tls_context() -> ssl.SSLContext:
    cert, key = HERE / "localhost.pem", HERE / "localhost-key.pem"
    if not cert.exists():
        subprocess.run(
            ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "30", "-subj", "/CN=localhost",
             "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1", "-keyout", str(key), "-out", str(cert)],
            check=True, capture_output=True,
        )
    ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
    ctx.load_cert_chain(cert, key)
    return ctx


async def main() -> None:
    app = web.Application()
    app["stt_expected"] = {}

    async def expect(request: web.Request) -> web.Response:
        """The test announces which caller line it is about to speak."""
        app["stt_expected"].clear()
        app["stt_expected"]["text"] = CALLER_TURNS[int(request.query["turn"])]
        return web.json_response({"ok": True})

    app.router.add_post("/emulator/expect", expect)
    app.router.add_post("/v1beta/models/{target}", gemini)
    app.router.add_get("/v1/text-to-speech/{voice}/multi-stream-input", tts_socket)
    app.router.add_get("/v1/speech-to-text/realtime", stt_socket)
    app.router.add_get("/emulator/log", lambda r: web.json_response(log))

    runner = web.AppRunner(app)
    await runner.setup()
    await web.TCPSite(runner, "127.0.0.1", HTTP_PORT).start()
    await web.TCPSite(runner, "127.0.0.1", TLS_PORT, ssl_context=tls_context()).start()
    note(f"listening: http/ws :{HTTP_PORT}, wss :{TLS_PORT}")
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
