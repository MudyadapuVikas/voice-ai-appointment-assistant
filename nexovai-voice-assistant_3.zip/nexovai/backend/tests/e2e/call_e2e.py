"""End-to-end voice call test: browser -> WebRTC -> Pipecat -> tools -> dashboard.

What is real here: the built React app in Chromium, the Pipecat browser client,
WebRTC audio both ways, our FastAPI backend, Silero VAD, Pipecat's ElevenLabs
STT/TTS and Gemini client code, Pipecat function calling, our three tools,
SQLite and the SSE dashboard updates.

What is emulated (see vendor_emulator.py): the ElevenLabs and Gemini servers.
The caller's voice is espeak-ng speech fed into a synthetic microphone.

Requires: espeak-ng, Chromium for Playwright, `npm run build` done in frontend/.
Run from backend/:   python -m tests.e2e.call_e2e
Artifacts (video, screenshots, logs) go to tests/e2e/artifacts/.
"""

import asyncio
import base64
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from playwright.async_api import Page, async_playwright

from tests.e2e.script import CALLER_TURNS, CORRECT_PHONE, PATIENT

BACKEND = Path(__file__).resolve().parents[2]
FRONTEND = BACKEND.parent / "frontend"
ART = Path(__file__).parent / "artifacts"
API_PORT, WEB_PORT = 7861, 4174
# Python with the backend requirements (defaults to the one running this script)
PY = os.getenv("BACKEND_PYTHON", sys.executable)

MIC_SHIM = """
(() => {
  // Synthetic microphone: the test plays espeak-ng speech into it with window.__say().
  const real = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  navigator.mediaDevices.getUserMedia = async (c) => {
    if (!c || !c.audio) return real(c);
    const ctx = new AudioContext({ sampleRate: 48000 });
    const dest = ctx.createMediaStreamDestination();
    // a real mic never goes silent: keep a faint noise floor so audio flows continuously
    const noise = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
    const ch = noise.getChannelData(0);
    for (let i = 0; i < ch.length; i++) ch[i] = (Math.random() * 2 - 1) * 0.003;
    const floor = ctx.createBufferSource();
    floor.buffer = noise; floor.loop = true; floor.connect(dest); floor.start();
    window.__mic = { ctx, dest };
    return dest.stream;
  };
  window.__say = async (b64) => {
    const { ctx, dest } = window.__mic;
    await ctx.resume();
    const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const buf = await ctx.decodeAudioData(bytes.buffer);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    src.connect(dest);
    src.start();
    await new Promise((r) => (src.onended = r));
  };
  // Independent check that the agent's audio really arrives over WebRTC.
  window.__agentPeak = 0;
  const RealPC = window.RTCPeerConnection;
  window.RTCPeerConnection = function (...args) {
    const pc = new RealPC(...args);
    pc.addEventListener("track", (e) => {
      if (e.track.kind !== "audio") return;
      const ctx = new AudioContext();
      const an = ctx.createAnalyser();
      ctx.createMediaStreamSource(new MediaStream([e.track])).connect(an);
      const data = new Float32Array(an.fftSize);
      setInterval(() => {
        an.getFloatTimeDomainData(data);
        let peak = 0; for (const v of data) peak = Math.max(peak, Math.abs(v));
        window.__agentPeak = Math.max(window.__agentPeak, peak);
      }, 50);
    });
    return pc;
  };
  window.RTCPeerConnection.prototype = RealPC.prototype;
})();
"""


def wav_b64(text: str) -> str:
    wav = subprocess.run(["espeak-ng", "-v", "en-us", "-s", "155", "--stdout", text], capture_output=True, check=True).stdout
    return base64.b64encode(wav).decode()


def wait_http(url: str, timeout: float = 60) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(url, timeout=2)
            return
        except Exception:
            time.sleep(0.5)
    raise RuntimeError(f"{url} did not come up")


class Checks:
    def __init__(self):
        self.results: list[tuple[bool, str]] = []

    def check(self, ok: bool, what: str) -> None:
        self.results.append((bool(ok), what))
        print(f"  {'PASS' if ok else 'FAIL'}  {what}", flush=True)

    @property
    def failed(self) -> int:
        return sum(1 for ok, _ in self.results if not ok)


async def agent_lines(page: Page) -> list[str]:
    return await page.locator("[data-role=agent]").all_inner_texts()


async def caller_lines(page: Page) -> list[str]:
    return await page.locator("[data-role=caller]").all_inner_texts()


async def wait_for_agent_reply(page: Page, before: int, timeout: float = 45) -> str:
    """Wait for a new agent bubble, then for Mira to finish speaking it."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        lines = await agent_lines(page)
        status = (await page.locator(".agent-status").inner_text()) if await page.locator(".agent-status").count() else ""
        if len(lines) > before and status.strip() == "Listening":
            await page.wait_for_timeout(900)  # stays quiet = finished
            if (await page.locator(".agent-status").inner_text()).strip() == "Listening":
                return lines[-1]
        await page.wait_for_timeout(250)
    raise TimeoutError(f"no agent reply (had {before} lines)")


async def run(checks: Checks) -> None:
    async with async_playwright() as p:
        browser = await p.chromium.launch(args=["--autoplay-policy=no-user-gesture-required", "--use-fake-ui-for-media-stream"])
        ctx = await browser.new_context(
            viewport={"width": 1440, "height": 900},
            permissions=["microphone"],
            record_video_dir=str(ART),
            record_video_size={"width": 1440, "height": 900},
        )
        await ctx.add_init_script(MIC_SHIM)
        page = await ctx.new_page()
        console: list[str] = []
        page.on("console", lambda m: console.append(f"{m.type}: {m.text}"))
        page.on("pageerror", lambda e: console.append(f"pageerror: {e}"))

        await page.goto(f"http://127.0.0.1:{WEB_PORT}/#/appointments")
        await page.wait_for_timeout(1500)
        await page.screenshot(path=ART / "0-before-call.png")

        # ---- dial
        await page.get_by_role("button", name="Try call").first.click()
        await page.wait_for_function("document.querySelector('[aria-label=\"Call with Mira\"]')?.innerText.match(/\\d\\d:\\d\\d\\n/)", timeout=30_000)
        checks.check(True, "call connected: microphone granted, WebRTC up, agent ready")
        greeting = await wait_for_agent_reply(page, 0)
        checks.check("Halcyon" in greeting, f"agent greeted the caller (LLM -> TTS -> browser): {greeting[:60]!r}")
        checks.check(await page.evaluate("window.__agentPeak") > 0.02, f"agent audio received in browser (peak {await page.evaluate('window.__agentPeak'):.2f})")

        expectations = {
            0: ("Vikram Mehta", "availability checked through the tool and real slots offered"),
            3: ("one two three five four", "agent read back the (wrong) number"),
            4: ("one two three four five", "agent read back the corrected number"),
            5: ("all set", "booking confirmed"),
            6: ("Shall I cancel", "agent found the booking by phone number and asked to confirm"),
            7: ("cancelled", "cancellation confirmed"),
        }

        for i, line in enumerate(CALLER_TURNS):
            before = len(await agent_lines(page))
            urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:8790/emulator/expect?turn={i}", method="POST"))
            await page.evaluate("b64 => window.__say(b64)", wav_b64(line))
            reply = await wait_for_agent_reply(page, before)
            heard = (await caller_lines(page))[-1]
            print(f"    caller: {heard!r}\n    agent:  {reply!r}", flush=True)
            checks.check(line.rstrip(".") in heard or heard in line, f"turn {i + 1}: caller transcript shown live")
            if i in expectations:
                needle, what = expectations[i]
                checks.check(needle.lower() in reply.lower(), f"turn {i + 1}: {what}")

            if i == 5:
                await page.wait_for_timeout(800)
                await page.screenshot(path=ART / "1-booked-in-call.png")
                ticket = await page.locator("text=Confirmed").count()
                checks.check(ticket > 0, "booking confirmation card shown inside the phone")
                row = page.locator("tbody tr", has_text=PATIENT)
                checks.check(await row.count() == 1, "dashboard appointments table updated live (SSE) with the new booking")
                api = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{API_PORT}/api/appointments").read())
                mine = [a for a in api if a["phone"] == CORRECT_PHONE]
                checks.check(len(mine) == 1 and mine[0]["status"] == "booked" and mine[0]["source"] == "voice",
                             f"database: booked by voice for the confirmed number {CORRECT_PHONE}")
                checks.check(not [a for a in api if a["phone"] == "9848012354"], "nothing was booked for the wrong number")

        await page.wait_for_timeout(1000)
        await page.screenshot(path=ART / "2-cancelled-in-call.png")
        api = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{API_PORT}/api/appointments").read())
        mine = [a for a in api if a["phone"] == CORRECT_PHONE]
        checks.check(mine and mine[0]["status"] == "cancelled", "database: appointment cancelled")

        # ---- hang up
        await page.get_by_role("button", name="End").click()
        await page.wait_for_timeout(1500)
        ended = await page.locator("text=Call ended").count()
        checks.check(ended > 0, "call ended cleanly from the browser")
        await page.locator("[aria-label='Call with Mira'] button", has_text="Close").click()
        await page.get_by_role("button", name="Cancelled").click()
        await page.wait_for_timeout(500)
        checks.check(await page.locator("tbody tr", has_text=PATIENT).count() == 1, "dashboard shows the cancellation")
        await page.goto(f"http://127.0.0.1:{WEB_PORT}/#/activity")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=ART / "3-activity.png")

        errors = [c for c in console if c.startswith(("error", "pageerror"))]
        checks.check(not errors, f"no browser errors ({errors[:2]})")
        await ctx.close()
        await browser.close()


def main() -> int:
    if not shutil.which("espeak-ng"):
        print("espeak-ng is required for the caller's voice")
        return 2
    if ART.exists():
        shutil.rmtree(ART)
    ART.mkdir(parents=True)
    db = ART / "e2e.db"
    cert = Path(__file__).parent / "localhost.pem"

    procs = []
    logs = {name: open(ART / f"{name}.log", "w") for name in ("emulator", "backend", "frontend")}
    try:
        procs.append(subprocess.Popen([PY, "-m", "tests.e2e.vendor_emulator"], cwd=BACKEND, stdout=logs["emulator"], stderr=subprocess.STDOUT))
        for _ in range(40):
            if cert.exists():
                break
            time.sleep(0.25)
        env = {
            **os.environ,
            "ELEVENLABS_API_KEY": "emulated-key",
            "GOOGLE_API_KEY": "emulated-key",
            "ELEVENLABS_TTS_URL": "ws://127.0.0.1:8790",
            "ELEVENLABS_STT_HOST": "127.0.0.1:8791",
            "GEMINI_BASE_URL": "http://127.0.0.1:8790",
            "SSL_CERT_FILE": str(cert),
            "NO_PROXY": "127.0.0.1,localhost",
            "no_proxy": "127.0.0.1,localhost",
            "DB_PATH": str(db),
        }
        procs.append(subprocess.Popen([PY, "-m", "uvicorn", "app.main:app", "--port", str(API_PORT)], cwd=BACKEND, env=env, stdout=logs["backend"], stderr=subprocess.STDOUT))
        wait_http(f"http://127.0.0.1:{API_PORT}/api/health")
        web_env = {**os.environ, "VITE_BACKEND_PORT": str(API_PORT)}
        procs.append(subprocess.Popen(["npx", "vite", "preview", "--port", str(WEB_PORT), "--host", "127.0.0.1", "--strictPort"],
                                      cwd=FRONTEND, env=web_env, stdout=logs["frontend"], stderr=subprocess.STDOUT))
        wait_http(f"http://127.0.0.1:{WEB_PORT}/")

        checks = Checks()
        print("Running end-to-end call…", flush=True)
        asyncio.run(run(checks))
        print(f"\n{len(checks.results) - checks.failed}/{len(checks.results)} checks passed")
        return 1 if checks.failed else 0
    finally:
        for p in procs:
            p.terminate()
        for p in procs:
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                p.kill()
        for f in logs.values():
            f.close()
        for v in ART.glob("*.webm"):
            v.rename(ART / "call.webm")


if __name__ == "__main__":
    sys.exit(main())
