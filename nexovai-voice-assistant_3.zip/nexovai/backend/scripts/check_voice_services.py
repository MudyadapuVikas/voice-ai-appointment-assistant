"""Check your real API keys before a demo: ElevenLabs TTS, ElevenLabs STT and Gemini.

    cd backend
    python -m scripts.check_voice_services

1. ElevenLabs TTS speaks a test sentence (your ELEVENLABS_VOICE_ID / model).
2. ElevenLabs STT transcribes that audio back (round trip).
3. Gemini gets Mira's real system prompt + our three tools and a caller request,
   and must answer with a check_doctor_availability function call
   (the same tool format Pipecat sends during a call).

Every step prints PASS/FAIL with the reason. No appointments are changed.
"""

import asyncio
import io
import json
import sys
import time
import wave

import aiohttp
from google import genai
from google.genai import types
from pipecat.adapters.llm.schemas.tools_schema import ToolsSchema
from pipecat.adapters.llm.services.gemini_adapter import GeminiLLMAdapter

from app.agents.prompts import receptionist_prompt
from app.config import settings
from app.database.db import init_db
from app.tools.appointment_tools import TOOLS

SENTENCE = "I would like to book an appointment with a cardiologist tomorrow."
RATE = 16000


def result(ok: bool, step: str, detail: str) -> bool:
    print(f"{'PASS' if ok else 'FAIL'}  {step:<22} {detail}", flush=True)
    return ok


def to_wav(pcm: bytes) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm)
    return buf.getvalue()


async def check_tts(session: aiohttp.ClientSession) -> bytes | None:
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{settings.elevenlabs_voice_id}?output_format=pcm_{RATE}"
    t = time.perf_counter()
    async with session.post(url, json={"text": SENTENCE, "model_id": settings.elevenlabs_tts_model}) as r:
        body = await r.read()
        if r.status != 200:
            result(False, "ElevenLabs TTS", f"HTTP {r.status}: {body[:200].decode(errors='replace')}")
            return None
    seconds = len(body) / 2 / RATE
    result(seconds > 1, "ElevenLabs TTS", f"{seconds:.1f}s of audio in {time.perf_counter() - t:.1f}s (voice {settings.elevenlabs_voice_id}, {settings.elevenlabs_tts_model})")
    return body


async def check_stt(session: aiohttp.ClientSession, pcm: bytes) -> bool:
    form = aiohttp.FormData()
    form.add_field("model_id", "scribe_v2")
    form.add_field("file", to_wav(pcm), filename="check.wav", content_type="audio/wav")
    t = time.perf_counter()
    async with session.post("https://api.elevenlabs.io/v1/speech-to-text", data=form) as r:
        text = await r.text()
        if r.status != 200:
            return result(False, "ElevenLabs STT", f"HTTP {r.status}: {text[:200]}")
    heard = json.loads(text).get("text", "")
    ok = "cardiologist" in heard.lower()
    return result(ok, "ElevenLabs STT", f"heard {heard!r} in {time.perf_counter() - t:.1f}s")


def check_gemini() -> bool:
    client = genai.Client(api_key=settings.google_api_key)
    tools = GeminiLLMAdapter().to_provider_tools_format(ToolsSchema(standard_tools=TOOLS))
    t = time.perf_counter()
    try:
        response = client.models.generate_content(
            model=settings.google_model,
            contents="Hi, do you have any cardiologists free tomorrow?",
            config=types.GenerateContentConfig(
                system_instruction=receptionist_prompt(),
                tools=tools,
                automatic_function_calling=types.AutomaticFunctionCallingConfig(disable=True),
            ),
        )
    except Exception as e:  # bad key, unknown model, quota...
        return result(False, "Gemini", f"{type(e).__name__}: {str(e)[:220]}")
    calls = response.function_calls or []
    if not calls:
        return result(False, "Gemini function call", f"no tool call; answered {response.text!r}")
    call = calls[0]
    ok = call.name == "check_doctor_availability"
    return result(ok, "Gemini function call", f"{call.name}({json.dumps(dict(call.args or {}))}) in {time.perf_counter() - t:.1f}s with {settings.google_model}")


async def main() -> int:
    missing = settings.missing_voice_credentials
    if missing:
        print(f"Missing in .env: {', '.join(missing)}")
        return 2
    init_db()  # the prompt lists the doctors
    ok = True
    async with aiohttp.ClientSession(headers={"xi-api-key": settings.elevenlabs_api_key}, timeout=aiohttp.ClientTimeout(total=60), trust_env=True) as session:
        try:
            pcm = await check_tts(session)
            ok &= pcm is not None
            if pcm:
                ok &= await check_stt(session, pcm)
        except aiohttp.ClientError as e:
            ok = result(False, "ElevenLabs", f"network error: {e}")
    ok &= check_gemini()
    print("\nAll voice services ready." if ok else "\nFix the FAIL lines above before a live call.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
