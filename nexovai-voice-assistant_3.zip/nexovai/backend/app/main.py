"""FastAPI entry point.

    cd backend
    uvicorn app.main:app --port 7860
"""

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from app.api import routes, webrtc
from app.config import settings
from app.database.db import init_db
from app.services.events import bus


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    bus.bind(asyncio.get_running_loop())
    if settings.voice_enabled:
        logger.info(f"Voice ready: ElevenLabs STT/TTS + {settings.google_model}")
    else:
        logger.warning(
            f"Voice disabled, missing {', '.join(settings.missing_voice_credentials)}. "
            "Dashboard and demo mode still work."
        )
    yield
    await webrtc.shutdown()


app = FastAPI(title="Halcyon voice front desk", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(routes.router)
app.include_router(webrtc.router)
