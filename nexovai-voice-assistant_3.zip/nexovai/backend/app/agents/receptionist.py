"""The voice pipeline for one call.

  browser mic --WebRTC--> Silero VAD --> ElevenLabs STT --> Gemini (+tools) --> ElevenLabs TTS --WebRTC--> browser

Transcripts, speaking state and tool activity reach the browser through RTVI
messages on the same WebRTC data channel.
"""

from google.genai.types import HttpOptions
from loguru import logger
from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.frames.frames import LLMRunFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.worker import PipelineParams, PipelineWorker
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.aggregators.llm_response_universal import LLMContextAggregatorPair, LLMUserAggregatorParams
from pipecat.processors.frameworks.rtvi import RTVIObserverParams
from pipecat.processors.frameworks.rtvi.observer import RTVIFunctionCallReportLevel
from pipecat.services.elevenlabs.stt import ElevenLabsRealtimeSTTService
from pipecat.services.elevenlabs.tts import ElevenLabsTTSService
from pipecat.services.google.llm import GoogleLLMService
from pipecat.transports.base_transport import TransportParams
from pipecat.transports.smallwebrtc.connection import SmallWebRTCConnection
from pipecat.transports.smallwebrtc.transport import SmallWebRTCTransport
from pipecat.workers.runner import WorkerRunner

from app.agents.prompts import GREETING_INSTRUCTION, receptionist_prompt
from app.config import settings
from app.tools.appointment_tools import TOOLS

IDLE_TIMEOUT_SECS = 180


async def run_receptionist(connection: SmallWebRTCConnection) -> None:
    transport = SmallWebRTCTransport(
        webrtc_connection=connection,
        params=TransportParams(audio_in_enabled=True, audio_out_enabled=True),
    )

    stt = ElevenLabsRealtimeSTTService(
        api_key=settings.elevenlabs_api_key,
        base_url=settings.elevenlabs_stt_host,
        settings=ElevenLabsRealtimeSTTService.Settings(
            keyterms=["appointment", "cancel", "cardiologist", "dermatologist", "pediatrician", "orthopedic", "ENT"],
        ),
    )
    tts = ElevenLabsTTSService(
        api_key=settings.elevenlabs_api_key,
        url=settings.elevenlabs_tts_url,
        settings=ElevenLabsTTSService.Settings(voice=settings.elevenlabs_voice_id, model=settings.elevenlabs_tts_model),
    )
    llm = GoogleLLMService(
        api_key=settings.google_api_key,
        http_options=HttpOptions(base_url=settings.gemini_base_url) if settings.gemini_base_url else None,
        settings=GoogleLLMService.Settings(model=settings.google_model, system_instruction=receptionist_prompt()),
    )

    context = LLMContext(tools=TOOLS)
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        # Silero VAD detects speech (and lets the caller interrupt Mira); Pipecat's
        # default smart-turn analyzer then decides when the caller has finished.
        # Default VAD params (stop_secs=0.2) are what that analyzer is tuned for.
        user_params=LLMUserAggregatorParams(vad_analyzer=SileroVADAnalyzer()),
    )

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    worker = PipelineWorker(
        pipeline,
        params=PipelineParams(enable_metrics=True, enable_usage_metrics=True),
        idle_timeout_secs=IDLE_TIMEOUT_SECS,
        # the UI shows "Checking the schedule..." from tool names; arguments (phone numbers) are never sent
        rtvi_observer_params=RTVIObserverParams(function_call_report_level={"*": RTVIFunctionCallReportLevel.NAME}),
    )
    runner = WorkerRunner(handle_sigint=False)
    await runner.add_workers(worker)

    @transport.event_handler("on_client_connected")
    async def on_client_connected(_transport, _client):
        logger.info(f"Call started ({connection.pc_id})")
        context.add_message({"role": "developer", "content": GREETING_INSTRUCTION})
        await worker.queue_frames([LLMRunFrame()])

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(_transport, _client):
        logger.info(f"Call ended ({connection.pc_id})")
        await runner.cancel()

    await runner.run()
