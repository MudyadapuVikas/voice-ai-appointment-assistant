"""Settings read from environment variables (.env in the repo root or in backend/)."""

import os
from dataclasses import dataclass, field
from pathlib import Path
from zoneinfo import ZoneInfo

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent.parent
ROOT_DIR = BACKEND_DIR.parent

# backend/.env wins over the root .env if both exist
load_dotenv(ROOT_DIR / ".env")
load_dotenv(BACKEND_DIR / ".env", override=True)


@dataclass(frozen=True)
class Settings:
    elevenlabs_api_key: str = field(default_factory=lambda: os.getenv("ELEVENLABS_API_KEY", "").strip())
    elevenlabs_voice_id: str = field(default_factory=lambda: os.getenv("ELEVENLABS_VOICE_ID", "EXAVITQu4vr4xnSDxMaL"))
    elevenlabs_tts_model: str = field(default_factory=lambda: os.getenv("ELEVENLABS_TTS_MODEL", "eleven_flash_v2_5"))
    google_api_key: str = field(default_factory=lambda: os.getenv("GOOGLE_API_KEY", "").strip())
    google_model: str = field(default_factory=lambda: os.getenv("GOOGLE_MODEL", "gemini-3.6-flash"))
    # Endpoint overrides. Leave unset in normal use; the end-to-end test points
    # them at a local emulator (tests/e2e), and they also allow regional endpoints.
    elevenlabs_tts_url: str = field(default_factory=lambda: os.getenv("ELEVENLABS_TTS_URL", "wss://api.elevenlabs.io"))
    elevenlabs_stt_host: str = field(default_factory=lambda: os.getenv("ELEVENLABS_STT_HOST", "api.elevenlabs.io"))
    gemini_base_url: str = field(default_factory=lambda: os.getenv("GEMINI_BASE_URL", ""))
    db_path: str = field(default_factory=lambda: os.getenv("DB_PATH", str(BACKEND_DIR / "data" / "clinic.db")))
    timezone: str = field(default_factory=lambda: os.getenv("CLINIC_TZ", "Asia/Kolkata"))
    clinic_name: str = field(default_factory=lambda: os.getenv("CLINIC_NAME", "Halcyon Clinic"))
    cors_origins: list[str] = field(
        default_factory=lambda: os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
    )

    @property
    def tz(self) -> ZoneInfo:
        return ZoneInfo(self.timezone)

    @property
    def missing_voice_credentials(self) -> list[str]:
        missing = []
        if not self.elevenlabs_api_key:
            missing.append("ELEVENLABS_API_KEY")
        if not self.google_api_key:
            missing.append("GOOGLE_API_KEY")
        return missing

    @property
    def voice_enabled(self) -> bool:
        return not self.missing_voice_credentials


settings = Settings()
