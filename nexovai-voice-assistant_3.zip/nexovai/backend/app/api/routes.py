"""Dashboard REST API, demo-mode actions and the live event stream."""

import asyncio

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

from app.config import settings
from app.database.db import get_conn, init_db
from app.services import appointments, availability
from app.services.errors import AppointmentError
from app.services.events import bus

router = APIRouter(prefix="/api")

HTTP_STATUS = {
    "unknown_doctor": 404,
    "unknown_appointment": 404,
    "no_appointments": 404,
    "no_matching_doctor": 404,
    "slot_unavailable": 409,
}


def error_response(e: AppointmentError) -> JSONResponse:
    return JSONResponse(status_code=HTTP_STATUS.get(e.code, 422), content=e.to_dict())


@router.get("/health")
def health():
    return {
        "ok": True,
        "voice_enabled": settings.voice_enabled,
        "missing_credentials": settings.missing_voice_credentials,
        "llm": settings.google_model,
        "clinic": settings.clinic_name,
    }


@router.get("/overview")
def overview():
    with get_conn() as conn:
        return {"stats": appointments.stats(conn), "activity": appointments.activity(conn, limit=8)}


@router.get("/schedule")
def schedule():
    with get_conn() as conn:
        return availability.schedule(conn)


@router.get("/appointments")
def list_appointments():
    with get_conn() as conn:
        return appointments.list_appointments(conn)


@router.get("/activity")
def list_activity(limit: int = 50):
    with get_conn() as conn:
        return appointments.activity(conn, limit=min(max(limit, 1), 200))


@router.get("/availability")
def get_availability(doctor: str = "", specialty: str = "", date: str = ""):
    try:
        with get_conn() as conn:
            return availability.check_availability(conn, doctor=doctor, specialty=specialty, day=date)
    except AppointmentError as e:
        return error_response(e)


# ---------------------------------------------------------------- demo mode
# The same service calls the voice tools make, so booking/cancelling can be
# tested from the dashboard without API keys. Marked source="dashboard".


class BookingIn(BaseModel):
    patient_name: str = Field(min_length=1, max_length=80)
    phone_number: str = Field(min_length=1, max_length=40)
    doctor_id: str
    date: str
    time: str


class CancelIn(BaseModel):
    phone_number: str
    appointment_id: int = 0
    confirm: bool = False


@router.post("/appointments", status_code=201)
def create_appointment(body: BookingIn):
    try:
        # the dashboard form shows the number on screen, which is its "read back"
        return appointments.book(**body.model_dump(), phone_confirmed=True, source="dashboard")
    except AppointmentError as e:
        return error_response(e)


@router.post("/appointments/cancel")
def cancel_appointment(body: CancelIn):
    try:
        return appointments.cancel(
            phone_number=body.phone_number,
            phone_confirmed=True,
            appointment_id=body.appointment_id,
            cancel_confirmed=body.confirm,
            source="dashboard",
        )
    except AppointmentError as e:
        return error_response(e)


@router.post("/demo/reset")
def reset_demo_data():
    init_db(reset=True)
    bus.publish("data.reset", {})
    return {"ok": True}


# ---------------------------------------------------------------- live events


@router.get("/events")
async def events(request: Request):
    """Server-Sent Events: the dashboard listens here for bookings and cancellations."""
    queue = bus.subscribe()

    async def stream():
        try:
            yield "event: ready\ndata: {}\n\n"
            while not await request.is_disconnected():
                try:
                    message = await asyncio.wait_for(queue.get(), timeout=15)
                    yield f"data: {message}\n\n"
                except asyncio.TimeoutError:
                    yield ": keep-alive\n\n"
        finally:
            bus.unsubscribe(queue)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
