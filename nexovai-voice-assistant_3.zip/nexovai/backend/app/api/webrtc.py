"""WebRTC signalling for the browser call.

The browser (Pipecat SmallWebRTCTransport) POSTs an SDP offer to /api/offer;
we answer it and start one receptionist pipeline per peer connection.
Trickle ICE candidates arrive with PATCH /api/offer.
"""

import asyncio

from fastapi import APIRouter, HTTPException, Request
from loguru import logger
from pipecat.transports.smallwebrtc.connection import SmallWebRTCConnection
from pipecat.transports.smallwebrtc.request_handler import (
    IceCandidate,
    SmallWebRTCPatchRequest,
    SmallWebRTCRequest,
    SmallWebRTCRequestHandler,
)

from app.agents.receptionist import run_receptionist
from app.config import settings

router = APIRouter(prefix="/api")
handler = SmallWebRTCRequestHandler()
_calls: set[asyncio.Task] = set()  # keep strong refs so running calls aren't garbage-collected


async def _run_call(connection: SmallWebRTCConnection) -> None:
    try:
        await run_receptionist(connection)
    except Exception:
        logger.exception("Voice pipeline crashed")


@router.post("/offer")
async def offer(request: Request):
    if not settings.voice_enabled:
        raise HTTPException(
            status_code=503,
            detail=f"Voice is disabled. Set {', '.join(settings.missing_voice_credentials)} in .env and restart the backend.",
        )
    body = await request.json()

    async def on_new_connection(connection: SmallWebRTCConnection):
        task = asyncio.create_task(_run_call(connection))
        _calls.add(task)
        task.add_done_callback(_calls.discard)

    answer = await handler.handle_web_request(
        request=SmallWebRTCRequest.from_dict(body),
        webrtc_connection_callback=on_new_connection,
    )
    return answer


@router.patch("/offer")
async def ice_candidates(request: Request):
    body = await request.json()
    patch = SmallWebRTCPatchRequest(
        pc_id=body["pc_id"],
        candidates=[IceCandidate(**c) for c in body.get("candidates", [])],
    )
    await handler.handle_patch_request(patch)
    return {"ok": True}


async def shutdown() -> None:
    await handler.close()
    for task in list(_calls):
        task.cancel()
