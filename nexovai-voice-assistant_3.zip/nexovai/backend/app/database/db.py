"""SQLite schema, connection helper and seed data.

Slots are not stored as rows. A doctor has working hours and working days;
a slot is free when it is inside those hours, not in the past, and not booked.
"""

import os
import random
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from typing import Iterator

from app.config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS doctors (
    id           TEXT PRIMARY KEY,
    name         TEXT NOT NULL,
    specialty    TEXT NOT NULL,
    room         TEXT NOT NULL,
    start_time   TEXT NOT NULL,          -- HH:MM
    end_time     TEXT NOT NULL,          -- HH:MM (exclusive)
    slot_minutes INTEGER NOT NULL,
    work_days    TEXT NOT NULL           -- weekday digits, Mon=0 .. Sun=6
);

CREATE TABLE IF NOT EXISTS appointments (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id     TEXT NOT NULL REFERENCES doctors(id),
    date          TEXT NOT NULL,         -- YYYY-MM-DD
    time          TEXT NOT NULL,         -- HH:MM
    patient_name  TEXT NOT NULL,
    phone         TEXT NOT NULL,         -- 10 digits, normalised
    status        TEXT NOT NULL DEFAULT 'booked' CHECK (status IN ('booked', 'cancelled')),
    source        TEXT NOT NULL DEFAULT 'voice',
    created_at    TEXT NOT NULL,
    cancelled_at  TEXT
);

-- the database itself refuses a second booking for the same doctor/slot
CREATE UNIQUE INDEX IF NOT EXISTS uniq_active_slot
    ON appointments(doctor_id, date, time) WHERE status = 'booked';
CREATE INDEX IF NOT EXISTS idx_appointments_phone ON appointments(phone);

CREATE TABLE IF NOT EXISTS activity (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    kind           TEXT NOT NULL,        -- booked | cancelled
    appointment_id INTEGER NOT NULL REFERENCES appointments(id),
    source         TEXT NOT NULL,        -- voice | dashboard | seed
    created_at     TEXT NOT NULL
);
"""

DOCTORS = [
    # id, name, specialty, room, start, end, slot minutes, working days
    ("D1", "Dr. Ananya Rao", "General Physician", "101", "09:00", "13:00", 30, "0123456"),
    ("D2", "Dr. Vikram Mehta", "Cardiology", "204", "10:00", "14:00", 30, "01234"),
    ("D3", "Dr. Priya Nair", "Cardiology", "206", "15:00", "18:00", 30, "135"),
    ("D4", "Dr. Sara Thomas", "Dermatology", "112", "14:00", "18:00", 30, "01235"),
    ("D5", "Dr. Arjun Iyer", "Pediatrics", "108", "09:30", "12:30", 30, "012345"),
    ("D6", "Dr. Meera Kapoor", "Orthopedics", "210", "15:00", "19:00", 30, "1345"),
    ("D7", "Dr. Rahul Sen", "ENT", "115", "11:00", "15:00", 30, "02456"),
]

SEED_APPOINTMENTS = [
    # doctor, days from today, slot index into that day's free slots, name, phone
    ("D1", 0, 3, "Kiran Patel", "9876501234"),
    ("D2", 1, 2, "Fatima Sheikh", "9123456780"),
    ("D4", 1, 4, "Rohan Das", "9988776655"),
    ("D5", 2, 1, "Neha Gupta", "9012345678"),
    ("D1", 3, 0, "Aditya Nair", "9090909090"),
    ("D7", 4, 2, "Ishaan Verma", "9812312345"),
]


# Share of each day's slots pre-filled with demo bookings (today first, tapering off).
# Tests set this to 0 so they only see SEED_APPOINTMENTS.
DEMO_FILL = (0.45, 0.35, 0.3, 0.22, 0.18, 0.14, 0.1)

PATIENT_NAMES = [
    "Aarav Sharma", "Diya Menon", "Vihaan Reddy", "Ananya Iyer", "Kabir Malhotra", "Meera Pillai", "Arjun Bose",
    "Saanvi Joshi", "Reyansh Gupta", "Ira Kulkarni", "Vivaan Chatterjee", "Myra Desai", "Advik Nair", "Kiara Shah",
    "Ayaan Khan", "Tara Bhatt", "Dhruv Agarwal", "Anika Rao", "Rudra Mishra", "Navya Banerjee", "Shaurya Kapoor",
    "Pari Hegde", "Atharv Jain", "Riya Das", "Krish Saxena", "Aadhya Mukherjee", "Yash Thakur", "Sara D'Souza",
    "Neil Fernandes", "Zoya Qureshi", "Om Prakash", "Lakshmi Narayan", "Farhan Ali", "Pooja Venkatesh",
]


def now() -> datetime:
    return datetime.now(settings.tz)


def stamp() -> str:
    return now().isoformat(timespec="seconds")


def _connect() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(settings.db_path) or ".", exist_ok=True)
    conn = sqlite3.connect(settings.db_path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    """A connection that commits on success and rolls back on error."""
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db(reset: bool = False) -> None:
    with get_conn() as conn:
        if reset:
            conn.executescript("DROP TABLE IF EXISTS activity; DROP TABLE IF EXISTS appointments; DROP TABLE IF EXISTS doctors;")
        conn.executescript(SCHEMA)
        if conn.execute("SELECT COUNT(*) FROM doctors").fetchone()[0] == 0:
            conn.executemany("INSERT INTO doctors VALUES (?,?,?,?,?,?,?,?)", DOCTORS)
            _seed(conn)


def _seed(conn: sqlite3.Connection) -> None:
    # imported here to avoid a circular import (services use this module)
    from app.services.availability import free_slots

    today = now().date()
    for n, (doctor_id, offset, index, name, phone) in enumerate(SEED_APPOINTMENTS):
        created = (now() - timedelta(hours=26 - n * 4)).isoformat(timespec="seconds")
        for extra in range(7):  # walk forward until the doctor works that day
            day = today + timedelta(days=offset + extra)
            free = free_slots(conn, doctor_id, day)
            if len(free) > index:
                cur = conn.execute(
                    "INSERT INTO appointments (doctor_id, date, time, patient_name, phone, source, created_at)"
                    " VALUES (?,?,?,?,?,?,?)",
                    (doctor_id, day.isoformat(), free[index], name, phone, "seed", created),
                )
                conn.execute(
                    "INSERT INTO activity (kind, appointment_id, source, created_at) VALUES ('booked', ?, 'seed', ?)",
                    (cur.lastrowid, created),
                )
                break

    if any(DEMO_FILL):
        _seed_demo_bookings(conn, today)


def _seed_demo_bookings(conn: sqlite3.Connection, today) -> None:
    """Fill the week realistically: busier today, lighter later; a few cancellations."""
    from app.services.availability import all_slots, booked_times, get_doctor

    rng = random.Random(7)  # deterministic: the demo looks the same after every reset
    rows = []
    for offset, fill in enumerate(DEMO_FILL):
        day = today + timedelta(days=offset)
        for (doctor_id, *_rest) in DOCTORS:
            doctor = get_doctor(conn, doctor_id)
            taken = booked_times(conn, doctor_id, day)
            for slot in all_slots(doctor, day):
                if slot not in taken and rng.random() < fill:
                    name = rng.choice(PATIENT_NAMES)
                    phone = rng.choice("6789") + "".join(rng.choice("0123456789") for _ in range(9))
                    created = now() - timedelta(minutes=rng.randint(20, 60 * 48))
                    rows.append((created, doctor_id, day.isoformat(), slot, name, phone))

    rows.sort(key=lambda r: r[0])  # activity feed in the order things "happened"
    for created, doctor_id, day, slot, name, phone in rows:
        stamp_ = created.isoformat(timespec="seconds")
        cur = conn.execute(
            "INSERT INTO appointments (doctor_id, date, time, patient_name, phone, source, created_at) VALUES (?,?,?,?,?,?,?)",
            (doctor_id, day, slot, name, phone, "seed", stamp_),
        )
        conn.execute(
            "INSERT INTO activity (kind, appointment_id, source, created_at) VALUES ('booked', ?, 'seed', ?)",
            (cur.lastrowid, stamp_),
        )

    # a handful of cancellations, newest activity last
    future = [r for r in conn.execute("SELECT id, date FROM appointments WHERE date > ?", (today.isoformat(),))]
    for row in rng.sample(future, min(4, len(future))):
        when = (now() - timedelta(minutes=rng.randint(5, 600))).isoformat(timespec="seconds")
        conn.execute("UPDATE appointments SET status='cancelled', cancelled_at=? WHERE id=?", (when, row["id"]))
        conn.execute("INSERT INTO activity (kind, appointment_id, source, created_at) VALUES ('cancelled', ?, 'seed', ?)", (row["id"], when))
