"""The three tools Gemini can call during a voice call.

Pipecat turns each function's signature + docstring into the tool schema the
LLM sees, and routes the LLM's function call back here. Each tool is a thin
adapter: business rules live in app.services, so the REST API and the voice
agent behave identically.
"""

import asyncio
from collections.abc import Callable

from loguru import logger
from pipecat.services.llm_service import FunctionCallParams

from app.database.db import get_conn
from app.services import appointments, availability
from app.services.errors import AppointmentError


async def _run(params: FunctionCallParams, name: str, fn: Callable[[], dict]) -> None:
    """Run a blocking service call off the event loop and hand the result to the LLM."""
    try:
        result = await asyncio.to_thread(fn)
    except AppointmentError as e:
        logger.info(f"{name} -> {e.code}")
        result = e.to_dict()
    except Exception:
        logger.exception(f"{name} failed")
        result = {"ok": False, "error": "internal_error", "message": "Something went wrong on our side. Apologise and offer to try again."}
    await params.result_callback(result)


async def check_doctor_availability(params: FunctionCallParams, doctor: str = "", specialty: str = "", date: str = ""):
    """Look up real free appointment slots. Always call this before offering any time to the caller.

    Args:
        doctor: Doctor's name or part of it, e.g. "Mehta". Empty if the caller didn't name one.
        specialty: Medical specialty, e.g. "cardiology" or "dermatologist". Empty if not given.
        date: Day in YYYY-MM-DD format. Empty to get the next few open days.
    """

    def query():
        with get_conn() as conn:
            return availability.check_availability(conn, doctor=doctor, specialty=specialty, day=date)

    await _run(params, "check_doctor_availability", query)


async def book_appointment(
    params: FunctionCallParams,
    patient_name: str,
    phone_number: str,
    phone_confirmed: bool,
    doctor_id: str,
    date: str,
    time: str,
):
    """Book a slot. Only call after the caller chose a slot returned by check_doctor_availability.

    Args:
        patient_name: The patient's full name.
        phone_number: The caller's 10 digit mobile number, as they said it.
        phone_confirmed: True only after you read the number back and the caller said it is correct.
        doctor_id: The doctor_id from check_doctor_availability, e.g. "D2".
        date: Day in YYYY-MM-DD format.
        time: Slot start time in 24 hour HH:MM format, e.g. "14:30".
    """
    await _run(
        params,
        "book_appointment",
        lambda: {
            "ok": True,
            "appointment": appointments.book(
                patient_name=patient_name,
                phone_number=phone_number,
                phone_confirmed=phone_confirmed,
                doctor_id=doctor_id,
                date=date,
                time=time,
                source="voice",
            ),
        },
    )


async def cancel_appointment(
    params: FunctionCallParams,
    phone_number: str,
    phone_confirmed: bool,
    appointment_id: int = 0,
    cancel_confirmed: bool = False,
):
    """Cancel the caller's appointment, found by their phone number. Works in two steps.

    First call with cancel_confirmed false: returns the caller's upcoming appointments and changes nothing.
    Tell the caller what you found, ask which one to cancel and get a clear yes.
    Then call again with that appointment_id and cancel_confirmed true.

    Args:
        phone_number: The caller's 10 digit mobile number, as they said it.
        phone_confirmed: True only after you read the number back and the caller said it is correct.
        appointment_id: The id of the appointment to cancel, from the first call. 0 on the first call.
        cancel_confirmed: True only after the caller confirmed which appointment to cancel.
    """
    await _run(
        params,
        "cancel_appointment",
        lambda: appointments.cancel(
            phone_number=phone_number,
            phone_confirmed=phone_confirmed,
            appointment_id=appointment_id,
            cancel_confirmed=cancel_confirmed,
            source="voice",
        ),
    )


TOOLS = [check_doctor_availability, book_appointment, cancel_appointment]
