"""In-process pub/sub that feeds the dashboard's Server-Sent Events stream.

Publishers may run on the event loop (voice tools) or in a worker thread
(sync code), so delivery always goes through loop.call_soon_threadsafe.
"""

import asyncio
import json
from typing import Any


class EventBus:
    def __init__(self) -> None:
        self._subscribers: set[asyncio.Queue] = set()
        self._loop: asyncio.AbstractEventLoop | None = None

    def bind(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def subscribe(self) -> asyncio.Queue:
        queue: asyncio.Queue = asyncio.Queue(maxsize=100)
        self._subscribers.add(queue)
        return queue

    def unsubscribe(self, queue: asyncio.Queue) -> None:
        self._subscribers.discard(queue)

    def publish(self, event_type: str, payload: dict[str, Any]) -> None:
        if not self._loop or not self._subscribers:
            return
        message = json.dumps({"type": event_type, **payload}, default=str)
        for queue in list(self._subscribers):
            self._loop.call_soon_threadsafe(self._offer, queue, message)

    @staticmethod
    def _offer(queue: asyncio.Queue, message: str) -> None:
        if queue.full():  # a stalled browser tab shouldn't grow memory forever
            queue.get_nowait()
        queue.put_nowait(message)


bus = EventBus()
