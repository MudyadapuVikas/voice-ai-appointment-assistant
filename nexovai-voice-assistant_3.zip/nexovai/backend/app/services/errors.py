class AppointmentError(Exception):
    """A business-rule failure the caller can be told about (not a crash).

    `code` is stable and machine-readable (used by the API and the LLM);
    `message` is a plain sentence the agent can paraphrase to the caller.
    """

    def __init__(self, code: str, message: str, **details):
        super().__init__(message)
        self.code = code
        self.message = message
        self.details = details

    def to_dict(self) -> dict:
        return {"ok": False, "error": self.code, "message": self.message, **self.details}
