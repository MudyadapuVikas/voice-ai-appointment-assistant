"""Booking, lookup and cancellation. Used by both the voice tools and the REST API."""

import sqlite3
from datetime import datetime

from app.database.db import get_conn, now, stamp
from app.services import availability
from app.services.errors import AppointmentError
from app.services.events import bus
from app.services.phone import require_phone, spoken_form

APPOINTMENT_SQL = """
    SELECT a.*, d.name AS doctor_name, d.specialty, d.room
    FROM appointments a JOIN doctors d ON d.id = a.doctor_id
"""


def _row_to_dict(row: sqlite3.Row) -> dict:
    item = {k: row[k] for k in row.keys()}
    # "completed" is derived: a booking whose time has passed
    if item["status"] == "booked":
        day = datetime.strptime(item["date"], "%Y-%m-%d").date()
        if availability.is_past(day, item["time"]):
            item["status"] = "completed"
    return item


def get_appointment(conn: sqlite3.Connection, appointment_id: int) -> dict:
    row = conn.execute(f"{APPOINTMENT_SQL} WHERE a.id = ?", (appointment_id,)).fetchone()
    if not row:
        raise AppointmentError("unknown_appointment", f"There is no appointment #{appointment_id}.")
    return _row_to_dict(row)


def list_appointments(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(f"{APPOINTMENT_SQL} ORDER BY a.date, a.time, a.id").fetchall()
    return [_row_to_dict(r) for r in rows]


def upcoming_for_phone(conn: sqlite3.Connection, phone: str) -> list[dict]:
    return [a for a in list_appointments(conn) if a["phone"] == phone and a["status"] == "booked"]


def _record(conn: sqlite3.Connection, kind: str, appointment: dict, source: str) -> None:
    conn.execute(
        "INSERT INTO activity (kind, appointment_id, source, created_at) VALUES (?,?,?,?)",
        (kind, appointment["id"], source, stamp()),
    )


def _require_confirmation(phone: str, confirmed: bool) -> None:
    if not confirmed:
        raise AppointmentError(
            "phone_not_confirmed",
            f"Read the number back as '{spoken_form(phone)}' and wait for the caller to say yes before calling again with phone_confirmed true.",
            phone_to_read_back=spoken_form(phone),
        )


# ---------------------------------------------------------------- booking


def book(
    *,
    patient_name: str,
    phone_number: str,
    doctor_id: str,
    date: str,
    time: str,
    phone_confirmed: bool,
    source: str = "voice",
) -> dict:
    phone = require_phone(phone_number)
    _require_confirmation(phone, phone_confirmed)

    name = " ".join((patient_name or "").split()).title()
    if len(name) < 2:
        raise AppointmentError("missing_name", "Ask the caller for the patient's name.")

    day = availability.parse_date(date)
    hhmm = availability.parse_time(time)

    with get_conn() as conn:
        doctor = availability.get_doctor(conn, doctor_id)
        free = availability.free_slots(conn, doctor["id"], day)
        if hhmm not in free:
            raise AppointmentError(
                "slot_unavailable",
                f"{doctor['name']} is not free at {hhmm} on {day:%A %d %B}.",
                free_slots_that_day=free,
                next_available=None if free else availability.next_available(conn, doctor["id"], day),
            )
        try:
            cur = conn.execute(
                "INSERT INTO appointments (doctor_id, date, time, patient_name, phone, source, created_at)"
                " VALUES (?,?,?,?,?,?,?)",
                (doctor["id"], day.isoformat(), hhmm, name, phone, source, stamp()),
            )
        except sqlite3.IntegrityError:
            # two callers raced for the same slot: the unique index decides
            raise AppointmentError("slot_unavailable", "That slot was just taken. Offer another time.") from None
        appointment = get_appointment(conn, cur.lastrowid)
        _record(conn, "booked", appointment, source)

    bus.publish("appointment.booked", {"appointment": appointment, "source": source})
    return appointment


# ---------------------------------------------------------------- cancelling


def cancel(
    *,
    phone_number: str,
    phone_confirmed: bool,
    appointment_id: int = 0,
    cancel_confirmed: bool = False,
    source: str = "voice",
) -> dict:
    """Two-step cancel.

    Step 1 (cancel_confirmed=False): returns the caller's upcoming appointments, changes nothing.
    Step 2 (cancel_confirmed=True + appointment_id): cancels that appointment.
    """
    phone = require_phone(phone_number)
    _require_confirmation(phone, phone_confirmed)

    with get_conn() as conn:
        upcoming = upcoming_for_phone(conn, phone)
        if not upcoming:
            raise AppointmentError("no_appointments", f"There are no upcoming appointments for {spoken_form(phone)}.")

        if not cancel_confirmed or not appointment_id:
            return {
                "ok": True,
                "cancelled": None,
                "needs_confirmation": True,
                "appointments": upcoming,
                "message": "Tell the caller which appointment(s) you found and ask which one to cancel. "
                "Then call again with appointment_id and cancel_confirmed true.",
            }

        target = next((a for a in upcoming if a["id"] == appointment_id), None)
        if not target:
            raise AppointmentError(
                "unknown_appointment",
                "That appointment is not an upcoming booking for this phone number.",
                appointments=upcoming,
            )

        conn.execute(
            "UPDATE appointments SET status = 'cancelled', cancelled_at = ? WHERE id = ?",
            (stamp(), target["id"]),
        )
        appointment = get_appointment(conn, target["id"])
        _record(conn, "cancelled", appointment, source)

    bus.publish("appointment.cancelled", {"appointment": appointment, "source": source})
    return {"ok": True, "cancelled": appointment, "needs_confirmation": False}


# ---------------------------------------------------------------- dashboard


def stats(conn: sqlite3.Connection) -> dict:
    items = list_appointments(conn)
    today = now().date().isoformat()
    working_today = [d for d in availability.list_doctors(conn) if availability.all_slots(d, now().date())]
    free_today = sum(len(availability.free_slots(conn, d["id"], now().date())) for d in working_today)
    return {
        "total": sum(1 for a in items if a["status"] != "cancelled"),
        "today": sum(1 for a in items if a["date"] == today and a["status"] != "cancelled"),
        "upcoming": sum(1 for a in items if a["status"] == "booked"),
        "completed": sum(1 for a in items if a["status"] == "completed"),
        "cancelled": sum(1 for a in items if a["status"] == "cancelled"),
        "doctors_total": len(availability.list_doctors(conn)),
        "doctors_today": len(working_today),
        "free_slots_today": free_today,
    }


def activity(conn: sqlite3.Connection, limit: int = 50) -> list[dict]:
    rows = conn.execute(
        """
        SELECT ac.id, ac.kind, ac.source, ac.created_at, ac.appointment_id,
               a.patient_name, a.phone, a.date, a.time, d.name AS doctor_name, d.specialty
        FROM activity ac
        JOIN appointments a ON a.id = ac.appointment_id
        JOIN doctors d ON d.id = a.doctor_id
        ORDER BY ac.created_at DESC, ac.id DESC LIMIT ?
        """,
        (limit,),
    ).fetchall()
    return [{k: r[k] for k in r.keys()} for r in rows]
