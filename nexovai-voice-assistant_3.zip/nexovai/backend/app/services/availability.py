"""Doctors, working days and free slots."""

import sqlite3
from datetime import date, datetime, timedelta

from app.database.db import now
from app.services.errors import AppointmentError

DAYS_AHEAD = 7  # bookings are open for today + the next 6 days


def booking_window() -> list[date]:
    today = now().date()
    return [today + timedelta(days=i) for i in range(DAYS_AHEAD)]


def parse_date(value: str | None) -> date:
    """Accepts YYYY-MM-DD, 'today' or 'tomorrow'. Must be inside the booking window."""
    text = (value or "").strip().lower()
    today = now().date()
    if text == "today":
        day = today
    elif text == "tomorrow":
        day = today + timedelta(days=1)
    else:
        try:
            day = datetime.strptime(text, "%Y-%m-%d").date()
        except ValueError:
            raise AppointmentError("invalid_date", f"'{value}' is not a date. Use YYYY-MM-DD.") from None
    if day < today:
        raise AppointmentError("date_in_past", "That date has already passed.")
    if day not in booking_window():
        raise AppointmentError(
            "date_out_of_range",
            f"Bookings are open only until {booking_window()[-1]:%A %d %B}.",
        )
    return day


def parse_time(value: str | None) -> str:
    text = (value or "").strip()
    for fmt in ("%H:%M", "%H.%M", "%I:%M %p", "%I %p", "%I:%M%p", "%I%p"):
        try:
            return datetime.strptime(text.upper(), fmt).strftime("%H:%M")
        except ValueError:
            continue
    raise AppointmentError("invalid_time", f"'{value}' is not a time. Use 24 hour HH:MM.")


def list_doctors(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM doctors ORDER BY specialty, name").fetchall()


def get_doctor(conn: sqlite3.Connection, doctor_id: str) -> sqlite3.Row:
    row = conn.execute("SELECT * FROM doctors WHERE id = ?", ((doctor_id or "").strip().upper(),)).fetchone()
    if not row:
        raise AppointmentError("unknown_doctor", f"There is no doctor with id '{doctor_id}'.")
    return row


def find_doctors(conn: sqlite3.Connection, doctor: str = "", specialty: str = "") -> list[sqlite3.Row]:
    """Case-insensitive match on id, any part of the name, or the specialty."""

    def clean(s: str) -> str:
        s = s.lower().replace("dr.", " ").replace("doctor", " ")
        return " ".join(s.split())

    name_q, spec_q = clean(doctor or ""), clean(specialty or "")
    # callers say "cardiologist", "dermatologist", "paediatrician": match on the stem
    spec_q = spec_q.removesuffix("s")
    for suffix in ("ologist", "ician", "ist"):
        if spec_q.endswith(suffix):
            spec_q = spec_q[: -len(suffix)]
            break
    spec_q = spec_q.replace("paed", "ped")

    result = []
    for d in list_doctors(conn):
        if name_q and not (name_q == d["id"].lower() or all(part in d["name"].lower() for part in name_q.split())):
            continue
        if spec_q and spec_q not in d["specialty"].lower():
            continue
        result.append(d)
    return result


def all_slots(doctor: sqlite3.Row, day: date) -> list[str]:
    if str(day.weekday()) not in doctor["work_days"]:
        return []
    cursor = datetime.combine(day, datetime.strptime(doctor["start_time"], "%H:%M").time())
    end = datetime.combine(day, datetime.strptime(doctor["end_time"], "%H:%M").time())
    slots = []
    while cursor < end:
        slots.append(cursor.strftime("%H:%M"))
        cursor += timedelta(minutes=doctor["slot_minutes"])
    return slots


def is_past(day: date, hhmm: str) -> bool:
    current = now()
    slot = datetime.combine(day, datetime.strptime(hhmm, "%H:%M").time(), tzinfo=current.tzinfo)
    return slot <= current


def booked_times(conn: sqlite3.Connection, doctor_id: str, day: date) -> set[str]:
    rows = conn.execute(
        "SELECT time FROM appointments WHERE doctor_id = ? AND date = ? AND status = 'booked'",
        (doctor_id, day.isoformat()),
    )
    return {r["time"] for r in rows}


def free_slots(conn: sqlite3.Connection, doctor_id: str, day: date) -> list[str]:
    doctor = get_doctor(conn, doctor_id)
    taken = booked_times(conn, doctor_id, day)
    return [t for t in all_slots(doctor, day) if t not in taken and not is_past(day, t)]


def check_availability(conn: sqlite3.Connection, doctor: str = "", specialty: str = "", day: str = "") -> dict:
    """What the voice tool and the API return. Never invents slots: everything comes from the DB."""
    doctors = find_doctors(conn, doctor, specialty)
    if not doctors:
        known = sorted({d["specialty"] for d in list_doctors(conn)})
        raise AppointmentError(
            "no_matching_doctor",
            "No doctor matches that request.",
            specialties=known,
            doctors=[d["name"] for d in list_doctors(conn)],
        )

    days = [parse_date(day)] if day else booking_window()
    results = []
    for d in doctors:
        open_days = []
        for current in days:
            slots = free_slots(conn, d["id"], current)
            if slots:
                open_days.append({"date": current.isoformat(), "weekday": current.strftime("%A"), "free_slots": slots})
            if not day and len(open_days) == 3:  # keep the LLM context small for open-ended searches
                break
        entry = {
            "doctor_id": d["id"],
            "name": d["name"],
            "specialty": d["specialty"],
            "availability": open_days,
        }
        if day and not open_days:
            entry["works_that_day"] = bool(all_slots(d, days[0]))
            entry["next_available"] = next_available(conn, d["id"], after=days[0])
        results.append(entry)

    any_free = any(r["availability"] for r in results)
    return {"ok": True, "any_free": any_free, "doctors": results}


def next_available(conn: sqlite3.Connection, doctor_id: str, after: date) -> dict | None:
    for current in booking_window():
        if current <= after:
            continue
        slots = free_slots(conn, doctor_id, current)
        if slots:
            return {"date": current.isoformat(), "weekday": current.strftime("%A"), "first_slots": slots[:3]}
    return None


def schedule(conn: sqlite3.Connection) -> dict:
    """Doctors x days x slots with state, for the dashboard."""
    days = booking_window()
    out = []
    for d in list_doctors(conn):
        per_day = {}
        for current in days:
            taken = booked_times(conn, d["id"], current)
            per_day[current.isoformat()] = [
                {"time": t, "state": "booked" if t in taken else ("past" if is_past(current, t) else "free")}
                for t in all_slots(d, current)
            ]
        out.append(
            {
                "id": d["id"],
                "name": d["name"],
                "specialty": d["specialty"],
                "room": d["room"],
                "start_time": d["start_time"],
                "end_time": d["end_time"],
                "work_days": [int(x) for x in d["work_days"]],
                "slots": per_day,
            }
        )
    return {"today": now().date().isoformat(), "days": [d.isoformat() for d in days], "doctors": out}
