"""Phone numbers arrive as speech-to-text output, so they can be digits, words or a mix."""

import re

from app.services.errors import AppointmentError

WORD_DIGITS = {
    "zero": "0", "oh": "0", "o": "0", "one": "1", "two": "2", "to": "2", "too": "2",
    "three": "3", "four": "4", "for": "4", "five": "5", "six": "6", "seven": "7",
    "eight": "8", "nine": "9",
}
REPEAT = {"double": 2, "triple": 3}


def normalize_phone(raw: str | None) -> str | None:
    """Return a 10-digit Indian mobile number, or None if it can't be one.

    Accepts "98480 12345", "+91 98480-12345", "nine eight four ...",
    "double five", and a leading 0 or 91.
    """
    if not raw:
        return None
    tokens = re.findall(r"[a-z]+|\d+", raw.lower())
    digits, repeat = "", 1
    for token in tokens:
        if token in REPEAT:
            repeat = REPEAT[token]
            continue
        value = token if token.isdigit() else WORD_DIGITS.get(token, "")
        if value:
            # "double 5" repeats one digit; "double 55" is ambiguous, keep as said
            digits += value * repeat if len(value) == 1 else value
        repeat = 1
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    if len(digits) != 10 or digits[0] not in "6789":
        return None
    return digits


def require_phone(raw: str | None) -> str:
    phone = normalize_phone(raw)
    if not phone:
        raise AppointmentError(
            "invalid_phone",
            "That doesn't sound like a valid 10 digit mobile number. Ask the caller to say it again slowly.",
        )
    return phone


def spoken_form(phone: str) -> str:
    """How the agent should read the number back: '98480 12345'."""
    return f"{phone[:5]} {phone[5:]}"


def mask(phone: str) -> str:
    return f"{phone[:2]}••• ••{phone[-3:]}"
