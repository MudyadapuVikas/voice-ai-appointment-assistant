import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// The FastAPI backend runs on :7860. Proxying /api keeps the browser on one
// origin, so WebRTC signalling, REST and the SSE stream need no CORS setup.
declare const process: { env: Record<string, string | undefined> };
const backend = `http://127.0.0.1:${process.env.VITE_BACKEND_PORT ?? "7860"}`;

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: { proxy: { "/api": backend } },
  preview: { proxy: { "/api": backend } },
});
