import { useCallback, useEffect, useState } from "react";
import { Shell, type Route } from "./components/layout/Shell";
import { PhoneCall, type CallConfirmation } from "./components/call/PhoneCall";
import { Toasts, type Toast } from "./components/ui/Toasts";
import { useClinicData } from "./hooks/useClinicData";
import { useVoiceCall } from "./hooks/useVoiceCall";
import { api, type LiveEvent } from "./lib/api";
import { playChime } from "./lib/sounds";
import { clock12, relativeDay } from "./lib/format";
import { Overview } from "./pages/Overview";
import { Doctors } from "./pages/Doctors";
import { Appointments } from "./pages/Appointments";
import { ActivityPage } from "./pages/ActivityPage";

const ROUTES: Route[] = ["overview", "doctors", "appointments", "activity"];
const routeFromHash = (): Route => {
  const r = window.location.hash.replace("#/", "") as Route;
  return ROUTES.includes(r) ? r : "overview";
};

let toastId = 0;

export default function App() {
  const [route, setRoute] = useState<Route>(routeFromHash);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmation, setConfirmation] = useState<CallConfirmation | null>(null);
  const call = useVoiceCall();

  useEffect(() => {
    const onHash = () => setRoute(routeFromHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = (r: Route) => {
    window.location.hash = `/${r}`;
    window.scrollTo({ top: 0 });
  };

  // every booking/cancellation, from the voice agent or the desk, arrives here over SSE
  const onLiveEvent = useCallback((event: LiveEvent) => {
    if (event.type === "data.reset") return;
    const a = event.appointment;
    const kind = event.type === "appointment.booked" ? "booked" : "cancelled";
    playChime();
    setConfirmation({ kind, appointment: a });
    const id = ++toastId;
    setToasts((t) => [
      ...t.slice(-2),
      {
        id,
        kind,
        title: `${kind === "booked" ? "Booked" : "Cancelled"}${event.source === "voice" ? " by Mira" : ""}`,
        body: `${a.patient_name} · ${a.doctor_name}, ${relativeDay(a.date, new Date().toLocaleDateString("en-CA"))} ${clock12(a.time)}`,
      },
    ]);
    window.setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 6000);
  }, []);

  const data = useClinicData(onLiveEvent);

  const startCall = () => {
    setConfirmation(null);
    if (data.health && !data.health.voice_enabled) {
      call.fail(`Voice is turned off: add ${data.health.missing_credentials.join(" and ")} to the .env file and restart the backend. Desk booking still works without them.`);
      return;
    }
    void call.start();
  };

  const reset = async () => {
    if (!window.confirm("Restore the demo doctors and appointments? Current bookings will be lost.")) return;
    await api.reset();
    await data.refresh();
  };

  const callBusy = call.phase === "connecting" || call.phase === "live";

  return (
    <>
      <Shell
        route={route}
        onNavigate={navigate}
        counts={{ appointments: data.stats?.upcoming, doctors: data.schedule?.doctors.length }}
        health={data.health}
        online={data.online}
        live={data.live}
        callPhase={call.phase}
        callStartedAt={call.startedAt}
        onCall={startCall}
        onReset={reset}
      >
        {route === "overview" && <Overview data={data} onNavigate={navigate} onCall={startCall} callBusy={callBusy} />}
        {route === "doctors" && <Doctors data={data} />}
        {route === "appointments" && <Appointments data={data} />}
        {route === "activity" && <ActivityPage data={data} />}
      </Shell>
      <Toasts toasts={toasts} onDismiss={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
      <PhoneCall call={call} confirmation={callBusy || call.phase === "ended" ? confirmation : null} />
    </>
  );
}
