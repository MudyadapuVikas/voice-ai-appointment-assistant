import { useCallback, useEffect, useRef, useState } from "react";
import { PipecatClient, type BotOutputData, type Participant, type UserInputData } from "@pipecat-ai/client-js";
import { SmallWebRTCTransport } from "@pipecat-ai/small-webrtc-transport";
import { playConnected, playHangup, startRinging } from "../lib/sounds";
import { MicMediaManager } from "../lib/micMediaManager";

export type CallPhase = "idle" | "connecting" | "live" | "ended" | "error";
export type AgentState = "listening" | "user-speaking" | "thinking" | "speaking" | "working";

export type Segment = { id: string; text: string; spoken: number };
export type TranscriptLine =
  | { kind: "user"; id: string; text: string; interim: string; open: boolean }
  | { kind: "agent"; id: string; segments: Segment[]; open: boolean; interrupted?: boolean };

let seq = 0;
const nextId = () => `t${++seq}`;

const closeLast = (lines: TranscriptLine[]): TranscriptLine[] => {
  const last = lines.at(-1);
  return last?.open ? [...lines.slice(0, -1), { ...last, open: false }] : lines;
};

/**
 * Owns one Pipecat browser client per call: WebRTC connect/disconnect, mic,
 * the agent's audio element, the live transcript and the agent's state.
 */
export function useVoiceCall() {
  const [phase, setPhase] = useState<CallPhase>("idle");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [lines, setLines] = useState<TranscriptLine[]>([]);
  const [tool, setTool] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState<"user" | "agent" | null>(null);
  const [awaitingReply, setAwaitingReply] = useState(false);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [endedAt, setEndedAt] = useState<number | null>(null);

  const client = useRef<PipecatClient | null>(null);
  const audioEl = useRef<HTMLAudioElement | null>(null);
  const audioCtx = useRef<AudioContext | null>(null);
  const analysers = useRef<{ mic?: AnalyserNode; agent?: AnalyserNode }>({});
  const stopRing = useRef<(() => void) | null>(null);
  const phaseRef = useRef<CallPhase>("idle");

  const go = (p: CallPhase) => {
    phaseRef.current = p;
    setPhase(p);
  };

  const attachAnalyser = (track: MediaStreamTrack, who: "mic" | "agent") => {
    const ctx = (audioCtx.current ??= new AudioContext());
    void ctx.resume();
    const node = ctx.createAnalyser();
    node.fftSize = 256;
    node.smoothingTimeConstant = 0.75;
    ctx.createMediaStreamSource(new MediaStream([track])).connect(node);
    analysers.current[who] = node;
  };

  const onUserInput = (d: UserInputData) => {
    if (!d.text?.trim()) return;
    setLines((prev) => {
      const last = prev.at(-1);
      if (last?.kind === "user" && last.open) {
        const updated = d.final ? { ...last, text: `${last.text} ${d.text}`.trim(), interim: "" } : { ...last, interim: d.text };
        return [...prev.slice(0, -1), updated];
      }
      const line: TranscriptLine = { kind: "user", id: nextId(), text: d.final ? d.text : "", interim: d.final ? "" : d.text, open: true };
      return [...closeLast(prev), line];
    });
  };

  // Agent text arrives per sentence ("new"), then word-by-word progress as it is spoken.
  const onBotOutput = (d: BotOutputData) => {
    const type = d.output_type ?? "sentence";
    if (!["sentence", "word", "token"].includes(type)) return;
    const progress = d.spoken_progress;
    const full = progress ? progress.accumulated_text + progress.remaining_text : d.text;
    if (!full.trim()) return;
    const spoken =
      d.will_be_spoken === false ? full.length : progress ? progress.accumulated_text.length : d.spoken_status === "completed" ? full.length : 0;
    const segId = String(d.segment_id ?? nextId());
    setAwaitingReply(false);

    setLines((prev) => {
      for (let i = prev.length - 1; i >= Math.max(0, prev.length - 3); i--) {
        const line = prev[i];
        if (line.kind === "agent" && line.segments.some((s) => s.id === segId)) {
          const segments = line.segments.map((s) => (s.id === segId ? { ...s, text: full, spoken: Math.max(s.spoken, spoken) } : s));
          return prev.map((x, j) => (j === i ? { ...line, segments } : x));
        }
      }
      const last = prev.at(-1);
      const segment = { id: segId, text: full, spoken };
      if (last?.kind === "agent" && last.open) return [...prev.slice(0, -1), { ...last, segments: [...last.segments, segment] }];
      return [...closeLast(prev), { kind: "agent", id: nextId(), segments: [segment], open: true }];
    });
  };

  const onInterrupted = () =>
    setLines((prev) => {
      const last = prev.at(-1);
      if (last?.kind !== "agent") return prev;
      // Pipecat also signals an interruption when the caller simply starts the next turn;
      // only mark the bubble as cut off if some of it really went unsaid.
      if (last.segments.every((s) => s.spoken >= s.text.length)) return prev;
      const segments = last.segments.map((s) => ({ ...s, text: s.text.slice(0, s.spoken).trimEnd() })).filter((s) => s.text);
      return [...prev.slice(0, -1), { ...last, segments, open: false, interrupted: true }];
    });

  const teardown = () => {
    stopRing.current?.();
    stopRing.current = null;
    analysers.current = {};
    void audioCtx.current?.close().catch(() => {});
    audioCtx.current = null;
    if (audioEl.current) audioEl.current.srcObject = null;
    client.current = null;
    setTool(null);
    setSpeaker(null);
    setAwaitingReply(false);
  };

  const finish = useCallback(() => {
    if (phaseRef.current === "connecting" || phaseRef.current === "live") {
      playHangup();
      setEndedAt(Date.now());
      go("ended");
    }
    teardown();
  }, []);

  const start = useCallback(async () => {
    if (phaseRef.current === "connecting" || phaseRef.current === "live") return;
    setLines([]);
    setError(null);
    setNotice(null);
    setMuted(false);
    setStartedAt(null);
    setEndedAt(null);
    go("connecting");
    stopRing.current = startRinging();
    audioEl.current ??= Object.assign(new Audio(), { autoplay: true });

    const pc = new PipecatClient({
      transport: new SmallWebRTCTransport({ mediaManager: new MicMediaManager() }),
      enableMic: true,
      enableCam: false,
      callbacks: {
        onTrackStarted: (track: MediaStreamTrack, participant?: Participant) => {
          if (track.kind !== "audio") return;
          if (participant?.local) return attachAnalyser(track, "mic");
          audioEl.current!.srcObject = new MediaStream([track]);
          void audioEl.current!.play().catch(() => {});
          attachAnalyser(track, "agent");
        },
        onBotReady: () => {
          stopRing.current?.();
          stopRing.current = null;
          playConnected();
          setStartedAt(Date.now());
          go("live");
        },
        onUserInput,
        onBotOutput,
        onBotInterrupted: onInterrupted,
        onUserStartedSpeaking: () => setSpeaker("user"),
        onUserStoppedSpeaking: () => {
          setSpeaker((s) => (s === "user" ? null : s));
          setAwaitingReply(true);
        },
        onBotStartedSpeaking: () => {
          setSpeaker("agent");
          setAwaitingReply(false);
        },
        onBotStoppedSpeaking: () => setSpeaker((s) => (s === "agent" ? null : s)),
        onLLMFunctionCallStarted: (d) => setTool(d.function_name ?? "working"),
        onLLMFunctionCallInProgress: (d) => setTool(d.function_name ?? "working"),
        onLLMFunctionCallStopped: () => window.setTimeout(() => setTool(null), 400),
        onDisconnected: () => finish(),
        // service errors (bad key, quota) are shown inside the phone instead of failing silently
        onError: (m) => {
          const msg = (m.data as { error?: string } | undefined)?.error;
          if (msg) setNotice(msg.length > 150 ? `${msg.slice(0, 150)}…` : msg);
        },
      },
    });
    client.current = pc;

    try {
      const timeout = new Promise<never>((_, reject) => window.setTimeout(() => reject(new Error("timeout")), 25_000));
      await Promise.race([pc.connect({ webrtcRequestParams: { endpoint: "/api/offer" } }), timeout]);
    } catch (e) {
      void pc.disconnect().catch(() => {});
      teardown();
      const denied = e instanceof DOMException && e.name === "NotAllowedError";
      setError(denied ? "Microphone access is blocked. Allow it in the browser and try again." : "Couldn't connect to the voice agent. Check the backend terminal.");
      go("error");
    }
  }, [finish]);

  const fail = useCallback((message: string) => {
    setError(message);
    go("error");
  }, []);

  const end = useCallback(async () => {
    const pc = client.current;
    finish();
    await pc?.disconnect().catch(() => {});
  }, [finish]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      client.current?.enableMic(m);
      return !m;
    });
  }, []);

  const close = useCallback(() => go("idle"), []);

  useEffect(() => () => void client.current?.disconnect(), []);

  const agentState: AgentState = tool
    ? "working"
    : speaker === "agent"
      ? "speaking"
      : speaker === "user"
        ? "user-speaking"
        : awaitingReply
          ? "thinking"
          : "listening";

  return { phase, error, notice, lines, tool, muted, agentState, startedAt, endedAt, analysers, start, end, close, fail, toggleMute };
}

export type VoiceCall = ReturnType<typeof useVoiceCall>;
