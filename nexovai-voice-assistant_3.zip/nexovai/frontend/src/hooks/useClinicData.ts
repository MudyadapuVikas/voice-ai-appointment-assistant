import { useCallback, useEffect, useRef, useState } from "react";
import { api, type Activity, type Appointment, type Health, type LiveEvent, type Schedule, type Stats } from "../lib/api";

export type Highlight = { appointmentId: number; kind: "booked" | "cancelled"; slotKey: string; at: number };

/**
 * Loads everything the dashboard shows and keeps it live:
 * the backend pushes every booking/cancellation (voice or dashboard) over SSE.
 */
export function useClinicData(onEvent?: (e: LiveEvent) => void) {
  const [health, setHealth] = useState<Health | null>(null);
  const [stats, setStats] = useState<Stats | null>(null);
  const [schedule, setSchedule] = useState<Schedule | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [activity, setActivity] = useState<Activity[]>([]);
  const [online, setOnline] = useState(true);
  const [live, setLive] = useState(false);
  const [highlight, setHighlight] = useState<Highlight | null>(null);
  const eventRef = useRef(onEvent);
  eventRef.current = onEvent;

  const refresh = useCallback(async () => {
    try {
      const [h, o, s, a, act] = await Promise.all([api.health(), api.overview(), api.schedule(), api.appointments(), api.activity()]);
      setHealth(h);
      setStats(o.stats);
      setSchedule(s);
      setAppointments(a);
      setActivity(act);
      setOnline(true);
    } catch {
      setOnline(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const poll = window.setInterval(refresh, 60_000); // keeps "past" slots and completed status current
    return () => window.clearInterval(poll);
  }, [refresh]);

  useEffect(() => {
    const source = new EventSource("/api/events");
    let clearTimer = 0;
    source.addEventListener("ready", () => setLive(true));
    source.onerror = () => setLive(false); // EventSource reconnects by itself
    source.onmessage = (msg) => {
      const event = JSON.parse(msg.data) as LiveEvent;
      if (event.type === "appointment.booked" || event.type === "appointment.cancelled") {
        const a = event.appointment;
        setHighlight({
          appointmentId: a.id,
          kind: event.type === "appointment.booked" ? "booked" : "cancelled",
          slotKey: `${a.doctor_id}|${a.date}|${a.time}`,
          at: Date.now(),
        });
        window.clearTimeout(clearTimer);
        clearTimer = window.setTimeout(() => setHighlight(null), 6000);
      }
      eventRef.current?.(event);
      void refresh();
    };
    return () => {
      window.clearTimeout(clearTimer);
      source.close();
    };
  }, [refresh]);

  return { health, stats, schedule, appointments, activity, online, live, highlight, refresh };
}

export type ClinicData = ReturnType<typeof useClinicData>;
