// Call sounds synthesised with Web Audio, so there are no audio files to ship.

let ctx: AudioContext | null = null;
const ac = () => (ctx ??= new AudioContext());

function tone(freqs: number[], start: number, dur: number, gain = 0.06) {
  const a = ac();
  const g = a.createGain();
  g.gain.setValueAtTime(0, start);
  g.gain.linearRampToValueAtTime(gain, start + 0.02);
  g.gain.setValueAtTime(gain, start + dur - 0.03);
  g.gain.linearRampToValueAtTime(0, start + dur);
  g.connect(a.destination);
  for (const f of freqs) {
    const o = a.createOscillator();
    o.frequency.value = f;
    o.connect(g);
    o.start(start);
    o.stop(start + dur);
  }
}

/** Indian/UK style double ring (400+450 Hz, ring-ring, pause). Returns a stop fn. */
export function startRinging(): () => void {
  const a = ac();
  void a.resume();
  const cycle = () => {
    const t = a.currentTime + 0.05;
    tone([400, 450], t, 0.4);
    tone([400, 450], t + 0.6, 0.4);
  };
  cycle();
  const id = window.setInterval(cycle, 3000);
  return () => window.clearInterval(id);
}

export function playConnected() {
  const t = ac().currentTime + 0.02;
  tone([880], t, 0.08, 0.04);
  tone([1320], t + 0.1, 0.12, 0.04);
}

export function playHangup() {
  const t = ac().currentTime + 0.02;
  [620, 480, 360].forEach((f, i) => tone([f], t + i * 0.16, 0.13, 0.05));
}

export function playChime() {
  const t = ac().currentTime + 0.02;
  tone([1046.5], t, 0.18, 0.03);
  tone([1568], t + 0.09, 0.3, 0.025);
}
