export type SlotState = "free" | "booked" | "past";
export type AppointmentStatus = "booked" | "completed" | "cancelled";

export type Doctor = {
  id: string;
  name: string;
  specialty: string;
  room: string;
  start_time: string;
  end_time: string;
  work_days: number[];
  slots: Record<string, { time: string; state: SlotState }[]>;
};

export type Schedule = { today: string; days: string[]; doctors: Doctor[] };

export type Appointment = {
  id: number;
  doctor_id: string;
  doctor_name: string;
  specialty: string;
  room: string;
  date: string;
  time: string;
  patient_name: string;
  phone: string;
  status: AppointmentStatus;
  source: "voice" | "dashboard" | "seed";
  created_at: string;
  cancelled_at: string | null;
};

export type Activity = {
  id: number;
  kind: "booked" | "cancelled";
  source: "voice" | "dashboard" | "seed";
  created_at: string;
  appointment_id: number;
  patient_name: string;
  phone: string;
  date: string;
  time: string;
  doctor_name: string;
  specialty: string;
};

export type Stats = {
  total: number;
  today: number;
  upcoming: number;
  completed: number;
  cancelled: number;
  doctors_total: number;
  doctors_today: number;
  free_slots_today: number;
};

export type Health = { ok: boolean; voice_enabled: boolean; missing_credentials: string[]; llm: string; clinic: string };

export type LiveEvent =
  | { type: "appointment.booked" | "appointment.cancelled"; appointment: Appointment; source: Appointment["source"] }
  | { type: "data.reset" };

/** Error body returned by the backend for business-rule failures. */
export class ApiError extends Error {
  constructor(public code: string, message: string, public details: Record<string, unknown> = {}) {
    super(message);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(path, { headers: { "Content-Type": "application/json" }, ...init });
  } catch {
    throw new ApiError("offline", "Can't reach the backend. Is it running on port 7860?");
  }
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = Array.isArray(body.detail) ? "Please fill in every field." : body.detail;
    throw new ApiError(body.error ?? `http_${res.status}`, body.message ?? detail ?? res.statusText, body);
  }
  return body as T;
}

export const api = {
  health: () => request<Health>("/api/health"),
  overview: () => request<{ stats: Stats; activity: Activity[] }>("/api/overview"),
  schedule: () => request<Schedule>("/api/schedule"),
  appointments: () => request<Appointment[]>("/api/appointments"),
  activity: () => request<Activity[]>("/api/activity"),
  book: (body: { patient_name: string; phone_number: string; doctor_id: string; date: string; time: string }) =>
    request<Appointment>("/api/appointments", { method: "POST", body: JSON.stringify(body) }),
  cancel: (body: { phone_number: string; appointment_id: number; confirm: boolean }) =>
    request<{ cancelled: Appointment | null }>("/api/appointments/cancel", { method: "POST", body: JSON.stringify(body) }),
  reset: () => request<{ ok: boolean }>("/api/demo/reset", { method: "POST" }),
};
