import { WavMediaManager } from "@pipecat-ai/small-webrtc-transport";
import type { Participant, RTVIEventCallbacks, Tracks } from "@pipecat-ai/client-js";

const LOCAL: Participant = { id: "local", name: "You", local: true };

/**
 * Microphone-only media manager for Pipecat's SmallWebRTCTransport.
 *
 * The transport's default (DailyMediaManager) loads a helper bundle from
 * c.daily.co at runtime just to open the mic. This one uses getUserMedia
 * directly, so a call works on networks that block that CDN. The transport
 * still owns the peer connection; it reads our track through tracks().
 *
 * It extends WavMediaManager only to inherit the MediaManager base class
 * (which the package doesn't export on its own); none of the WAV recording or
 * playback is used: the agent's audio arrives as a WebRTC track.
 */
export class MicMediaManager extends WavMediaManager {
  // set by the base class (setClientOptions); `declare` so we don't shadow them
  declare protected _callbacks: RTVIEventCallbacks;
  declare protected _micEnabled: boolean;

  private stream: MediaStream | null = null;
  private mics: MediaDeviceInfo[] = [];
  private selected: MediaDeviceInfo | Record<string, never> = {};

  private get track(): MediaStreamTrack | undefined {
    return this.stream?.getAudioTracks()[0];
  }

  async initialize(): Promise<void> {
    if (this.stream) return;
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        video: false,
      });
    } catch (error) {
      const name = error instanceof DOMException ? error.name : "";
      this._callbacks.onDeviceError?.({
        devices: ["mic"],
        type: name === "NotAllowedError" ? "permissions" : name === "NotFoundError" ? "not-found" : "unknown",
        details: error,
      } as never);
      throw error;
    }
    const track = this.track!;
    track.enabled = this._micEnabled;

    // device labels are only readable once permission has been granted
    this.mics = (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "audioinput");
    this.selected = this.mics.find((m) => m.deviceId === track.getSettings().deviceId) ?? this.mics[0] ?? {};
    this._callbacks.onAvailableMicsUpdated?.(this.mics);
    if ("deviceId" in this.selected) this._callbacks.onMicUpdated?.(this.selected as MediaDeviceInfo);
    this._callbacks.onTrackStarted?.(track, LOCAL);
  }

  async connect(): Promise<void> {}

  async disconnect(): Promise<void> {
    const track = this.track;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    if (track) this._callbacks.onTrackStopped?.(track, LOCAL);
  }

  async interruptBotAudio(): Promise<unknown> {
    return undefined; // agent audio plays from a WebRTC track, nothing is buffered here
  }

  bufferBotAudio(): Int16Array | undefined {
    return undefined;
  }

  async getAllMics(): Promise<MediaDeviceInfo[]> {
    return this.mics;
  }
  async getAllCams(): Promise<MediaDeviceInfo[]> {
    return [];
  }
  async getAllSpeakers(): Promise<MediaDeviceInfo[]> {
    return (await navigator.mediaDevices.enumerateDevices()).filter((d) => d.kind === "audiooutput");
  }

  updateMic(): void {
    console.warn("MicMediaManager: switching microphones mid-call is not supported");
  }
  updateCam(): void {}
  updateSpeaker(): void {}

  get selectedMic(): MediaDeviceInfo | Record<string, never> {
    return this.selected;
  }
  get selectedCam(): Record<string, never> {
    return {};
  }
  get selectedSpeaker(): Record<string, never> {
    return {};
  }

  enableMic(enable: boolean): void {
    this._micEnabled = enable;
    if (this.track) this.track.enabled = enable; // muting keeps the track, so no renegotiation
  }
  enableCam(): void {}
  enableScreenShare(): void {}

  get isMicEnabled(): boolean {
    return this._micEnabled;
  }
  get isCamEnabled(): boolean {
    return false;
  }
  get isSharingScreen(): boolean {
    return false;
  }
  get supportsScreenShare(): boolean {
    return false;
  }
  get mediaSupport() {
    return { mic: true, cam: false, screenShare: false };
  }

  tracks(): Tracks {
    return { local: { audio: this.track } };
  }
}
