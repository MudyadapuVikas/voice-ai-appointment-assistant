const parseDay = (iso: string) => new Date(`${iso}T00:00:00`);

export const weekdayShort = (iso: string) => parseDay(iso).toLocaleDateString("en-IN", { weekday: "short" });
export const dayOfMonth = (iso: string) => parseDay(iso).getDate();
export const monthShort = (iso: string) => parseDay(iso).toLocaleDateString("en-IN", { month: "short" });
export const longDate = (iso: string) =>
  parseDay(iso).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" });

export function relativeDay(iso: string, today: string) {
  const diff = Math.round((parseDay(iso).getTime() - parseDay(today).getTime()) / 86_400_000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Tomorrow";
  if (diff === -1) return "Yesterday";
  return `${weekdayShort(iso)}, ${dayOfMonth(iso)} ${monthShort(iso)}`;
}

/** "14:30" → "2:30" */
export function clock(hhmm: string) {
  const [h, m] = hhmm.split(":").map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, "0")}`;
}
export const meridiem = (hhmm: string) => (Number(hhmm.slice(0, 2)) < 12 ? "AM" : "PM");
export const clock12 = (hhmm: string) => `${clock(hhmm)} ${meridiem(hhmm)}`;

/** 9848012345 → 98480 •••45 — recognisable to staff, not a leak on a shared screen */
export const maskPhone = (p: string) => `${p.slice(0, 5)} •••${p.slice(-2)}`;

export const initials = (name: string) =>
  name
    .replace(/^Dr\.\s*/, "")
    .split(/\s+/)
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

export const callTimer = (secs: number) =>
  `${String(Math.floor(secs / 60)).padStart(2, "0")}:${String(secs % 60).padStart(2, "0")}`;

export function timeAgo(iso: string, now = Date.now()) {
  const secs = Math.max(0, Math.round((now - new Date(iso).getTime()) / 1000));
  if (secs < 45) return "just now";
  const mins = Math.round(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export const cx = (...parts: (string | false | null | undefined)[]) => parts.filter(Boolean).join(" ");
