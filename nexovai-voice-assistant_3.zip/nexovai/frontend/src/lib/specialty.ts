import { Baby, Bone, Ear, HeartPulse, ScanFace, Stethoscope, type LucideIcon } from "lucide-react";

/** One muted tone + icon per specialty, used for avatars and tags. */
const SPECIALTY: Record<string, { icon: LucideIcon; tone: string; dot: string }> = {
  Cardiology: { icon: HeartPulse, tone: "bg-rose-50 text-rose-700 ring-rose-100", dot: "bg-rose-400" },
  Dermatology: { icon: ScanFace, tone: "bg-amber-50 text-amber-700 ring-amber-100", dot: "bg-amber-400" },
  Pediatrics: { icon: Baby, tone: "bg-sky-50 text-sky-700 ring-sky-100", dot: "bg-sky-400" },
  Orthopedics: { icon: Bone, tone: "bg-indigo-50 text-indigo-700 ring-indigo-100", dot: "bg-indigo-400" },
  ENT: { icon: Ear, tone: "bg-violet-50 text-violet-700 ring-violet-100", dot: "bg-violet-400" },
  "General Physician": { icon: Stethoscope, tone: "bg-brand-soft text-brand-2 ring-emerald-100", dot: "bg-brand" },
};

export const specialtyStyle = (name: string) => SPECIALTY[name] ?? SPECIALTY["General Physician"];
