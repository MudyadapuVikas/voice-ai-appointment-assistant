import { useEffect, useMemo, useState, type FormEvent } from "react";
import { AlertCircle, FlaskConical } from "lucide-react";
import { api, ApiError, type Schedule } from "../lib/api";
import { clock12, relativeDay } from "../lib/format";
import { Dialog, Field, inputClass } from "./ui/Dialog";
import { Button } from "./ui/primitives";

/**
 * Demo mode: books through the same backend service the voice agent's
 * book_appointment tool uses, so the workflow can be tested without API keys.
 */
export function DeskBookingDialog({ open, onClose, schedule }: { open: boolean; onClose: () => void; schedule: Schedule | null }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [doctorId, setDoctorId] = useState("");
  const [day, setDay] = useState("");
  const [time, setTime] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open && schedule) {
      setDoctorId((d) => d || schedule.doctors[0].id);
      setDay((d) => d || schedule.today);
      setError(null);
    }
  }, [open, schedule]);

  const free = useMemo(() => {
    const doctor = schedule?.doctors.find((d) => d.id === doctorId);
    return (doctor?.slots[day] ?? []).filter((s) => s.state === "free").map((s) => s.time);
  }, [schedule, doctorId, day]);

  useEffect(() => setTime((t) => (free.includes(t) ? t : free[0] ?? "")), [free]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.book({ patient_name: name, phone_number: phone, doctor_id: doctorId, date: day, time });
      setName("");
      setPhone("");
      onClose();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Booking failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} title="New booking" subtitle="Front-desk entry. Same rules as the voice agent.">
      <form onSubmit={submit} className="space-y-4">
        <div className="flex items-center gap-2 rounded-lg bg-warn-soft px-3 py-2 text-[12px] text-warn">
          <FlaskConical size={14} /> Demo mode — no voice, no API keys needed
        </div>
        <Field label="Patient name">
          <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" required autoFocus />
        </Field>
        <Field label="Mobile number" hint="10 digits. +91 or a leading 0 is fine.">
          <input className={inputClass} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="98480 12345" inputMode="tel" required />
        </Field>
        <Field label="Doctor">
          <select className={inputClass} value={doctorId} onChange={(e) => setDoctorId(e.target.value)}>
            {schedule?.doctors.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} — {d.specialty}
              </option>
            ))}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Day">
            <select className={inputClass} value={day} onChange={(e) => setDay(e.target.value)}>
              {schedule?.days.map((d) => (
                <option key={d} value={d}>
                  {relativeDay(d, schedule.today)}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Time">
            <select className={inputClass} value={time} onChange={(e) => setTime(e.target.value)} disabled={!free.length}>
              {free.length ? free.map((t) => <option key={t} value={t}>{clock12(t)}</option>) : <option>No open slots</option>}
            </select>
          </Field>
        </div>
        {error && (
          <p className="flex items-start gap-2 rounded-lg bg-danger-soft px-3 py-2 text-[12.5px] text-danger">
            <AlertCircle size={14} className="mt-0.5 shrink-0" /> {error}
          </p>
        )}
        <div className="flex justify-end gap-2 pt-1">
          <Button variant="ghost" onClick={onClose}>Cancel</Button>
          <Button variant="primary" type="submit" disabled={busy || !time}>{busy ? "Booking…" : "Book appointment"}</Button>
        </div>
      </form>
    </Dialog>
  );
}
