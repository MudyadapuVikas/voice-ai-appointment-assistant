import type { SlotState } from "../lib/api";
import { clock, clock12, cx } from "../lib/format";

export function SlotChip({ time, state, flash, compact }: { time: string; state: SlotState; flash?: boolean; compact?: boolean }) {
  return (
    <span
      title={`${clock12(time)} · ${state === "free" ? "open" : state}`}
      className={cx(
        "tabular grid place-items-center rounded-md font-mono transition-colors",
        compact ? "h-7 text-[10.5px]" : "h-8 text-[11.5px]",
        state === "free" && "border border-line bg-surface text-ink hover:border-brand hover:text-brand",
        state === "booked" && "bg-ink text-white/40",
        state === "past" && "text-ink-3/70 [background:repeating-linear-gradient(-45deg,transparent_0_4px,var(--color-line-2)_4px_5px)]",
        flash && "slot-pop",
      )}
    >
      {clock(time)}
    </span>
  );
}
