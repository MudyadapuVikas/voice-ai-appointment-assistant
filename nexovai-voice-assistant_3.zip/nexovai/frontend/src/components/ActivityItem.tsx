import { CalendarPlus, CalendarX2 } from "lucide-react";
import type { Activity } from "../lib/api";
import { clock12, cx, relativeDay, timeAgo } from "../lib/format";
import { SourceTag } from "./ui/primitives";

export function ActivityItem({ item, today, fresh, compact }: { item: Activity; today: string; fresh?: boolean; compact?: boolean }) {
  const booked = item.kind === "booked";
  const Icon = booked ? CalendarPlus : CalendarX2;
  return (
    <li
      className={cx(
        "flex gap-3 rounded-lg px-2 py-2.5 -mx-2",
        fresh && (booked ? "animate-flash-ok" : "animate-flash-cx"),
      )}
    >
      <span className={cx("mt-0.5 grid size-7 shrink-0 place-items-center rounded-full", booked ? "bg-brand-soft text-brand" : "bg-danger-soft text-danger")}>
        <Icon size={14} strokeWidth={1.9} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[13px] leading-snug">
          <span className="font-medium">{item.patient_name}</span>
          <span className="text-ink-2"> {booked ? "booked with" : "cancelled with"} </span>
          <span className="font-medium">{item.doctor_name}</span>
        </p>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[12px] text-ink-2">
          <span className="tabular">
            {relativeDay(item.date, today)} · {clock12(item.time)}
          </span>
          {!compact && <span className="text-ink-3">· {item.specialty}</span>}
        </div>
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <span className="tabular font-mono text-[11px] text-ink-3">{timeAgo(item.created_at)}</span>
        <SourceTag source={item.source} />
      </div>
    </li>
  );
}
