import { Fragment, useEffect, useRef, useState } from "react";
import { CalendarCheck2, CalendarX2, Mic, MicOff, Phone, PhoneOff, X } from "lucide-react";
import type { AgentState, TranscriptLine, VoiceCall } from "../../hooks/useVoiceCall";
import type { Appointment } from "../../lib/api";
import { callTimer, clock12, cx, longDate } from "../../lib/format";
import { Waveform } from "./Waveform";

const TOOL_LABEL: Record<string, string> = {
  check_doctor_availability: "Checking the schedule",
  book_appointment: "Booking the slot",
  cancel_appointment: "Looking up the booking",
};

const STATE_LABEL: Record<Exclude<AgentState, "working">, string> = {
  listening: "Listening",
  "user-speaking": "Hearing you",
  thinking: "Thinking",
  speaking: "Speaking",
};

export type CallConfirmation = { kind: "booked" | "cancelled"; appointment: Appointment };

export function PhoneCall({ call, confirmation }: { call: VoiceCall; confirmation: CallConfirmation | null }) {
  const { phase } = call;
  const open = phase !== "idle";
  const [now, setNow] = useState(Date.now());
  const [card, setCard] = useState<CallConfirmation | null>(null);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 500);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => setCard(confirmation), [confirmation]);

  // The booking event arrives before Mira has said it out loud, so keep the card
  // up while she confirms it; it tucks away a few seconds after she finishes,
  // or as soon as the caller starts the next request.
  useEffect(() => {
    if (!card) return;
    if (call.agentState === "user-speaking") return setCard(null);
    if (call.agentState !== "listening") return;
    const id = window.setTimeout(() => setCard(null), 6000);
    return () => window.clearTimeout(id);
  }, [card, call.agentState]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [call.lines]);

  useEffect(() => {
    if (phase !== "ended") return;
    const id = window.setTimeout(call.close, 7000);
    return () => window.clearTimeout(id);
  }, [phase, call.close]);

  const secs = call.startedAt ? Math.floor(((call.endedAt ?? now) - call.startedAt) / 1000) : 0;
  const bigHeader = phase === "connecting" || phase === "error";

  return (
    // On desktop the dashboard stays visible and usable beside the phone, so bookings
    // can be watched landing live; on small screens the phone takes over.
    <div className="pointer-events-none fixed inset-0 z-50 flex items-end justify-end sm:p-6" aria-hidden={!open}>

      <div
        role="dialog"
        aria-label="Call with Mira"
        className={cx(
          "pointer-events-auto relative flex h-dvh w-full flex-col overflow-hidden bg-[#111110] text-[#f3f1ec] transition-all duration-500 ease-[cubic-bezier(.2,.8,.2,1)]",
          "sm:h-[min(720px,calc(100dvh-48px))] sm:w-[360px] sm:rounded-[48px] sm:border-[9px] sm:border-black sm:shadow-[0_0_0_1px_#3b3a36,0_40px_90px_rgba(0,0,0,0.4)]",
          open ? "translate-y-0 scale-100 opacity-100" : "pointer-events-none translate-y-16 scale-95 opacity-0",
        )}
      >
        {/* ambient glow, stronger while Mira talks */}
        <div
          className={cx(
            "pointer-events-none absolute -inset-x-1/3 -top-1/3 h-2/3 rounded-full bg-[radial-gradient(closest-side,rgba(14,124,102,0.45),transparent)] transition-opacity duration-700",
            call.agentState === "speaking" ? "opacity-100" : "opacity-50",
            (phase === "ended" || phase === "error") && "opacity-20",
          )}
        />

        {/* status bar */}
        <div className="relative z-10 hidden items-center justify-between px-6 pt-3 text-[13px] font-semibold sm:flex">
          <span className="tabular">{new Date(now).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })}</span>
          <span className="h-[26px] w-[92px] rounded-full bg-black" />
          <span className="flex items-end gap-[2px]">
            {[4, 6, 8, 10].map((h) => <i key={h} className="w-[3px] rounded-[1px] bg-current" style={{ height: h }} />)}
            <i className="relative ml-1.5 h-[10px] w-5 rounded-[3px] border-[1.5px] border-current after:absolute after:inset-[1px_4px_1px_1px] after:rounded-[1px] after:bg-current" />
          </span>
        </div>

        {/* caller header */}
        <div className={cx("relative z-10 text-center transition-all duration-500", bigHeader ? "pt-24" : "pt-7")}>
          <div
            className={cx(
              "relative mx-auto mb-3 grid place-items-center rounded-full bg-[#2a2925] font-display italic transition-all duration-500",
              bigHeader ? "size-24 text-[44px]" : "size-16 text-[30px]",
              phase === "connecting" && "ripple",
              call.agentState === "speaking" && phase === "live" && "ring-[3px] ring-emerald-400/40",
            )}
          >
            M
          </div>
          <div className="font-display text-[26px] leading-tight">Mira</div>
          <div className="text-[12.5px] text-white/45">Halcyon Clinic · Front desk</div>
          <div className="mt-2 h-5 text-[13px] text-white/60">
            {phase === "connecting" && <span className="fade-pulse">Calling…</span>}
            {phase === "live" && <span className="tabular font-mono">{callTimer(secs)}</span>}
            {phase === "ended" && <>Call ended · <span className="tabular font-mono">{callTimer(secs)}</span></>}
            {phase === "error" && <span className="text-[#f0a596]">Call failed</span>}
          </div>
        </div>

        {(phase === "live" || phase === "ended") && (
          <>
            <div className="relative z-10 px-6 pt-3">
              <Waveform analysers={call.analysers} active={phase === "live"} />
            </div>
            {phase === "live" && <AgentStatus state={call.agentState} tool={call.tool} />}
            {call.notice && <p className="relative z-10 mx-6 mt-2 text-center font-mono text-[10.5px] leading-snug text-[#f0a596]">{call.notice}</p>}
            <div ref={scroller} className="no-scrollbar chat-mask relative z-10 flex flex-1 flex-col gap-1.5 overflow-y-auto px-4 pb-4 pt-3">
              {call.lines.length === 0 && (
                <p className="m-auto max-w-[220px] text-center font-display text-[17px] italic leading-snug text-white/40">
                  Ask for a doctor, a day, or to cancel a booking.
                </p>
              )}
              {call.lines.map((line, i) => (
                <Fragment key={line.id}>
                  <Bubble line={line} showLabel={call.lines[i - 1]?.kind !== line.kind} />
                </Fragment>
              ))}
              {call.agentState === "user-speaking" && call.lines.at(-1)?.kind !== "user" && (
                <div className="typing flex gap-1 self-end rounded-[18px] rounded-br-md bg-[#f3f1ec] px-3.5 py-3">
                  {[0, 1, 2].map((i) => <span key={i} className="size-1.5 rounded-full bg-[#77736a]" />)}
                </div>
              )}
            </div>
          </>
        )}

        {phase === "error" && <p className="relative z-10 mx-8 mt-6 text-center text-[13px] leading-relaxed text-[#f0a596]">{call.error}</p>}

        {card && <ConfirmationTicket card={card} onDismiss={() => setCard(null)} />}

        {/* controls */}
        <div className={cx("relative z-20 flex justify-center gap-10 bg-gradient-to-b from-transparent to-[#111110] to-30% px-6 pb-9 pt-4", phase !== "live" && "mt-auto")}>
          {phase === "live" && (
            <Control label={call.muted ? "Unmute" : "Mute"} onClick={call.toggleMute} active={call.muted}>
              {call.muted ? <MicOff size={22} /> : <Mic size={22} />}
            </Control>
          )}
          {(phase === "connecting" || phase === "live") && (
            <Control label="End" onClick={call.end} tone="end">
              <PhoneOff size={22} />
            </Control>
          )}
          {(phase === "ended" || phase === "error") && (
            <>
              <Control label="Close" onClick={call.close}>
                <X size={22} />
              </Control>
              <Control label="Call again" onClick={call.start} tone="call">
                <Phone size={22} />
              </Control>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function AgentStatus({ state, tool }: { state: AgentState; tool: string | null }) {
  const label = state === "working" ? TOOL_LABEL[tool ?? ""] ?? "Working" : STATE_LABEL[state];
  return (
    <div className="relative z-10 mt-2 flex justify-center">
      <span
        className={cx(
          "agent-status inline-flex items-center gap-2 rounded-full border px-2.5 py-1 font-mono text-[11px] transition-colors",
          state === "working" ? "border-emerald-400/25 bg-emerald-900/40 text-emerald-200" : "border-white/10 bg-white/5 text-white/60",
        )}
      >
        {state === "working" ? (
          <span className="spin size-2.5 rounded-full border-[1.5px] border-emerald-300 border-t-transparent" />
        ) : (
          <span className={cx("size-1.5 rounded-full", state === "speaking" ? "bg-emerald-300" : state === "user-speaking" ? "bg-sky-300" : state === "thinking" ? "fade-pulse bg-amber-200" : "bg-white/50")} />
        )}
        {label}
      </span>
    </div>
  );
}

function Bubble({ line, showLabel }: { line: TranscriptLine; showLabel: boolean }) {
  const label = showLabel && (
    <div className={cx("mb-1 mt-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-white/30", line.kind === "user" ? "self-end" : "self-start")}>
      {line.kind === "user" ? "You" : "Mira"}
    </div>
  );
  if (line.kind === "user") {
    return (
      <>
        {label}
        <div data-role="caller" className="max-w-[84%] animate-rise self-end rounded-[18px] rounded-br-md bg-[#f3f1ec] px-3 py-2 text-[13.5px] leading-snug text-ink">
          {line.text}
          {line.interim && <span className="text-ink-3"> {line.interim}</span>}
        </div>
      </>
    );
  }
  return (
    <>
      {label}
      <div data-role="agent" className="max-w-[86%] animate-rise self-start rounded-[18px] rounded-bl-md bg-[#252420] px-3 py-2 text-[13.5px] leading-snug ring-1 ring-white/5">
        {line.segments.map((s) => (
          <span key={s.id}>
            <span className="transition-colors">{s.text.slice(0, s.spoken)}</span>
            <span className="text-white/35">{s.text.slice(s.spoken)}</span>{" "}
          </span>
        ))}
        {line.interrupted && <span className="text-white/35">—</span>}
      </div>
    </>
  );
}

function ConfirmationTicket({ card, onDismiss }: { card: CallConfirmation; onDismiss: () => void }) {
  const a = card.appointment;
  const booked = card.kind === "booked";
  return (
    <button
      onClick={onDismiss}
      className="absolute inset-x-3.5 bottom-[124px] z-30 animate-rise rounded-2xl bg-[#f6f4ef] p-4 text-left text-ink shadow-[0_18px_40px_rgba(0,0,0,0.45)]"
    >
      <div className="flex items-center justify-between">
        <span className={cx("flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-[0.12em]", booked ? "text-brand" : "text-danger")}>
          {booked ? <CalendarCheck2 size={13} /> : <CalendarX2 size={13} />}
          {booked ? "Confirmed" : "Cancelled"}
        </span>
        <span className="tabular font-mono text-[11px] text-ink-3">#{String(a.id).padStart(4, "0")}</span>
      </div>
      <div className="my-3 border-t border-dashed border-line" />
      <div className={cx("font-display text-[23px] leading-tight", !booked && "line-through decoration-danger/70")}>{a.doctor_name}</div>
      <div className="mt-1 flex items-baseline justify-between text-[13px] text-ink-2">
        <span>{longDate(a.date)}</span>
        <span className="tabular font-mono text-[16px] font-medium text-ink">{clock12(a.time)}</span>
      </div>
      <div className="mt-0.5 text-[12px] text-ink-3">
        {a.patient_name} · {a.specialty}
      </div>
    </button>
  );
}

function Control({ children, label, onClick, active, tone }: { children: React.ReactNode; label: string; onClick: () => void; active?: boolean; tone?: "end" | "call" }) {
  return (
    <button onClick={onClick} className="group grid justify-items-center gap-2 text-[11.5px] text-white/65">
      <span
        className={cx(
          "grid size-[62px] place-items-center rounded-full transition-transform group-hover:scale-105 group-active:scale-95",
          tone === "end" ? "bg-[#dc4430] text-white" : tone === "call" ? "bg-[#1f9a6c] text-white" : active ? "bg-[#f3f1ec] text-ink" : "bg-[#2a2925] text-white",
        )}
      >
        {children}
      </span>
      {label}
    </button>
  );
}
