import { useEffect, useRef } from "react";
import type { VoiceCall } from "../../hooks/useVoiceCall";

const BARS = 40;

/**
 * Live waveform drawn from Web Audio analysers on the caller's mic and Mira's
 * audio track. Mira's voice is drawn in green, the caller's in white; with
 * nobody talking it settles into a slow "breathing" line so the call never
 * looks frozen.
 */
export function Waveform({ analysers, active }: { analysers: VoiceCall["analysers"]; active: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = canvas.current!;
    const g = c.getContext("2d")!;
    const levels = new Float32Array(BARS);
    const mic = new Float32Array(BARS);
    const agent = new Float32Array(BARS);
    const buf = new Uint8Array(128);
    let tint = 0; // 0 = caller colour, 1 = Mira colour (eased)
    let raf = 0;

    const sample = (node: AnalyserNode | undefined, out: Float32Array) => {
      out.fill(0);
      if (!node) return 0;
      node.getByteFrequencyData(buf);
      let sum = 0;
      for (let i = 0; i < BARS / 2; i++) {
        const v = buf[2 + Math.floor((i / (BARS / 2)) * 50)] / 255;
        out[i] = v;
        sum += v;
      }
      return sum / (BARS / 2);
    };

    const draw = (t: number) => {
      const dpr = window.devicePixelRatio || 1;
      const w = c.clientWidth;
      const h = c.clientHeight;
      if (c.width !== Math.round(w * dpr)) {
        c.width = Math.round(w * dpr);
        c.height = Math.round(h * dpr);
      }
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, w, h);

      const m = sample(analysers.current.mic, mic);
      const a = sample(analysers.current.agent, agent);
      tint += ((a >= m ? 1 : 0) - tint) * 0.08;

      const gap = w / BARS;
      const bw = Math.max(2, gap * 0.45);
      for (let i = 0; i < BARS; i++) {
        // mirror the spectrum around the centre, low frequencies in the middle
        const k = Math.abs(i - (BARS - 1) / 2) | 0;
        const envelope = 1 - Math.pow(Math.abs(i - (BARS - 1) / 2) / (BARS / 2), 2) * 0.55;
        const target = Math.max(mic[k] ?? 0, agent[k] ?? 0) * envelope;
        const idle = active ? (0.05 + 0.04 * Math.sin(t / 520 + i * 0.42)) * envelope : 0.025;
        levels[i] += (Math.max(target, idle) - levels[i]) * 0.3;
        const bh = Math.max(2.5, levels[i] * h);
        const r = Math.round(243 + (127 - 243) * tint);
        const gg = Math.round(241 + (214 - 241) * tint);
        const b = Math.round(236 + (172 - 236) * tint);
        g.fillStyle = `rgba(${r},${gg},${b},${0.55 + Math.min(levels[i] * 1.6, 0.45)})`;
        g.beginPath();
        g.roundRect(i * gap + (gap - bw) / 2, (h - bh) / 2, bw, bh, bw / 2);
        g.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [analysers, active]);

  return <canvas ref={canvas} className="block h-14 w-full" aria-hidden />;
}
