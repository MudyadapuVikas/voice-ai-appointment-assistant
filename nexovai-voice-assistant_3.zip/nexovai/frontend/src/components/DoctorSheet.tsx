import { useEffect } from "react";
import { Clock3, DoorOpen, X } from "lucide-react";
import type { Appointment, Doctor } from "../lib/api";
import { clock, clock12, cx, relativeDay } from "../lib/format";
import { DoctorAvatar, SpecialtyTag, StatusBadge } from "./ui/primitives";
import { SlotChip } from "./SlotChip";

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

/** Right-hand profile panel: the doctor's whole week and who is booked with them. */
export function DoctorSheet({
  doctor,
  days,
  today,
  appointments,
  flashSlot,
  onClose,
}: {
  doctor: Doctor | null;
  days: string[];
  today: string;
  appointments: Appointment[];
  flashSlot: string | null;
  onClose: () => void;
}) {
  useEffect(() => {
    if (!doctor) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [doctor, onClose]);

  const open = Boolean(doctor);
  const all = doctor ? days.flatMap((d) => doctor.slots[d] ?? []) : [];
  const booked = all.filter((s) => s.state === "booked").length;
  const free = all.filter((s) => s.state === "free").length;
  const patients = doctor ? appointments.filter((a) => a.doctor_id === doctor.id && a.status === "booked") : [];

  return (
    <div className={cx("fixed inset-0 z-40", open ? "pointer-events-auto" : "pointer-events-none")} aria-hidden={!open}>
      <div className={cx("absolute inset-0 bg-ink/20 transition-opacity duration-300", open ? "opacity-100" : "opacity-0")} onClick={onClose} />
      <aside
        className={cx(
          "absolute inset-y-0 right-0 flex w-full max-w-[460px] flex-col border-l border-line bg-surface shadow-2xl transition-transform duration-500 ease-[cubic-bezier(.2,.8,.2,1)]",
          open ? "translate-x-0" : "translate-x-full",
        )}
        role="dialog"
        aria-label="Doctor profile"
      >
        {doctor && (
          <>
            <header className="border-b border-line-2 px-6 pb-5 pt-5">
              <div className="flex items-start justify-between">
                <DoctorAvatar name={doctor.name} specialty={doctor.specialty} size={56} />
                <button onClick={onClose} className="rounded-md p-1.5 text-ink-3 hover:bg-line-2 hover:text-ink" aria-label="Close">
                  <X size={16} />
                </button>
              </div>
              <h2 className="mt-4 font-display text-[30px] leading-none">{doctor.name}</h2>
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1">
                <SpecialtyTag specialty={doctor.specialty} />
                <span className="flex items-center gap-1.5 text-[12px] text-ink-2">
                  <DoorOpen size={13} className="text-ink-3" /> Room {doctor.room}
                </span>
                <span className="flex items-center gap-1.5 text-[12px] text-ink-2">
                  <Clock3 size={13} className="text-ink-3" />
                  <span className="tabular">{clock12(doctor.start_time)} – {clock12(doctor.end_time)}</span>
                </span>
              </div>
              <div className="mt-4 flex gap-1">
                {WEEKDAYS.map((w, i) => (
                  <span
                    key={w}
                    className={cx(
                      "flex-1 rounded-md py-1 text-center text-[11px]",
                      doctor.work_days.includes(i) ? "bg-ink text-white" : "bg-line-2 text-ink-3",
                    )}
                  >
                    {w}
                  </span>
                ))}
              </div>
              <dl className="mt-4 grid grid-cols-3 divide-x divide-line-2 rounded-lg border border-line-2">
                {[
                  ["Open", free],
                  ["Booked", booked],
                  ["Load", `${all.length ? Math.round((booked / all.length) * 100) : 0}%`],
                ].map(([k, v]) => (
                  <div key={k} className="px-3 py-2.5">
                    <dt className="text-[11.5px] text-ink-3">{k}</dt>
                    <dd className="tabular mt-0.5 font-mono text-[17px] font-medium">{v}</dd>
                  </div>
                ))}
              </dl>
            </header>

            <div className="flex-1 overflow-y-auto px-6 py-5">
              <h3 className="eyebrow mb-3">Next 7 days</h3>
              <div className="space-y-4">
                {days.map((d) => {
                  const slots = doctor.slots[d] ?? [];
                  return (
                    <div key={d} className="grid grid-cols-[76px_1fr] gap-3">
                      <div className={cx("pt-1.5 text-[12.5px]", d === today ? "font-medium" : "text-ink-2")}>{relativeDay(d, today)}</div>
                      {slots.length === 0 ? (
                        <div className="pt-1.5 text-[12px] text-ink-3">Off</div>
                      ) : (
                        <div className="grid grid-cols-5 gap-1">
                          {slots.map((s) => (
                            <SlotChip key={s.time} time={s.time} state={s.state} flash={flashSlot === `${doctor.id}|${d}|${s.time}`} compact />
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <h3 className="eyebrow mb-2 mt-8">Upcoming patients</h3>
              {patients.length === 0 ? (
                <p className="text-[12.5px] text-ink-3">No upcoming bookings.</p>
              ) : (
                <ul className="divide-y divide-line-2">
                  {patients.map((a) => (
                    <li key={a.id} className="flex items-center justify-between gap-3 py-2.5">
                      <div>
                        <div className="text-[13px] font-medium">{a.patient_name}</div>
                        <div className="tabular font-mono text-[11.5px] text-ink-3">
                          {relativeDay(a.date, today)} · {clock(a.time)}
                        </div>
                      </div>
                      <StatusBadge status={a.status} />
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </>
        )}
      </aside>
    </div>
  );
}
