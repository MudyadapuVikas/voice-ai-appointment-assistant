import type { ReactNode } from "react";
import type { LucideIcon } from "lucide-react";
import type { AppointmentStatus } from "../../lib/api";
import { cx, initials } from "../../lib/format";
import { specialtyStyle } from "../../lib/specialty";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-[34px] leading-none tracking-[-0.01em]">{title}</h1>
        {subtitle && <p className="mt-2 text-ink-2">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cx("card", className)}>{children}</section>;
}

export function CardHeader({ title, icon: Icon, action }: { title: string; icon?: LucideIcon; action?: ReactNode }) {
  return (
    <header className="flex items-center justify-between gap-3 border-b border-line-2 px-5 py-3.5">
      <h2 className="flex items-center gap-2 text-[13px] font-medium">
        {Icon && <Icon size={15} className="text-ink-3" strokeWidth={1.8} />}
        {title}
      </h2>
      {action}
    </header>
  );
}

const STATUS: Record<AppointmentStatus, { label: string; className: string }> = {
  booked: { label: "Booked", className: "bg-brand-soft text-brand-2" },
  completed: { label: "Completed", className: "bg-line-2 text-ink-2" },
  cancelled: { label: "Cancelled", className: "bg-danger-soft text-danger" },
};

export function StatusBadge({ status }: { status: AppointmentStatus }) {
  const s = STATUS[status];
  return (
    <span className={cx("inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11.5px] font-medium", s.className)}>
      <span className="size-1.5 rounded-full bg-current opacity-70" />
      {s.label}
    </span>
  );
}

export function SourceTag({ source }: { source: "voice" | "dashboard" | "seed" }) {
  const label = source === "voice" ? "Voice" : source === "dashboard" ? "Desk" : "Sample";
  return <span className="rounded border border-line px-1.5 py-px font-mono text-[10px] uppercase tracking-wider text-ink-3">{label}</span>;
}

export function Avatar({ name, size = 36, tone = "neutral" }: { name: string; size?: number; tone?: "neutral" | "brand" }) {
  return (
    <span
      style={{ width: size, height: size }}
      className={cx(
        "inline-grid shrink-0 place-items-center rounded-full font-mono text-[11px] font-medium",
        tone === "brand" ? "bg-brand-soft text-brand-2" : "border border-line bg-line-2 text-ink-2",
      )}
    >
      {initials(name)}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = "secondary",
  icon: Icon,
  disabled,
  type = "button",
  className,
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  icon?: LucideIcon;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const styles = {
    primary: "bg-ink text-white hover:bg-ink/90 shadow-sm",
    secondary: "bg-surface border border-line hover:border-ink-3 text-ink",
    ghost: "text-ink-2 hover:bg-line-2 hover:text-ink",
    danger: "bg-danger text-white hover:bg-danger/90",
  }[variant];
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cx(
        "inline-flex h-9 items-center justify-center gap-2 rounded-lg px-3.5 text-[13px] font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50",
        styles,
        className,
      )}
    >
      {Icon && <Icon size={15} strokeWidth={1.9} />}
      {children}
    </button>
  );
}

export function EmptyState({ icon: Icon, title, hint }: { icon: LucideIcon; title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-14 text-center">
      <span className="mb-3 grid size-10 place-items-center rounded-full bg-line-2 text-ink-3">
        <Icon size={18} strokeWidth={1.8} />
      </span>
      <p className="font-medium">{title}</p>
      {hint && <p className="mt-1 max-w-xs text-[13px] text-ink-2">{hint}</p>}
    </div>
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string; count?: number }[];
}) {
  return (
    <div className="no-scrollbar inline-flex max-w-full overflow-x-auto rounded-lg bg-line-2 p-0.5">
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cx(
            "flex items-center gap-1.5 whitespace-nowrap rounded-md px-3 py-1.5 text-[12.5px] transition-all",
            value === o.value ? "bg-surface font-medium text-ink shadow-[0_1px_2px_rgba(0,0,0,0.08)]" : "text-ink-2 hover:text-ink",
          )}
        >
          {o.label}
          {o.count !== undefined && <span className="font-mono text-[11px] text-ink-3">{o.count}</span>}
        </button>
      ))}
    </div>
  );
}

export function DoctorAvatar({ name, specialty, size = 40 }: { name: string; specialty: string; size?: number }) {
  const s = specialtyStyle(specialty);
  const Icon = s.icon;
  return (
    <span className="relative inline-block shrink-0" style={{ width: size, height: size }}>
      <span className={cx("grid size-full place-items-center rounded-full font-mono text-[11.5px] font-medium ring-1", s.tone)}>{initials(name)}</span>
      <span className="absolute -bottom-0.5 -right-0.5 grid size-[17px] place-items-center rounded-full bg-surface ring-1 ring-line">
        <Icon size={10} strokeWidth={2.2} className="text-ink-2" />
      </span>
    </span>
  );
}

export function SpecialtyTag({ specialty }: { specialty: string }) {
  const s = specialtyStyle(specialty);
  return (
    <span className="inline-flex items-center gap-1.5 text-[12px] text-ink-2">
      <span className={cx("size-1.5 rounded-full", s.dot)} />
      {specialty}
    </span>
  );
}
