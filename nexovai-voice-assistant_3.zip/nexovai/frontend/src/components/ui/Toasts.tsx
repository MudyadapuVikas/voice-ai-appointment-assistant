import { CalendarCheck2, CalendarX2, X } from "lucide-react";
import { cx } from "../../lib/format";

export type Toast = { id: number; kind: "booked" | "cancelled"; title: string; body: string };

export function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div className="pointer-events-none fixed bottom-20 right-4 z-40 flex lg:bottom-6 lg:left-[272px] lg:right-auto w-[340px] max-w-[calc(100vw-2rem)] flex-col gap-2">
      {toasts.map((t) => (
        <div key={t.id} className="card pointer-events-auto flex animate-rise items-start gap-3 p-3.5 shadow-lg">
          <span className={cx("grid size-8 shrink-0 place-items-center rounded-full", t.kind === "booked" ? "bg-brand-soft text-brand" : "bg-danger-soft text-danger")}>
            {t.kind === "booked" ? <CalendarCheck2 size={15} /> : <CalendarX2 size={15} />}
          </span>
          <div className="min-w-0 flex-1">
            <div className="text-[13px] font-medium">{t.title}</div>
            <div className="truncate text-[12.5px] text-ink-2">{t.body}</div>
          </div>
          <button onClick={() => onDismiss(t.id)} className="text-ink-3 hover:text-ink" aria-label="Dismiss">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
