import { useEffect, useState, type ReactNode } from "react";
import { Activity, CalendarDays, LayoutGrid, Phone, RotateCcw, Stethoscope, type LucideIcon } from "lucide-react";
import type { Health } from "../../lib/api";
import type { CallPhase } from "../../hooks/useVoiceCall";
import { callTimer, cx } from "../../lib/format";

export type Route = "overview" | "doctors" | "appointments" | "activity";

export const NAV: { id: Route; label: string; icon: LucideIcon }[] = [
  { id: "overview", label: "Overview", icon: LayoutGrid },
  { id: "doctors", label: "Doctors", icon: Stethoscope },
  { id: "appointments", label: "Appointments", icon: CalendarDays },
  { id: "activity", label: "Activity", icon: Activity },
];

type ShellProps = {
  route: Route;
  onNavigate: (r: Route) => void;
  counts: Partial<Record<Route, number>>;
  health: Health | null;
  online: boolean;
  live: boolean;
  callPhase: CallPhase;
  callStartedAt: number | null;
  onCall: () => void;
  onReset: () => void;
  children: ReactNode;
};

function useNow(ms = 1000) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now;
}

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <span className="relative grid size-8 place-items-center rounded-[9px] bg-ink text-white">
        <svg viewBox="0 0 32 32" className="size-5" aria-hidden>
          <path d="M10 8v16M22 8v16M10 16h12" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" fill="none" />
        </svg>
        <span className="absolute -right-0.5 -top-0.5 size-2.5 rounded-full border-2 border-canvas bg-brand" />
      </span>
      <div className="leading-none">
        <div className="font-display text-[22px] italic">Halcyon</div>
        <div className="eyebrow mt-0.5 !text-[9.5px]">Front desk</div>
      </div>
    </div>
  );
}

function AgentCard({ health, online, callPhase, callStartedAt, onCall }: Pick<ShellProps, "health" | "online" | "callPhase" | "callStartedAt" | "onCall">) {
  const now = useNow();
  const onCallNow = callPhase === "connecting" || callPhase === "live";
  const secs = callStartedAt ? Math.floor((now.getTime() - callStartedAt) / 1000) : 0;
  const status = !online
    ? { label: "Backend offline", dot: "bg-ink-3" }
    : onCallNow
      ? { label: callPhase === "live" ? `On call · ${callTimer(secs)}` : "Connecting…", dot: "bg-danger live-dot text-danger" }
      : health?.voice_enabled
        ? { label: "Ready for calls", dot: "bg-brand live-dot text-brand" }
        : { label: "Voice not configured", dot: "bg-warn" };

  return (
    <div className="rounded-xl border border-line bg-surface p-3.5">
      <div className="flex items-center gap-2.5">
        <span className="grid size-8 place-items-center rounded-full bg-brand-soft font-display text-[17px] italic text-brand-2">M</span>
        <div className="min-w-0">
          <div className="text-[13px] font-medium">Mira</div>
          <div className="flex items-center gap-1.5 text-[11.5px] text-ink-2">
            <span className={cx("size-1.5 rounded-full", status.dot)} />
            <span className="tabular truncate">{status.label}</span>
          </div>
        </div>
      </div>
      {health && !health.voice_enabled && online && (
        <p className="mt-2.5 rounded-md bg-warn-soft px-2 py-1.5 font-mono text-[10.5px] leading-snug text-warn">
          Set {health.missing_credentials.join(" + ")} in .env
        </p>
      )}
      <button
        onClick={onCall}
        disabled={onCallNow}
        className="mt-3 flex h-9 w-full items-center justify-center gap-2 rounded-lg bg-ink text-[13px] font-medium text-white transition hover:bg-ink/90 disabled:opacity-60"
      >
        <Phone size={14} strokeWidth={2} />
        Try call
      </button>
    </div>
  );
}

export function Shell(props: ShellProps) {
  const { route, onNavigate, counts, live, online, onReset, children, onCall, callPhase } = props;
  const now = useNow(15_000);

  return (
    <div className="min-h-dvh lg:pl-[248px]">
      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-[248px] flex-col border-r border-line bg-canvas px-4 py-5 lg:flex">
        <div className="px-2">
          <Logo />
        </div>
        <nav className="mt-8 space-y-0.5">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className={cx(
                "group flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-[13.5px] transition-colors",
                route === id ? "bg-surface font-medium text-ink shadow-[0_0_0_1px_var(--color-line)]" : "text-ink-2 hover:bg-line-2 hover:text-ink",
              )}
            >
              <Icon size={16} strokeWidth={1.8} className={route === id ? "text-brand" : "text-ink-3 group-hover:text-ink-2"} />
              {label}
              {counts[id] !== undefined && <span className="tabular ml-auto font-mono text-[11px] text-ink-3">{counts[id]}</span>}
            </button>
          ))}
        </nav>
        <div className="mt-auto space-y-2">
          <AgentCard {...props} />
          <button onClick={onReset} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-1.5 text-[12px] text-ink-3 hover:bg-line-2 hover:text-ink-2">
            <RotateCcw size={13} /> Reset demo data
          </button>
        </div>
      </aside>

      {/* top bar */}
      <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-line bg-canvas/85 px-5 backdrop-blur-md lg:px-8">
        <div className="lg:hidden">
          <Logo />
        </div>
        <div className="hidden text-[13px] text-ink-2 lg:block">
          {now.toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" })}
          <span className="mx-2 text-line">/</span>
          <span className="tabular font-mono text-[12px] text-ink">
            {now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className={cx("flex items-center gap-1.5 font-mono text-[11px]", online && live ? "text-brand" : "text-ink-3")}>
            <span className={cx("size-1.5 rounded-full", online && live ? "bg-brand live-dot" : "bg-ink-3")} />
            {online ? (live ? "Live" : "Connecting") : "Offline"}
          </span>
          <button
            onClick={onCall}
            disabled={callPhase === "connecting" || callPhase === "live"}
            className="grid size-9 place-items-center rounded-full bg-ink text-white disabled:opacity-60 lg:hidden"
            aria-label="Try call"
          >
            <Phone size={15} />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-[1240px] px-5 pb-28 pt-7 lg:px-8 lg:pb-12">{children}</main>

      {/* mobile tab bar */}
      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-4 border-t border-line bg-canvas/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden">
        {NAV.map(({ id, label, icon: Icon }) => (
          <button key={id} onClick={() => onNavigate(id)} className={cx("flex flex-col items-center gap-1 py-2.5 text-[10.5px]", route === id ? "text-ink" : "text-ink-3")}>
            <Icon size={18} strokeWidth={route === id ? 2.1 : 1.7} />
            {label}
          </button>
        ))}
      </nav>
    </div>
  );
}
