import { Fragment, useEffect, useMemo, useState } from "react";
import { CalendarDays, Plus, Search, X } from "lucide-react";
import type { ClinicData } from "../hooks/useClinicData";
import { api, ApiError, type Appointment } from "../lib/api";
import { clock, cx, maskPhone, meridiem, relativeDay } from "../lib/format";
import { Avatar, Button, Card, EmptyState, PageHeader, Segmented, SourceTag, SpecialtyTag, StatusBadge } from "../components/ui/primitives";
import { Dialog } from "../components/ui/Dialog";
import { DeskBookingDialog } from "../components/DeskBookingDialog";

type Filter = "upcoming" | "today" | "completed" | "cancelled" | "all";

export function Appointments({ data }: { data: ClinicData }) {
  const { appointments, schedule, highlight } = data;
  const today = schedule?.today ?? "";
  const [filter, setFilter] = useState<Filter>("upcoming");
  const [query, setQuery] = useState("");
  const [booking, setBooking] = useState(false);
  const [cancelling, setCancelling] = useState<Appointment | null>(null);

  const matches: Record<Filter, (a: Appointment) => boolean> = {
    upcoming: (a) => a.status === "booked",
    today: (a) => a.date === today,
    completed: (a) => a.status === "completed",
    cancelled: (a) => a.status === "cancelled",
    all: () => true,
  };

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return appointments
      .filter(matches[filter])
      .filter((a) => !q || [a.patient_name, a.doctor_name, a.specialty, a.phone.slice(-4), `#${a.id}`].some((s) => s.toLowerCase().includes(q)))
      .sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`) || a.id - b.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appointments, filter, query, today]);

  const count = (f: Filter) => appointments.filter(matches[f]).length;

  // bring the row Mira just booked or cancelled into view
  useEffect(() => {
    if (!highlight) return;
    const id = window.setTimeout(() => {
      const rows = document.querySelectorAll<HTMLElement>(`[data-appt="${highlight.appointmentId}"]`);
      [...rows].find((el) => el.offsetParent !== null)?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 300);
    return () => window.clearTimeout(id);
  }, [highlight]);
  const dayCounts = rows.reduce((m, a) => m.set(a.date, (m.get(a.date) ?? 0) + 1), new Map<string, number>());
  const flashClass = (id: number) =>
    highlight?.appointmentId === id ? (highlight.kind === "booked" ? "animate-flash-ok" : "animate-flash-cx") : "";

  return (
    <>
      <PageHeader
        title="Appointments"
        subtitle="Updates live as Mira books and cancels."
        actions={<Button variant="primary" icon={Plus} onClick={() => setBooking(true)}>New booking</Button>}
      />

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Segmented
          value={filter}
          onChange={setFilter}
          options={(["upcoming", "today", "completed", "cancelled", "all"] as Filter[]).map((f) => ({
            value: f,
            label: f[0].toUpperCase() + f.slice(1),
            count: count(f),
          }))}
        />
        <div className="relative w-full sm:w-64">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-3" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Patient, doctor or last 4 digits"
            className="h-9 w-full rounded-lg border border-line bg-surface pl-8 pr-8 text-[13px] outline-none focus:border-ink-3"
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-2 top-1/2 -translate-y-1/2 text-ink-3 hover:text-ink" aria-label="Clear">
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      <Card className="overflow-hidden">
        {rows.length === 0 ? (
          <EmptyState icon={CalendarDays} title="No appointments here" hint="Try another filter, or place a call to book one." />
        ) : (
          <>
            {/* phones: stacked cards */}
            <ul className="divide-y divide-line-2 md:hidden">
              {rows.map((a) => (
                <li key={a.id} data-appt={a.id} className={cx("flex gap-3 px-4 py-3.5", flashClass(a.id))}>
                  <Avatar name={a.patient_name} size={32} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <PatientName a={a} />
                      <StatusBadge status={a.status} />
                    </div>
                    <div className="mt-1 text-[12.5px] text-ink-2">{a.doctor_name} · {a.specialty}</div>
                    <div className="mt-1.5 flex items-center justify-between">
                      <span className="tabular font-mono text-[12.5px]">
                        {today ? relativeDay(a.date, today) : a.date} · {clock(a.time)} {meridiem(a.time)}
                      </span>
                      {a.status === "booked" && <CancelButton onClick={() => setCancelling(a)} />}
                    </div>
                  </div>
                </li>
              ))}
            </ul>

            {/* tablet and up: table */}
            <table className="hidden w-full text-left md:table">
              <thead className="border-b border-line-2 bg-canvas/60">
                <tr className="eyebrow">
                  <th className="px-5 py-2.5 font-normal">Patient</th>
                  <th className="px-3 py-2.5 font-normal">Doctor</th>
                  <th className="px-3 py-2.5 font-normal">Time</th>
                  <th className="px-3 py-2.5 font-normal">Status</th>
                  <th className="px-5 py-2.5 font-normal" />
                </tr>
              </thead>
              <tbody className="divide-y divide-line-2">
                {rows.map((a, i) => (
                  <Fragment key={a.id}>
                  {(i === 0 || rows[i - 1].date !== a.date) && (
                    <tr className="bg-canvas/70">
                      <td colSpan={5} className="px-5 py-2">
                        <span className="eyebrow !text-ink-2">{today ? relativeDay(a.date, today) : a.date}</span>
                        <span className="tabular ml-2 font-mono text-[10.5px] text-ink-3">{dayCounts.get(a.date)}</span>
                      </td>
                    </tr>
                  )}
                  <tr data-appt={a.id} className={cx("transition-colors hover:bg-canvas/70", flashClass(a.id))}>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={a.patient_name} size={32} />
                        <PatientName a={a} />
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="text-[13px]">{a.doctor_name}</div>
                      <SpecialtyTag specialty={a.specialty} />
                    </td>
                    <td className="px-3 py-3">
                      <div className="tabular font-mono text-[13px]">
                        {clock(a.time)} <span className="text-[10.5px] text-ink-3">{meridiem(a.time)}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <StatusBadge status={a.status} />
                        <span className="hidden lg:inline">
                          <SourceTag source={a.source} />
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-right">{a.status === "booked" && <CancelButton onClick={() => setCancelling(a)} />}</td>
                  </tr>
                  </Fragment>
                ))}
              </tbody>
            </table>
          </>
        )}
      </Card>

      <DeskBookingDialog open={booking} onClose={() => setBooking(false)} schedule={schedule} />
      <CancelDialog appointment={cancelling} onClose={() => setCancelling(null)} today={today} />
    </>
  );
}

function PatientName({ a }: { a: Appointment }) {
  return (
    <div className="min-w-0">
      <div className={cx("truncate font-medium", a.status === "cancelled" && "text-ink-2 line-through decoration-danger/60")}>{a.patient_name}</div>
      <div className="tabular font-mono text-[11.5px] text-ink-3">
        {maskPhone(a.phone)} · #{String(a.id).padStart(4, "0")}
      </div>
    </div>
  );
}

function CancelButton({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick} className="rounded-md px-2 py-1 text-[12px] text-ink-2 hover:bg-danger-soft hover:text-danger">
      Cancel
    </button>
  );
}

function CancelDialog({ appointment, onClose, today }: { appointment: Appointment | null; onClose: () => void; today: string }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  if (!appointment) return null;

  const confirm = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.cancel({ phone_number: appointment.phone, appointment_id: appointment.id, confirm: true });
      onClose();
    } catch (e) {
      setError(e instanceof ApiError ? e.message : "Cancellation failed.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onClose={onClose} title={`Cancel #${String(appointment.id).padStart(4, "0")}?`} subtitle="Demo mode — the slot opens up again immediately.">
      <div className="rounded-xl border border-line p-4">
        <div className="font-medium">{appointment.patient_name}</div>
        <div className="mt-1 text-[13px] text-ink-2">
          {appointment.doctor_name} · {relativeDay(appointment.date, today)}, {clock(appointment.time)} {meridiem(appointment.time)}
        </div>
      </div>
      {error && <p className="mt-3 text-[12.5px] text-danger">{error}</p>}
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>Keep it</Button>
        <Button variant="danger" onClick={confirm} disabled={busy}>{busy ? "Cancelling…" : "Cancel appointment"}</Button>
      </div>
    </Dialog>
  );
}
