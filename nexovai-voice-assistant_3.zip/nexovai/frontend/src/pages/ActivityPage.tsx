import { useMemo, useState } from "react";
import { Activity as ActivityIcon } from "lucide-react";
import type { ClinicData } from "../hooks/useClinicData";
import { ActivityItem } from "../components/ActivityItem";
import { Card, EmptyState, PageHeader, Segmented } from "../components/ui/primitives";
import { relativeDay } from "../lib/format";

type Filter = "all" | "booked" | "cancelled" | "voice";

export function ActivityPage({ data }: { data: ClinicData }) {
  const { activity, schedule, highlight } = data;
  const today = schedule?.today ?? "";
  const [filter, setFilter] = useState<Filter>("all");

  const groups = useMemo(() => {
    const items = activity.filter((a) => filter === "all" || (filter === "voice" ? a.source === "voice" : a.kind === filter));
    const byDay = new Map<string, typeof items>();
    for (const item of items) {
      const day = item.created_at.slice(0, 10);
      byDay.set(day, [...(byDay.get(day) ?? []), item]);
    }
    return [...byDay.entries()];
  }, [activity, filter]);

  return (
    <>
      <PageHeader title="Activity" subtitle="Every booking and cancellation, newest first." />
      <div className="mb-4">
        <Segmented
          value={filter}
          onChange={setFilter}
          options={[
            { value: "all", label: "All", count: activity.length },
            { value: "booked", label: "Bookings", count: activity.filter((a) => a.kind === "booked").length },
            { value: "cancelled", label: "Cancellations", count: activity.filter((a) => a.kind === "cancelled").length },
            { value: "voice", label: "By voice", count: activity.filter((a) => a.source === "voice").length },
          ]}
        />
      </div>
      <Card className="px-5 py-3">
        {groups.length === 0 ? (
          <EmptyState icon={ActivityIcon} title="No activity yet" hint="Place a call and book something." />
        ) : (
          groups.map(([day, items]) => (
            <div key={day} className="py-2">
              <h3 className="eyebrow mb-1 mt-2">{today ? relativeDay(day, today) : day}</h3>
              <ul>
                {items.map((item, i) => (
                  <ActivityItem key={item.id} item={item} today={today} fresh={highlight?.appointmentId === item.appointment_id && i === 0 && day === groups[0][0]} />
                ))}
              </ul>
            </div>
          ))
        )}
      </Card>
    </>
  );
}
