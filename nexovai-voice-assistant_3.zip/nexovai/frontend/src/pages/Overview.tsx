import { useEffect, useRef, useState } from "react";
import { Activity as ActivityIcon, ArrowUpRight, AudioLines, CalendarRange, Clock3, Phone } from "lucide-react";
import type { ClinicData } from "../hooks/useClinicData";
import type { Route } from "../components/layout/Shell";
import type { Appointment, Health, Schedule } from "../lib/api";
import { ActivityItem } from "../components/ActivityItem";
import { Avatar, Card, CardHeader, EmptyState, SpecialtyTag, StatusBadge } from "../components/ui/primitives";
import { clock, clock12, cx, longDate, meridiem, weekdayShort } from "../lib/format";

type Props = { data: ClinicData; onNavigate: (r: Route) => void; onCall: () => void; callBusy: boolean };

function greeting() {
  const h = new Date().getHours();
  return h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening";
}

/** booked and total slots per day across all doctors */
function weekLoad(schedule: Schedule) {
  return schedule.days.map((day) => {
    const slots = schedule.doctors.flatMap((d) => d.slots[day] ?? []);
    return { day, booked: slots.filter((s) => s.state === "booked").length, total: slots.length };
  });
}

function Metric({ label, value, sub, children }: { label: string; value: string | number; sub?: string; children?: React.ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col justify-between gap-4 p-5">
      <span className="text-[12.5px] text-ink-2">{label}</span>
      <div className="flex items-end justify-between gap-3">
        <div>
          <div className="tabular font-mono text-[30px] font-medium leading-none tracking-[-0.04em]">{value}</div>
          {sub && <div className="mt-2 text-[12px] text-ink-3">{sub}</div>}
        </div>
        {children}
      </div>
    </div>
  );
}

function Spark({ values }: { values: number[] }) {
  const max = Math.max(1, ...values);
  return (
    <div className="hidden h-8 items-end gap-[3px] sm:flex" aria-hidden>
      {values.map((v, i) => (
        <span key={i} className={cx("w-[5px] rounded-sm", i === 0 ? "bg-brand" : "bg-line")} style={{ height: `${Math.max(12, (v / max) * 100)}%` }} />
      ))}
    </div>
  );
}

function Ring({ value, total }: { value: number; total: number }) {
  const pct = total ? value / total : 0;
  const c = 2 * Math.PI * 14;
  return (
    <svg viewBox="0 0 36 36" className="hidden size-9 -rotate-90 sm:block" aria-hidden>
      <circle cx="18" cy="18" r="14" fill="none" strokeWidth="4" className="stroke-line-2" />
      <circle cx="18" cy="18" r="14" fill="none" strokeWidth="4" strokeLinecap="round" className="stroke-brand transition-all duration-700" strokeDasharray={`${pct * c} ${c}`} />
    </svg>
  );
}

function TodayTimeline({ items, highlightId }: { items: Appointment[]; highlightId?: number }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 30_000);
    return () => window.clearInterval(id);
  }, []);
  const nowHHMM = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const nowIndex = items.findIndex((a) => a.time > nowHHMM);

  const list = useRef<HTMLOListElement>(null);
  useEffect(() => {
    const marker = list.current?.querySelector<HTMLElement>("[data-now]");
    const scroller = list.current?.parentElement;
    if (marker && scroller) scroller.scrollTop = Math.max(0, marker.offsetTop - 120);
  }, [items.length]);

  if (!items.length) return <EmptyState icon={Clock3} title="Nothing booked for today" hint="Bookings made on a call appear here as they happen." />;

  return (
    <ol ref={list} className="relative px-5 py-3">
      <span className="absolute bottom-6 left-[94px] top-6 w-px bg-line" aria-hidden />
      {items.map((a, i) => (
        <li key={a.id}>
          {i === nowIndex && <NowMarker time={nowHHMM} />}
          <div className={cx("relative -mx-2 flex items-center gap-4 rounded-lg px-2 py-2.5", highlightId === a.id && "animate-flash-ok")}>
            <div className={cx("tabular w-[62px] text-right font-mono text-[13px]", a.status === "completed" ? "text-ink-3" : "font-medium")}>
              {clock(a.time)}
              <span className="ml-0.5 text-[10px] text-ink-3">{meridiem(a.time)}</span>
            </div>
            <span className={cx("relative z-10 size-2.5 shrink-0 rounded-full ring-4 ring-surface", a.status === "completed" ? "bg-line" : "bg-brand")} />
            <Avatar name={a.patient_name} size={30} />
            <div className="min-w-0 flex-1">
              <div className={cx("truncate font-medium", a.status === "completed" && "text-ink-2")}>{a.patient_name}</div>
              <div className="flex items-center gap-2 truncate text-[12px] text-ink-2">
                {a.doctor_name}
                <span className="hidden sm:inline"><SpecialtyTag specialty={a.specialty} /></span>
              </div>
            </div>
            <span className="hidden sm:inline-flex"><StatusBadge status={a.status} /></span>
          </div>
        </li>
      ))}
      {nowIndex === -1 && <NowMarker time={nowHHMM} />}
    </ol>
  );
}

function NowMarker({ time }: { time: string }) {
  return (
    <div data-now className="relative my-1 flex items-center gap-4" aria-label="Now">
      <span className="tabular w-[62px] text-right font-mono text-[10.5px] font-medium text-danger">{clock12(time)}</span>
      <span className="relative z-10 -ml-[1px] size-2 rounded-full bg-danger" />
      <span className="h-px flex-1 bg-danger/40" />
    </div>
  );
}

function VoiceAgentCard({ health, onCall, callBusy, online }: { health: Health | null; onCall: () => void; callBusy: boolean; online: boolean }) {
  const ready = online && health?.voice_enabled;
  return (
    <section className="relative flex flex-col overflow-hidden rounded-xl bg-ink p-5 text-white shadow-[0_1px_2px_rgba(0,0,0,0.1)]">
      <div className="pointer-events-none absolute -right-20 -top-24 size-64 rounded-full bg-brand/45 blur-3xl" />
      <div className="relative flex items-center justify-between">
        <span className="eyebrow !text-white/45">Voice receptionist</span>
        <span className={cx("flex items-center gap-1.5 text-[11.5px]", ready ? "text-emerald-300" : "text-amber-200")}>
          <span className={cx("size-1.5 rounded-full", ready ? "live-dot bg-emerald-300" : "bg-amber-200")} />
          {!online ? "Offline" : ready ? "Online" : "Needs API keys"}
        </span>
      </div>
      <div className="relative mt-5 flex items-center gap-3.5">
        <span className="grid size-12 place-items-center rounded-full bg-white/10 font-display text-[24px] italic ring-1 ring-white/15">M</span>
        <div>
          <div className="font-display text-[26px] leading-none">Mira</div>
          <div className="mt-1 text-[12.5px] text-white/55">Books and cancels by phone number</div>
        </div>
      </div>

      <div className="relative mt-5 grid grid-cols-3 gap-px overflow-hidden rounded-lg bg-white/10 text-center font-mono text-[10.5px]">
        {[
          ["Hears", "Scribe"],
          ["Thinks", "Gemini"],
          ["Speaks", "Flash v2.5"],
        ].map(([k, v]) => (
          <div key={k} className="bg-ink/80 px-2 py-2">
            <div className="text-white/40">{k}</div>
            <div className="mt-0.5 text-white/85">{v}</div>
          </div>
        ))}
      </div>

      {health && !health.voice_enabled && online && (
        <p className="relative mt-3 font-mono text-[10.5px] leading-snug text-amber-200/90">Add {health.missing_credentials.join(" + ")} to .env</p>
      )}

      <button
        onClick={onCall}
        disabled={callBusy}
        className="relative mt-5 flex h-11 items-center justify-center gap-2.5 rounded-lg bg-white text-[14px] font-medium text-ink transition hover:bg-white/90 disabled:opacity-60"
      >
        <Phone size={15} strokeWidth={2.2} />
        {callBusy ? "On a call" : "Try call"}
      </button>
    </section>
  );
}

function WeekCapacity({ schedule, onOpen }: { schedule: Schedule; onOpen: () => void }) {
  const load = weekLoad(schedule);
  const max = Math.max(...load.map((d) => d.total), 1);
  return (
    <Card>
      <CardHeader
        title="Week ahead"
        icon={CalendarRange}
        action={
          <button onClick={onOpen} className="flex items-center gap-1 text-[12px] text-ink-2 hover:text-ink">
            Doctors <ArrowUpRight size={13} />
          </button>
        }
      />
      <div className="flex h-[196px] items-end justify-between gap-2 px-5 pb-4 pt-5">
        {load.map((d) => {
          const free = d.total - d.booked;
          return (
            <div key={d.day} className="flex h-full flex-1 flex-col items-center justify-end gap-2" title={`${d.booked} booked · ${free} open`}>
              <span className={cx("tabular font-mono text-[11px]", d.total ? "text-ink-2" : "text-ink-3")}>{d.total ? free : "–"}</span>
              <div className="flex w-full max-w-[28px] flex-col justify-end overflow-hidden rounded-md" style={{ height: `${Math.max((d.total / max) * 100, 3)}%` }}>
                <div className="w-full flex-1 bg-brand-soft" />
                <div className="w-full bg-ink transition-all duration-700" style={{ height: d.total ? `${(d.booked / d.total) * 100}%` : 0 }} />
              </div>
              <span className={cx("text-[11px]", d.day === schedule.today ? "font-medium text-ink" : "text-ink-3")}>
                {d.day === schedule.today ? "Today" : weekdayShort(d.day)}
              </span>
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-4 border-t border-line-2 px-5 py-3 text-[11.5px] text-ink-3">
        <span className="flex items-center gap-1.5"><i className="size-2 rounded-sm bg-ink" /> Booked</span>
        <span className="flex items-center gap-1.5"><i className="size-2 rounded-sm bg-brand-soft ring-1 ring-emerald-100" /> Open</span>
      </div>
    </Card>
  );
}

export function Overview({ data, onNavigate, onCall, callBusy }: Props) {
  const { stats, schedule, appointments, activity, highlight, health, online } = data;
  const today = schedule?.today ?? "";
  const todays = appointments.filter((a) => a.date === today && a.status !== "cancelled").sort((a, b) => a.time.localeCompare(b.time));
  const load = schedule ? weekLoad(schedule) : [];
  const next = todays.find((a) => a.status === "booked");

  return (
    <>
      <header className="mb-7">
        <div className="eyebrow">{today ? longDate(today) : " "}</div>
        <h1 className="mt-2 font-display text-[38px] leading-none tracking-[-0.01em]">{greeting()}.</h1>
      </header>

      <Card className="grid grid-cols-2 divide-line-2 max-lg:[&>*:nth-child(-n+2)]:border-b max-lg:[&>*:nth-child(odd)]:border-r lg:grid-cols-4 lg:divide-x">
        <Metric label="Appointments" value={stats?.total ?? "–"} sub={stats ? `${stats.upcoming} upcoming` : undefined}>
          {load.length > 0 && <Spark values={load.map((d) => d.booked)} />}
        </Metric>
        <Metric label="Today" value={stats?.today ?? "–"} sub={stats ? `${stats.free_slots_today} slots open` : undefined} />
        <Metric label="Doctors in today" value={stats ? `${stats.doctors_today}` : "–"} sub={stats ? `of ${stats.doctors_total} on staff` : undefined}>
          {stats && <Ring value={stats.doctors_today} total={stats.doctors_total} />}
        </Metric>
        <Metric label="Cancelled" value={stats?.cancelled ?? "–"} sub={stats ? `${stats.completed} completed` : undefined} />
      </Card>

      <div className="mt-5 grid items-start gap-5 lg:grid-cols-3">
        <div className="min-w-0 space-y-5 lg:col-span-2">
          <Card>
            <CardHeader
              title="Today"
              icon={Clock3}
              action={
                <span className="text-[12px] text-ink-3">
                  {todays.length} booked
                  {next && (
                    <>
                      {" "}· next <span className="tabular font-mono text-ink-2">{clock12(next.time)}</span>
                    </>
                  )}
                </span>
              }
            />
            <div className="no-scrollbar max-h-[460px] overflow-y-auto">
              <TodayTimeline items={todays} highlightId={highlight?.appointmentId} />
            </div>
          </Card>
          <Card>
            <CardHeader
              title="Recent activity"
              icon={ActivityIcon}
              action={
                <button onClick={() => onNavigate("activity")} className="flex items-center gap-1 text-[12px] text-ink-2 hover:text-ink">
                  View all <ArrowUpRight size={13} />
                </button>
              }
            />
            {activity.length === 0 ? (
              <EmptyState icon={AudioLines} title="No activity yet" />
            ) : (
              <ul className="px-5 py-2">
                {activity.slice(0, 5).map((item, i) => (
                  <ActivityItem key={item.id} item={item} today={today} fresh={i === 0 && highlight?.appointmentId === item.appointment_id} />
                ))}
              </ul>
            )}
          </Card>
        </div>
        <div className="min-w-0 space-y-5 lg:sticky lg:top-[76px]">
          <VoiceAgentCard health={health} online={online} onCall={onCall} callBusy={callBusy} />
          {schedule && <WeekCapacity schedule={schedule} onOpen={() => onNavigate("doctors")} />}
        </div>
      </div>
    </>
  );
}
