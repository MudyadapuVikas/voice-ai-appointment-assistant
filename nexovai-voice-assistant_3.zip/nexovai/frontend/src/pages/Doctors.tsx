import { useEffect, useMemo, useState } from "react";
import { ChevronRight, Clock3, DoorOpen, Stethoscope } from "lucide-react";
import type { ClinicData } from "../hooks/useClinicData";
import type { Doctor, Schedule } from "../lib/api";
import { DoctorAvatar, EmptyState, PageHeader, Segmented, SpecialtyTag } from "../components/ui/primitives";
import { SlotChip } from "../components/SlotChip";
import { DoctorSheet } from "../components/DoctorSheet";
import { clock12, cx, dayOfMonth, relativeDay, weekdayShort } from "../lib/format";

function DayPicker({ schedule, value, onChange }: { schedule: Schedule; value: string; onChange: (d: string) => void }) {
  const free = (d: string) => schedule.doctors.reduce((n, doc) => n + (doc.slots[d] ?? []).filter((s) => s.state === "free").length, 0);
  return (
    <div className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 pb-1 lg:mx-0 lg:px-0">
      {schedule.days.map((d) => {
        const on = d === value;
        return (
          <button
            key={d}
            onClick={() => onChange(d)}
            className={cx(
              "group min-w-[84px] flex-1 rounded-xl border px-3.5 py-3 text-left transition-all",
              on ? "border-ink bg-ink text-white shadow-md" : "border-line bg-surface hover:border-ink-3",
            )}
          >
            <div className={cx("font-mono text-[10px] uppercase tracking-[0.12em]", on ? "text-white/50" : "text-ink-3")}>
              {d === schedule.today ? "Today" : weekdayShort(d)}
            </div>
            <div className="mt-1 font-display text-[28px] leading-none">{dayOfMonth(d)}</div>
            <div className={cx("mt-1.5 text-[11px]", on ? "text-emerald-300" : "text-brand")}>
              <span className="tabular font-mono">{free(d)}</span> open
            </div>
          </button>
        );
      })}
    </div>
  );
}

function nextOpen(doctor: Doctor, days: string[]) {
  for (const d of days) {
    const slot = (doctor.slots[d] ?? []).find((s) => s.state === "free");
    if (slot) return { day: d, time: slot.time };
  }
  return null;
}

function DoctorCard({ doctor, schedule, day, flashSlot, onOpen }: { doctor: Doctor; schedule: Schedule; day: string; flashSlot: string | null; onOpen: () => void }) {
  const slots = doctor.slots[day] ?? [];
  const free = slots.filter((s) => s.state === "free").length;
  const week = schedule.days.flatMap((d) => doctor.slots[d] ?? []);
  const weekBooked = week.filter((s) => s.state === "booked").length;
  const load = week.length ? weekBooked / week.length : 0;
  const next = nextOpen(doctor, schedule.days);

  return (
    <article className="card group flex animate-rise flex-col transition-shadow hover:shadow-[0_4px_16px_rgba(24,24,27,0.06)]">
      <button onClick={onOpen} className="flex items-start gap-3.5 px-5 pt-5 text-left">
        <DoctorAvatar name={doctor.name} specialty={doctor.specialty} size={44} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 font-medium">
            <span className="truncate">{doctor.name}</span>
            <ChevronRight size={14} className="shrink-0 text-ink-3 opacity-0 transition group-hover:translate-x-0.5 group-hover:opacity-100" />
          </div>
          <SpecialtyTag specialty={doctor.specialty} />
        </div>
        <span
          className={cx(
            "shrink-0 rounded-full px-2 py-0.5 text-[11.5px] font-medium",
            !slots.length ? "bg-line-2 text-ink-3" : free ? "bg-brand-soft text-brand-2" : "bg-warn-soft text-warn",
          )}
        >
          {!slots.length ? "Off" : free ? `${free} open` : "Full"}
        </span>
      </button>

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 px-5 text-[12px] text-ink-2">
        <span className="flex items-center gap-1.5">
          <Clock3 size={13} className="text-ink-3" />
          <span className="tabular">{clock12(doctor.start_time)} – {clock12(doctor.end_time)}</span>
        </span>
        <span className="flex items-center gap-1.5">
          <DoorOpen size={13} className="text-ink-3" /> Room {doctor.room}
        </span>
      </div>

      <div className="mt-4 px-5">
        <div className="flex items-center justify-between text-[11.5px] text-ink-3">
          <span>Week load</span>
          <span className="tabular font-mono">{weekBooked}/{week.length}</span>
        </div>
        <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-line-2">
          <div className="h-full rounded-full bg-ink transition-all duration-700" style={{ width: `${Math.max(load * 100, weekBooked ? 4 : 0)}%` }} />
        </div>
      </div>

      <div className="mt-4 flex-1 border-t border-line-2 px-5 py-4">
        {slots.length === 0 ? (
          <p className="text-[12.5px] text-ink-3">
            Not in clinic on {new Date(`${day}T00:00:00`).toLocaleDateString("en-IN", { weekday: "long" })}s.
            {next && (
              <>
                {" "}Next open <span className="text-ink-2">{relativeDay(next.day, schedule.today)}, {clock12(next.time)}</span>.
              </>
            )}
          </p>
        ) : (
          <div className="grid grid-cols-4 gap-1.5 sm:grid-cols-6 lg:grid-cols-4 xl:grid-cols-5">
            {slots.map((s) => (
              <SlotChip key={s.time} time={s.time} state={s.state} flash={flashSlot === `${doctor.id}|${day}|${s.time}`} />
            ))}
          </div>
        )}
      </div>
    </article>
  );
}

export function Doctors({ data }: { data: ClinicData }) {
  const { schedule, highlight, appointments } = data;
  const [day, setDay] = useState("");
  const [specialty, setSpecialty] = useState("all");
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    if (schedule && !day) setDay(schedule.today);
  }, [schedule, day]);

  // follow the agent: jump to the day it just booked or cancelled
  useEffect(() => {
    if (highlight) setDay(highlight.slotKey.split("|")[1]);
  }, [highlight]);

  const specialties = useMemo(() => [...new Set(schedule?.doctors.map((d) => d.specialty) ?? [])].sort(), [schedule]);

  if (!schedule || !day) return <PageHeader title="Doctors" />;

  const doctors = schedule.doctors.filter((d) => specialty === "all" || d.specialty === specialty);
  const inToday = schedule.doctors.filter((d) => (d.slots[day] ?? []).length).length;

  return (
    <>
      <PageHeader title="Doctors" subtitle={`${relativeDay(day, schedule.today)} · ${inToday} of ${schedule.doctors.length} in clinic`} />
      <DayPicker schedule={schedule} value={day} onChange={setDay} />
      <div className="mb-5 mt-5 flex flex-wrap items-center justify-between gap-3">
        <Segmented value={specialty} onChange={setSpecialty} options={[{ value: "all", label: "All specialties" }, ...specialties.map((s) => ({ value: s, label: s }))]} />
        <div className="flex items-center gap-4 text-[11.5px] text-ink-3">
          <span className="flex items-center gap-1.5"><i className="h-2.5 w-4 rounded-[3px] border border-line bg-surface" /> Open</span>
          <span className="flex items-center gap-1.5"><i className="h-2.5 w-4 rounded-[3px] bg-ink" /> Booked</span>
          <span className="flex items-center gap-1.5"><i className="h-2.5 w-4 rounded-[3px] [background:repeating-linear-gradient(-45deg,transparent_0_3px,var(--color-line)_3px_4px)]" /> Passed</span>
        </div>
      </div>
      {doctors.length === 0 ? (
        <EmptyState icon={Stethoscope} title="No doctors" />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {doctors.map((d) => (
            <DoctorCard key={d.id} doctor={d} schedule={schedule} day={day} flashSlot={highlight?.slotKey ?? null} onOpen={() => setOpenId(d.id)} />
          ))}
        </div>
      )}
      <DoctorSheet
        doctor={schedule.doctors.find((d) => d.id === openId) ?? null}
        days={schedule.days}
        today={schedule.today}
        appointments={appointments}
        flashSlot={highlight?.slotKey ?? null}
        onClose={() => setOpenId(null)}
      />
    </>
  );
}
