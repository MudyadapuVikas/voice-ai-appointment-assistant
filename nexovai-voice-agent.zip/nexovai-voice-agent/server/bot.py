"""Voice agent for doctor appointments.

Pipeline: browser mic -> Silero VAD -> ElevenLabs STT -> Gemini (with tools)
          -> ElevenLabs TTS -> browser speaker

Run:  python bot.py -t webrtc     (serves on http://localhost:7860)
"""

import os

from dotenv import load_dotenv
from loguru import logger

from pipecat.audio.vad.silero import SileroVADAnalyzer
from pipecat.audio.vad.vad_analyzer import VADParams
from pipecat.frames.frames import LLMRunFrame
from pipecat.pipeline.pipeline import Pipeline
from pipecat.pipeline.worker import PipelineParams, PipelineWorker
from pipecat.processors.aggregators.llm_context import LLMContext
from pipecat.processors.frameworks.rtvi import RTVIObserverParams
from pipecat.processors.frameworks.rtvi.observer import RTVIFunctionCallReportLevel
from pipecat.processors.aggregators.llm_response_universal import (
    LLMContextAggregatorPair,
    LLMUserAggregatorParams,
)
from pipecat.runner.run import app
from pipecat.runner.types import RunnerArguments
from pipecat.runner.utils import create_transport
from pipecat.services.elevenlabs.stt import ElevenLabsRealtimeSTTService
from pipecat.services.elevenlabs.tts import ElevenLabsTTSService
from pipecat.services.google.llm import GoogleLLMService
from pipecat.transports.base_transport import BaseTransport, TransportParams
from pipecat.workers.runner import WorkerRunner

import db
from tools import TOOLS

load_dotenv(override=True)
db.init_db()

CLINIC = "Halcyon Clinic"


def system_prompt() -> str:
    today = db.now()
    with db.connect() as conn:
        roster = "\n".join(
            f'- {d["id"]}: {d["name"]}, {d["specialty"]}' for d in db.list_doctors(conn)
        )
    return f"""You are Mira, the front desk voice assistant at {CLINIC}. You are on a phone call.
Today is {today:%A, %d %B %Y} and the time is {today:%H:%M}. Use this to turn "tomorrow" or "Friday" into a YYYY-MM-DD date.

Doctors:
{roster}

You can check availability, book an appointment, and cancel an appointment.

How to work:
- Callers are identified only by the phone number they say. Before booking or cancelling, ask for it,
  then read it back digit by digit in groups, like "nine eight four eight zero, one two three four five. Is that right?"
  Only set phone_confirmed to true after they say yes. If they correct you, read it back again.
- For a booking you also need the patient's name.
- Always call check_doctor_availability before offering times. Offer two or three options, not the whole list.
- After booking or cancelling, confirm the doctor, day and time in one sentence.
- If a tool returns ok false, explain briefly and help the caller pick something else.

Style: this is speech. Short sentences, no lists, no symbols, no markdown. Say times like "two thirty in the afternoon"
and dates like "Thursday the twenty seventh". Be warm and quick, one question at a time."""


async def run_bot(transport: BaseTransport, runner_args: RunnerArguments):
    stt = ElevenLabsRealtimeSTTService(
        api_key=os.environ["ELEVENLABS_API_KEY"],
        # bias recognition towards words callers will say
        settings=ElevenLabsRealtimeSTTService.Settings(
            keyterms=["appointment", "cancel", "cardiology", "dermatology", "pediatrics", "orthopedics", "ENT"],
        ),
    )

    tts = ElevenLabsTTSService(
        api_key=os.environ["ELEVENLABS_API_KEY"],
        settings=ElevenLabsTTSService.Settings(
            voice=os.getenv("ELEVENLABS_VOICE_ID", "EXAVITQu4vr4xnSDxMaL"),
            model=os.getenv("ELEVENLABS_TTS_MODEL", "eleven_flash_v2_5"),
        ),
    )

    llm = GoogleLLMService(
        api_key=os.environ["GOOGLE_API_KEY"],
        settings=GoogleLLMService.Settings(
            model=os.getenv("GOOGLE_MODEL", "gemini-3.6-flash"),
            system_instruction=system_prompt(),
        ),
    )

    # Tools are plain async functions; Pipecat reads their signatures + docstrings
    # to build the function declarations and routes calls back to them.
    context = LLMContext(tools=TOOLS)
    user_aggregator, assistant_aggregator = LLMContextAggregatorPair(
        context,
        # Silero VAD decides when the caller starts/stops talking (turn taking + barge-in)
        user_params=LLMUserAggregatorParams(
            vad_analyzer=SileroVADAnalyzer(params=VADParams(stop_secs=0.6)),
        ),
    )

    pipeline = Pipeline(
        [
            transport.input(),
            stt,
            user_aggregator,
            llm,
            tts,
            transport.output(),
            assistant_aggregator,
        ]
    )

    # RTVI is enabled by default: it streams transcripts, speaking events and our
    # server messages to the browser client over the WebRTC data channel.
    worker = PipelineWorker(
        pipeline,
        params=PipelineParams(enable_metrics=True, enable_usage_metrics=True),
        idle_timeout_secs=runner_args.pipeline_idle_timeout_secs,
        # let the UI show "checking availability..." (tool names only, never the phone number)
        rtvi_observer_params=RTVIObserverParams(
            function_call_report_level={"*": RTVIFunctionCallReportLevel.NAME}
        ),
    )
    runner = WorkerRunner(handle_sigint=runner_args.handle_sigint)
    await runner.add_workers(worker)

    @transport.event_handler("on_client_connected")
    async def on_client_connected(transport, client):
        logger.info("Caller connected")
        context.add_message(
            {"role": "developer", "content": f"Greet the caller as Mira from {CLINIC} in one short sentence and ask how you can help."}
        )
        await worker.queue_frames([LLMRunFrame()])

    @transport.event_handler("on_client_disconnected")
    async def on_client_disconnected(transport, client):
        logger.info("Caller hung up")
        await runner.cancel()

    await runner.run()


async def bot(runner_args: RunnerArguments):
    transport = await create_transport(
        runner_args,
        {"webrtc": lambda: TransportParams(audio_in_enabled=True, audio_out_enabled=True)},
    )
    await run_bot(transport, runner_args)


# ---------------------------------------------------------------- dashboard API
# Added to the Pipecat dev runner's FastAPI app, next to its /api/offer route.


@app.get("/api/schedule")
def get_schedule():
    with db.connect() as conn:
        return db.schedule(conn)


@app.get("/api/appointments")
def get_appointments():
    with db.connect() as conn:
        return db.list_appointments(conn)


@app.post("/api/reset")
def reset_demo():
    db.init_db(reset=True)
    return {"ok": True}


if __name__ == "__main__":
    from pipecat.runner.run import main

    main()
