"""The three tools the LLM can call. Pipecat builds each tool's schema from the
function signature and docstring, so the docstrings below are what Gemini sees.

Every tool returns a dict. Errors are returned as {"ok": False, "error": ...}
instead of raising, so the agent can explain the problem to the caller.
"""

import re
import sqlite3
from datetime import date, datetime

from loguru import logger
from pipecat.processors.frameworks.rtvi import RTVIServerMessageFrame
from pipecat.services.llm_service import FunctionCallParams

import db

WORD_DIGITS = {
    "zero": "0", "oh": "0", "o": "0", "one": "1", "two": "2", "three": "3", "four": "4",
    "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9",
}


def normalize_phone(raw: str) -> str | None:
    """Turn what STT heard into a 10 digit number, or None.

    Handles "98480 12345", "+91 98480-12345", "nine eight four ...",
    and "double five" / "triple seven".
    """
    text = raw.lower().replace("-", " ")
    words = re.findall(r"[a-z]+|\d+", text)
    digits, repeat = "", 1
    for w in words:
        if w in ("double", "triple"):
            repeat = 2 if w == "double" else 3
            continue
        d = WORD_DIGITS.get(w, w if w.isdigit() else "")
        if d:
            digits += d * repeat if len(d) == 1 else d
        repeat = 1
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    return digits if len(digits) == 10 else None


def parse_date(value: str) -> date | None:
    try:
        return datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except ValueError:
        return None


def match_doctors(conn, doctor: str) -> list[sqlite3.Row]:
    """Match by id, name fragment or specialty (case-insensitive)."""
    doctors = db.list_doctors(conn)
    q = doctor.lower().replace("dr.", "").replace("doctor", "").strip()
    if not q:
        return doctors
    return [
        d for d in doctors
        if q == d["id"].lower() or q in d["name"].lower() or q in d["specialty"].lower()
    ]


async def notify(params: FunctionCallParams, event: str, appointment: dict):
    """Tell the dashboard something changed (sent as an RTVI server message)."""
    await params.llm.push_frame(RTVIServerMessageFrame(data={"type": event, "appointment": appointment}))


# ---------------------------------------------------------------- tools


async def check_doctor_availability(params: FunctionCallParams, doctor: str = "", date: str = ""):
    """Look up free appointment slots. Call this before offering any times to the caller.

    Args:
        doctor: Doctor name, part of a name, or a specialty such as "cardiology". Empty for all doctors.
        date: Day in YYYY-MM-DD format. Empty to search the next 7 days.
    """
    logger.info(f"check_doctor_availability doctor={doctor!r} date={date!r}")
    with db.connect() as conn:
        doctors = match_doctors(conn, doctor)
        if not doctors:
            names = ", ".join(f'{d["name"]} ({d["specialty"]})' for d in db.list_doctors(conn))
            await params.result_callback({"ok": False, "error": f"No doctor matches '{doctor}'. Doctors: {names}"})
            return

        if date:
            day = parse_date(date)
            if not day or day not in db.upcoming_days():
                await params.result_callback({"ok": False, "error": "Date must be within the next 7 days, as YYYY-MM-DD."})
                return
            days = [day]
        else:
            days = db.upcoming_days()

        results = []
        for d in doctors:
            open_days = []
            for day in days:
                free = db.free_slots(conn, d["id"], day)
                if free:
                    open_days.append({"date": day.isoformat(), "weekday": day.strftime("%A"), "free_slots": free})
                # keep the answer short for the LLM when searching the whole week
                if not date and len(open_days) == 3:
                    break
            results.append({"doctor_id": d["id"], "name": d["name"], "specialty": d["specialty"], "availability": open_days})

    await params.result_callback({"ok": True, "doctors": results})


async def book_appointment(
    params: FunctionCallParams,
    phone_number: str,
    phone_confirmed: bool,
    patient_name: str,
    doctor_id: str,
    date: str,
    time: str,
):
    """Book a slot for the caller. Only call after the caller picked a slot from check_doctor_availability.

    Args:
        phone_number: The caller's 10 digit phone number, exactly as they said it.
        phone_confirmed: True only if you read the number back digit by digit and the caller said it is correct.
        patient_name: The patient's name.
        doctor_id: The doctor_id returned by check_doctor_availability, e.g. "D2".
        date: Day in YYYY-MM-DD format.
        time: Slot start time in 24 hour HH:MM format, e.g. "14:30".
    """
    logger.info(f"book_appointment {doctor_id} {date} {time} phone={phone_number!r}")
    phone = normalize_phone(phone_number)
    if not phone:
        await params.result_callback({"ok": False, "error": "That is not a valid 10 digit phone number. Ask again."})
        return
    if not phone_confirmed:
        await params.result_callback({"ok": False, "error": f"Read the number {phone} back to the caller and get a yes first."})
        return

    day = parse_date(date)
    with db.connect() as conn:
        doctor = db.get_doctor(conn, doctor_id.upper().strip())
        if not doctor:
            await params.result_callback({"ok": False, "error": f"Unknown doctor_id '{doctor_id}'."})
            return
        if not day or time not in db.free_slots(conn, doctor["id"], day):
            free = db.free_slots(conn, doctor["id"], day) if day else []
            await params.result_callback({"ok": False, "error": "That slot is not available.", "free_slots_that_day": free})
            return
        try:
            cur = conn.execute(
                "INSERT INTO appointments (doctor_id, date, time, patient_name, phone, created_at) VALUES (?,?,?,?,?,?)",
                (doctor["id"], day.isoformat(), time, patient_name.strip() or "Caller", phone,
                 db.now().isoformat(timespec="seconds")),
            )
        except sqlite3.IntegrityError:
            # someone else took it between the check and the insert
            await params.result_callback({"ok": False, "error": "That slot was just taken. Offer another one."})
            return
        appointment = db.get_appointment(conn, cur.lastrowid)

    await notify(params, "appointment_booked", appointment)
    await params.result_callback({"ok": True, "appointment": appointment})


async def cancel_appointment(
    params: FunctionCallParams,
    phone_number: str,
    phone_confirmed: bool,
    appointment_id: int = 0,
):
    """Cancel the caller's upcoming appointment, found by their phone number.

    If the caller has more than one upcoming appointment, this returns the list
    without cancelling; ask which one, then call again with appointment_id.

    Args:
        phone_number: The caller's 10 digit phone number, exactly as they said it.
        phone_confirmed: True only if you read the number back digit by digit and the caller said it is correct.
        appointment_id: Which appointment to cancel, when the caller has several. 0 if not known yet.
    """
    logger.info(f"cancel_appointment phone={phone_number!r} id={appointment_id}")
    phone = normalize_phone(phone_number)
    if not phone:
        await params.result_callback({"ok": False, "error": "That is not a valid 10 digit phone number. Ask again."})
        return
    if not phone_confirmed:
        await params.result_callback({"ok": False, "error": f"Read the number {phone} back to the caller and get a yes first."})
        return

    with db.connect() as conn:
        today = db.now().date().isoformat()
        upcoming = [
            a for a in db.list_appointments(conn)
            if a["phone"] == phone and a["status"] == "booked" and a["date"] >= today
        ]
        if not upcoming:
            await params.result_callback({"ok": False, "error": f"No upcoming appointment found for {phone}."})
            return

        if appointment_id:
            target = next((a for a in upcoming if a["id"] == appointment_id), None)
            if not target:
                await params.result_callback({"ok": False, "error": "That appointment id does not belong to this number.", "appointments": upcoming})
                return
        elif len(upcoming) == 1:
            target = upcoming[0]
        else:
            await params.result_callback({"ok": False, "needs_choice": True, "appointments": upcoming})
            return

        conn.execute(
            "UPDATE appointments SET status='cancelled', cancelled_at=? WHERE id=?",
            (db.now().isoformat(timespec="seconds"), target["id"]),
        )
        appointment = db.get_appointment(conn, target["id"])

    await notify(params, "appointment_cancelled", appointment)
    await params.result_callback({"ok": True, "cancelled": appointment})


TOOLS = [check_doctor_availability, book_appointment, cancel_appointment]
