"""SQLite storage for doctors and appointments.

Slots are not stored as rows. Each doctor has working hours and working days;
a slot is free if it falls inside those hours and no booked appointment uses it.
"""

import os
import sqlite3
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(__file__), "clinic.db"))
TZ = ZoneInfo(os.getenv("CLINIC_TZ", "Asia/Kolkata"))
DAYS_AHEAD = 7

# weekday numbers: Mon=0 ... Sun=6
DOCTORS = [
    # id, name, specialty, room, start, end, slot minutes, working days
    ("D1", "Dr. Ananya Rao", "General Physician", "101", "09:00", "13:00", 30, "0123456"),
    ("D2", "Dr. Vikram Mehta", "Cardiology", "204", "10:00", "14:00", 30, "01234"),
    ("D3", "Dr. Sara Thomas", "Dermatology", "112", "14:00", "18:00", 30, "01235"),
    ("D4", "Dr. Arjun Iyer", "Pediatrics", "108", "09:30", "12:30", 30, "012345"),
    ("D5", "Dr. Meera Kapoor", "Orthopedics", "210", "15:00", "19:00", 30, "1345"),
    ("D6", "Dr. Rahul Sen", "ENT", "115", "11:00", "15:00", 30, "02456"),
]


def now() -> datetime:
    return datetime.now(TZ)


def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(reset: bool = False):
    with connect() as conn:
        if reset:
            conn.executescript("DROP TABLE IF EXISTS appointments; DROP TABLE IF EXISTS doctors;")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS doctors (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                specialty TEXT NOT NULL,
                room TEXT NOT NULL,
                start TEXT NOT NULL,
                end TEXT NOT NULL,
                slot_minutes INTEGER NOT NULL,
                days TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                doctor_id TEXT NOT NULL REFERENCES doctors(id),
                date TEXT NOT NULL,
                time TEXT NOT NULL,
                patient_name TEXT NOT NULL,
                phone TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'booked',
                created_at TEXT NOT NULL,
                cancelled_at TEXT
            );
            -- one booked appointment per doctor per slot
            CREATE UNIQUE INDEX IF NOT EXISTS one_booking_per_slot
                ON appointments(doctor_id, date, time) WHERE status = 'booked';
            CREATE INDEX IF NOT EXISTS by_phone ON appointments(phone);
            """
        )
        if conn.execute("SELECT COUNT(*) FROM doctors").fetchone()[0] == 0:
            conn.executemany("INSERT INTO doctors VALUES (?,?,?,?,?,?,?,?)", DOCTORS)
            _seed_appointments(conn)


def _seed_appointments(conn: sqlite3.Connection):
    """A few existing bookings so the board doesn't start empty."""
    seeds = [
        ("D1", 0, "Kiran Patel", "9876501234"),
        ("D2", 1, "Fatima Sheikh", "9123456780"),
        ("D3", 1, "Rohan Das", "9988776655"),
        ("D4", 2, "Neha Gupta", "9012345678"),
        ("D1", 3, "Aditya Nair", "9090909090"),
    ]
    stamp = now().isoformat(timespec="seconds")
    for doctor_id, slot_index, name, phone in seeds:
        for day in upcoming_days():
            free = free_slots(conn, doctor_id, day)
            if len(free) > slot_index + 2:
                conn.execute(
                    "INSERT INTO appointments (doctor_id, date, time, patient_name, phone, created_at)"
                    " VALUES (?,?,?,?,?,?)",
                    (doctor_id, day.isoformat(), free[slot_index + 2], name, phone, stamp),
                )
                break


# ---------- slots ----------


def upcoming_days(n: int = DAYS_AHEAD) -> list[date]:
    today = now().date()
    return [today + timedelta(days=i) for i in range(n)]


def all_slots(doctor: sqlite3.Row, day: date) -> list[str]:
    if str(day.weekday()) not in doctor["days"]:
        return []
    start = datetime.combine(day, datetime.strptime(doctor["start"], "%H:%M").time())
    end = datetime.combine(day, datetime.strptime(doctor["end"], "%H:%M").time())
    slots = []
    while start < end:
        slots.append(start.strftime("%H:%M"))
        start += timedelta(minutes=doctor["slot_minutes"])
    return slots


def booked_times(conn, doctor_id: str, day: date) -> set[str]:
    rows = conn.execute(
        "SELECT time FROM appointments WHERE doctor_id=? AND date=? AND status='booked'",
        (doctor_id, day.isoformat()),
    )
    return {r["time"] for r in rows}


def is_past(day: date, hhmm: str) -> bool:
    slot = datetime.combine(day, datetime.strptime(hhmm, "%H:%M").time(), tzinfo=TZ)
    return slot <= now()


def free_slots(conn, doctor_id: str, day: date) -> list[str]:
    doctor = get_doctor(conn, doctor_id)
    taken = booked_times(conn, doctor_id, day)
    return [t for t in all_slots(doctor, day) if t not in taken and not is_past(day, t)]


# ---------- queries ----------


def get_doctor(conn, doctor_id: str):
    return conn.execute("SELECT * FROM doctors WHERE id=?", (doctor_id,)).fetchone()


def list_doctors(conn) -> list[sqlite3.Row]:
    return conn.execute("SELECT * FROM doctors ORDER BY id").fetchall()


def appointment_dict(row: sqlite3.Row) -> dict:
    return {k: row[k] for k in row.keys()}


def list_appointments(conn) -> list[dict]:
    rows = conn.execute(
        """
        SELECT a.*, d.name AS doctor_name, d.specialty
        FROM appointments a JOIN doctors d ON d.id = a.doctor_id
        ORDER BY a.date, a.time
        """
    ).fetchall()
    return [appointment_dict(r) for r in rows]


def get_appointment(conn, appointment_id: int) -> dict | None:
    row = conn.execute(
        """
        SELECT a.*, d.name AS doctor_name, d.specialty
        FROM appointments a JOIN doctors d ON d.id = a.doctor_id WHERE a.id=?
        """,
        (appointment_id,),
    ).fetchone()
    return appointment_dict(row) if row else None


def schedule(conn) -> dict:
    """Everything the dashboard board needs: doctors x days x slots with state."""
    days = upcoming_days()
    doctors = []
    for d in list_doctors(conn):
        per_day = {}
        for day in days:
            taken = booked_times(conn, d["id"], day)
            per_day[day.isoformat()] = [
                {
                    "time": t,
                    "state": "booked" if t in taken else ("past" if is_past(day, t) else "free"),
                }
                for t in all_slots(d, day)
            ]
        doctors.append(
            {
                "id": d["id"],
                "name": d["name"],
                "specialty": d["specialty"],
                "room": d["room"],
                "hours": f'{d["start"]}–{d["end"]}',
                "slots": per_day,
            }
        )
    return {"days": [d.isoformat() for d in days], "today": now().date().isoformat(), "doctors": doctors}
