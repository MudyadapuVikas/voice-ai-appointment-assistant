# Halcyon — voice front desk

A caller phones the clinic from the browser, talks to **Mira**, a voice agent, and checks a doctor's availability, books, or cancels. The agent knows the caller only by the phone number they say during the call. The dashboard shows the schedule and appointments and updates while the call is going on.

**LLM:** Google Gemini (`gemini-3.6-flash` by default, set with `GOOGLE_MODEL`), free tier from Google AI Studio.
**STT / TTS:** ElevenLabs Scribe Realtime / ElevenLabs Flash v2.5.
**Framework:** Pipecat 1.17 (Python), SmallWebRTC transport, Silero VAD.
**Frontend:** React + Vite + TypeScript. No UI kit.

```
browser mic ──WebRTC──▶ Silero VAD ─▶ ElevenLabs STT ─▶ Gemini ─▶ ElevenLabs TTS ──WebRTC──▶ speaker
                                                          │  ▲
                                         function call    ▼  │ result
                                         check_doctor_availability / book_appointment / cancel_appointment
                                                          │
                                                       SQLite ──RTVI server message──▶ dashboard refreshes
```

## Run it

You need Python 3.11+, Node 20+, an [ElevenLabs API key](https://elevenlabs.io/app/settings/api-keys) and a [Gemini API key](https://aistudio.google.com/apikey).

**1. Server** (terminal 1)

```bash
cd server
python -m venv .venv
# Windows: .venv\Scripts\activate     macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # Windows: copy .env.example .env  — then fill in the two keys
python bot.py -t webrtc     # http://localhost:7860
```

The first start downloads the Silero VAD model and creates `clinic.db` with six doctors and a few sample bookings.

**2. Dashboard** (terminal 2)

```bash
cd client
npm install
npm run dev                 # http://localhost:5173
```

Open http://localhost:5173 in Chrome, click **Try a call** and allow the microphone. Use headphones so the agent doesn't hear itself.

**Reset** in the header restores the demo data.

## Things to say

- "I'd like to see a cardiologist on Friday."
- "Do you have anything with Dr. Rao tomorrow morning?"
- "My number is 98480 12345."
- "I need to cancel my appointment."

## How it works

| File | What it does |
| --- | --- |
| `server/bot.py` | Builds the Pipecat pipeline, the system prompt, and adds `/api/schedule`, `/api/appointments` and `/api/reset` to the Pipecat runner's FastAPI app. The runner already serves `/api/offer` for the WebRTC handshake. |
| `server/tools.py` | The three tools. Pipecat reads each function's signature and docstring to build the tool schema Gemini sees. |
| `server/db.py` | SQLite. Slots aren't stored: a slot is free if it's within the doctor's hours, not in the past, and not booked. A partial unique index stops double booking. |
| `client/src/lib/useCall.ts` | Pipecat JS client: connect/disconnect, live transcript, which tool is running, audio analysers for the waveform. |
| `client/src/components/*` | Schedule board, appointments list, phone call screen, waveform. |

**Phone number handling.** The caller is identified only by the number they say. `normalize_phone` accepts digits or spoken words ("nine eight…", "double five", "+91"). Both `book_appointment` and `cancel_appointment` require `phone_confirmed=true`, and the prompt only allows that after the agent has read the number back and the caller has said yes. If the model skips the read-back, the tool refuses and tells it to confirm.

**Live updates.** After a booking or cancellation the tool pushes an `RTVIServerMessageFrame`. The browser receives it over the WebRTC data channel, refetches, opens the day, highlights the slot and row, and shows a confirmation card on the phone.

**Cancel with more than one booking.** If the number has several upcoming appointments, `cancel_appointment` returns the list without cancelling anything, the agent asks which one, then calls again with `appointment_id`.

## Bonus items

- Silero VAD for turn-taking and barge-in
- Phone-style call screen: ringing → connected → ended, with timer, mute, end call and the transcript inside the phone
- Agent's words light up as they're spoken (TTS word timestamps)
- Waveform drawn from the real audio tracks (Web Audio analysers)
- "Checking the schedule…" indicator while a tool runs (tool names only; arguments aren't sent to the browser)
- Confirmation card inside the phone, highlighted slot and row on the dashboard
- Ring, connect, hang-up and chime sounds made with Web Audio (no audio files)
- Responsive layout; on a phone the call screen goes full screen

## Notes

- Mock data only. The doctors, hours and seeded bookings are in `server/db.py`.
- Times use `CLINIC_TZ` (default `Asia/Kolkata`).
- If a key is wrong or a quota runs out, the error appears in small text inside the phone.
