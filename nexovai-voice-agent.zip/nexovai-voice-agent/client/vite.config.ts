import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The Pipecat server (python bot.py -t webrtc) runs on :7860.
// Proxying /api keeps the browser on one origin: no CORS, same code in dev and preview.
export default defineConfig({
  plugins: [react()],
  server: { proxy: { "/api": "http://localhost:7860" } },
  preview: { proxy: { "/api": "http://localhost:7860" } },
});
