import { useCallback, useEffect, useRef, useState } from "react";
import { api, type Appointment, type Schedule } from "./lib/api";
import { useCall, type ServerEvent } from "./lib/useCall";
import { playChime } from "./lib/sounds";
import { Header } from "./components/Header";
import { Board } from "./components/Board";
import { Ledger } from "./components/Ledger";
import { Phone } from "./components/Phone";

export type Flash = { id: number; kind: "booked" | "cancelled"; slot: string };

export default function App() {
  const [schedule, setSchedule] = useState<Schedule | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [offline, setOffline] = useState(false);
  const [day, setDay] = useState<string | null>(null);
  const [flash, setFlash] = useState<Flash | null>(null);
  const [lastEvent, setLastEvent] = useState<ServerEvent | null>(null);
  const flashTimer = useRef<number>(0);

  const refresh = useCallback(async () => {
    try {
      const [s, a] = await Promise.all([api.schedule(), api.appointments()]);
      setSchedule(s);
      setAppointments(a);
      setDay((d) => d ?? s.today);
      setOffline(false);
    } catch {
      setOffline(true);
    }
  }, []);

  useEffect(() => {
    void refresh();
    const id = window.setInterval(refresh, 30_000); // keeps "past" slots honest
    return () => window.clearInterval(id);
  }, [refresh]);

  // The agent pushes an RTVI server message after every booking / cancellation.
  const onServerEvent = useCallback(
    (e: ServerEvent) => {
      if (e.type !== "appointment_booked" && e.type !== "appointment_cancelled") return;
      const a = e.appointment;
      playChime();
      setLastEvent(e);
      setDay(a.date);
      setFlash({ id: a.id, kind: e.type === "appointment_booked" ? "booked" : "cancelled", slot: `${a.doctor_id}|${a.date}|${a.time}` });
      window.clearTimeout(flashTimer.current);
      flashTimer.current = window.setTimeout(() => setFlash(null), 4500);
      void refresh();
    },
    [refresh],
  );

  const call = useCall(onServerEvent);

  useEffect(() => {
    if (call.phase === "ringing") setLastEvent(null);
    if (call.phase === "ended") void refresh();
  }, [call.phase, refresh]);

  const reset = async () => {
    await api.reset();
    await refresh();
  };

  return (
    <div className={`app ${call.phase !== "idle" ? "app--oncall" : ""}`}>
      <Header phase={call.phase} startedAt={call.startedAt} offline={offline} onReset={reset} />
      <main className="layout">
        <Board schedule={schedule} day={day} onDay={setDay} flash={flash} />
        <Ledger appointments={appointments} today={schedule?.today ?? ""} flash={flash} />
      </main>

      {call.phase === "idle" && (
        <button className="dial" onClick={call.start}>
          <span className="dial__dot" />
          Try a call
        </button>
      )}
      <Phone call={call} lastEvent={lastEvent} />
    </div>
  );
}
