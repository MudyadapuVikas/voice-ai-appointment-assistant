const parse = (iso: string) => new Date(`${iso}T00:00:00`);

export const weekday = (iso: string) => parse(iso).toLocaleDateString("en-IN", { weekday: "short" });
export const dayNum = (iso: string) => parse(iso).getDate();
export const month = (iso: string) => parse(iso).toLocaleDateString("en-IN", { month: "short" });
export const longDate = (iso: string) =>
  parse(iso).toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" });

export function relativeDay(iso: string, today: string) {
  const diff = Math.round((parse(iso).getTime() - parse(today).getTime()) / 86_400_000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Tomorrow";
  if (diff === -1) return "Yesterday";
  return `${weekday(iso)} ${dayNum(iso)} ${month(iso)}`;
}

/** 14:30 -> 2:30 pm */
export function clock(hhmm: string) {
  const [h, m] = hhmm.split(":").map(Number);
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, "0")}`;
}
export const meridiem = (hhmm: string) => (Number(hhmm.slice(0, 2)) < 12 ? "am" : "pm");

/** 9848012345 -> 98480 •••45  (enough to recognise, not enough to leak) */
export const maskPhone = (p: string) => `${p.slice(0, 5)} •••${p.slice(-2)}`;

export const initials = (name: string) =>
  name
    .replace(/^Dr\.\s*/, "")
    .split(/\s+/)
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

export const timer = (secs: number) =>
  `${String(Math.floor(secs / 60)).padStart(2, "0")}:${String(secs % 60).padStart(2, "0")}`;
