import { useCallback, useEffect, useRef, useState } from "react";
import { PipecatClient, type BotOutputData, type Participant, type UserInputData } from "@pipecat-ai/client-js";
import { SmallWebRTCTransport } from "@pipecat-ai/small-webrtc-transport";
import { playConnected, playHangup, startRinging } from "./sounds";

export type Phase = "idle" | "ringing" | "live" | "ended" | "error";

export type Seg = { id: string; text: string; spoken: number };
export type Line =
  | { kind: "user"; id: string; text: string; interim: string; open: boolean }
  | { kind: "bot"; id: string; segs: Seg[]; open: boolean; cut?: boolean };

export type ServerEvent = { type: "appointment_booked" | "appointment_cancelled"; appointment: import("./api").Appointment };

let uid = 0;
const nextId = () => `l${++uid}`;

function closeLast(lines: Line[]): Line[] {
  const last = lines.at(-1);
  if (!last || !last.open) return lines;
  return [...lines.slice(0, -1), { ...last, open: false }];
}

/** Owns the Pipecat client: connect/disconnect, transcript, tool activity, audio analysers. */
export function useCall(onServerEvent: (e: ServerEvent) => void) {
  const [phase, setPhase] = useState<Phase>("idle");
  const [error, setError] = useState<string | null>(null);
  const [lines, setLines] = useState<Line[]>([]);
  const [tool, setTool] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const [speaking, setSpeaking] = useState<"user" | "bot" | null>(null);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [endedAt, setEndedAt] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const client = useRef<PipecatClient | null>(null);
  const audioEl = useRef<HTMLAudioElement | null>(null);
  const audioCtx = useRef<AudioContext | null>(null);
  const analysers = useRef<{ mic?: AnalyserNode; bot?: AnalyserNode }>({});
  const stopRing = useRef<(() => void) | null>(null);
  const phaseRef = useRef<Phase>("idle");
  const eventRef = useRef(onServerEvent);
  eventRef.current = onServerEvent;

  const go = (p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  };

  const attachAnalyser = (track: MediaStreamTrack, who: "mic" | "bot") => {
    const ctx = (audioCtx.current ??= new AudioContext());
    void ctx.resume();
    const node = ctx.createAnalyser();
    node.fftSize = 256;
    node.smoothingTimeConstant = 0.75;
    ctx.createMediaStreamSource(new MediaStream([track])).connect(node);
    analysers.current[who] = node;
  };

  const onUserInput = (d: UserInputData) => {
    if (!d.text?.trim()) return;
    setLines((prev) => {
      const last = prev.at(-1);
      if (last?.kind === "user" && last.open) {
        const next = d.final
          ? { ...last, text: `${last.text} ${d.text}`.trim(), interim: "" }
          : { ...last, interim: d.text };
        return [...prev.slice(0, -1), next];
      }
      const line: Line = { kind: "user", id: nextId(), text: d.final ? d.text : "", interim: d.final ? "" : d.text, open: true };
      return [...closeLast(prev), line];
    });
  };

  const onBotOutput = (d: BotOutputData) => {
    const type = d.output_type ?? "sentence";
    if (type !== "sentence" && type !== "token" && type !== "word") return; // skip sounds/pauses
    const p = d.spoken_progress;
    const full = p ? p.accumulated_text + p.remaining_text : d.text;
    if (!full.trim()) return;
    const spoken = d.will_be_spoken === false ? full.length : p ? p.accumulated_text.length : d.spoken_status === "completed" ? full.length : 0;
    const segId = String(d.segment_id ?? nextId());

    setLines((prev) => {
      // update an existing segment (word-by-word progress)
      for (let i = prev.length - 1; i >= Math.max(0, prev.length - 3); i--) {
        const l = prev[i];
        if (l.kind === "bot" && l.segs.some((s) => s.id === segId)) {
          const segs = l.segs.map((s) => (s.id === segId ? { ...s, text: full, spoken: Math.max(s.spoken, spoken) } : s));
          return prev.map((x, j) => (j === i ? { ...l, segs } : x));
        }
      }
      const last = prev.at(-1);
      const seg = { id: segId, text: full, spoken };
      if (last?.kind === "bot" && last.open) return [...prev.slice(0, -1), { ...last, segs: [...last.segs, seg] }];
      return [...closeLast(prev), { kind: "bot", id: nextId(), segs: [seg], open: true }];
    });
  };

  const onInterrupted = () =>
    setLines((prev) => {
      const last = prev.at(-1);
      if (last?.kind !== "bot") return prev;
      const segs = last.segs
        .map((s) => ({ ...s, text: s.text.slice(0, s.spoken).trimEnd(), spoken: s.spoken }))
        .filter((s) => s.text);
      return [...prev.slice(0, -1), { ...last, segs, open: false, cut: true }];
    });

  const cleanup = () => {
    stopRing.current?.();
    stopRing.current = null;
    analysers.current = {};
    void audioCtx.current?.close();
    audioCtx.current = null;
    if (audioEl.current) audioEl.current.srcObject = null;
    client.current = null;
    setTool(null);
    setSpeaking(null);
  };

  const finish = useCallback(() => {
    if (phaseRef.current === "ringing" || phaseRef.current === "live") {
      playHangup();
      setEndedAt(Date.now());
      go("ended");
    }
    cleanup();
  }, []);

  const start = useCallback(async () => {
    if (phaseRef.current === "ringing" || phaseRef.current === "live") return;
    setLines([]);
    setError(null);
    setNotice(null);
    setMuted(false);
    setStartedAt(null);
    setEndedAt(null);
    go("ringing");
    stopRing.current = startRinging();

    audioEl.current ??= Object.assign(new Audio(), { autoplay: true });

    const pc = new PipecatClient({
      transport: new SmallWebRTCTransport(),
      enableMic: true,
      enableCam: false,
      callbacks: {
        onTrackStarted: (track: MediaStreamTrack, participant?: Participant) => {
          if (track.kind !== "audio") return;
          if (participant?.local) {
            attachAnalyser(track, "mic");
          } else {
            audioEl.current!.srcObject = new MediaStream([track]);
            void audioEl.current!.play().catch(() => {});
            attachAnalyser(track, "bot");
          }
        },
        onBotReady: () => {
          stopRing.current?.();
          stopRing.current = null;
          playConnected();
          setStartedAt(Date.now());
          go("live");
        },
        onUserInput,
        onBotOutput,
        onBotInterrupted: onInterrupted,
        onUserStartedSpeaking: () => setSpeaking("user"),
        onUserStoppedSpeaking: () => setSpeaking((s) => (s === "user" ? null : s)),
        onBotStartedSpeaking: () => setSpeaking("bot"),
        onBotStoppedSpeaking: () => setSpeaking((s) => (s === "bot" ? null : s)),
        onLLMFunctionCallStarted: (d) => setTool(d.function_name ?? "working"),
        onLLMFunctionCallInProgress: (d) => setTool(d.function_name ?? "working"),
        onLLMFunctionCallStopped: () => window.setTimeout(() => setTool(null), 500),
        onServerMessage: (data: ServerEvent) => eventRef.current(data),
        onDisconnected: () => finish(),
        // surface service errors (bad API key, quota) inside the phone instead of failing silently
        onError: (m) => {
          const msg = (m.data as { error?: string })?.error;
          if (msg) setNotice(msg.length > 140 ? `${msg.slice(0, 140)}…` : msg);
        },
      },
    });
    client.current = pc;

    try {
      await pc.connect({ webrtcRequestParams: { endpoint: "/api/offer" } });
    } catch (e) {
      cleanup();
      const denied = e instanceof DOMException && e.name === "NotAllowedError";
      setError(denied ? "Microphone access is blocked." : "Can't reach the agent. Is the server running?");
      go("error");
    }
  }, [finish]);

  const end = useCallback(async () => {
    const pc = client.current;
    finish();
    await pc?.disconnect().catch(() => {});
  }, [finish]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      client.current?.enableMic(m);
      return !m;
    });
  }, []);

  const close = useCallback(() => go("idle"), []);

  useEffect(() => () => void client.current?.disconnect(), []);

  return { phase, error, notice, lines, tool, muted, speaking, startedAt, endedAt, analysers, start, end, close, toggleMute };
}

export type Call = ReturnType<typeof useCall>;
