export type SlotState = "free" | "booked" | "past";

export type Doctor = {
  id: string;
  name: string;
  specialty: string;
  room: string;
  hours: string;
  slots: Record<string, { time: string; state: SlotState }[]>;
};

export type Schedule = { days: string[]; today: string; doctors: Doctor[] };

export type Appointment = {
  id: number;
  doctor_id: string;
  doctor_name: string;
  specialty: string;
  date: string;
  time: string;
  patient_name: string;
  phone: string;
  status: "booked" | "cancelled";
  created_at: string;
  cancelled_at: string | null;
};

async function get<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`${path} → ${res.status}`);
  return res.json();
}

export const api = {
  schedule: () => get<Schedule>("/api/schedule"),
  appointments: () => get<Appointment[]>("/api/appointments"),
  reset: () => fetch("/api/reset", { method: "POST" }),
};
