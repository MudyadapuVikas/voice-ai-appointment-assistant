import { useMemo, useState } from "react";
import type { Appointment } from "../lib/api";
import type { Flash } from "../App";
import { clock, maskPhone, meridiem, relativeDay } from "../lib/format";

type Props = { appointments: Appointment[]; today: string; flash: Flash | null };
type Tab = "upcoming" | "cancelled" | "all";

export function Ledger({ appointments, today, flash }: Props) {
  const [tab, setTab] = useState<Tab>("upcoming");

  const counts = {
    upcoming: appointments.filter((a) => a.status === "booked" && a.date >= today).length,
    cancelled: appointments.filter((a) => a.status === "cancelled").length,
    all: appointments.length,
  };

  const groups = useMemo(() => {
    const list = appointments.filter((a) =>
      tab === "upcoming" ? a.status === "booked" && a.date >= today : tab === "cancelled" ? a.status === "cancelled" : true,
    );
    const map = new Map<string, Appointment[]>();
    for (const a of list) map.set(a.date, [...(map.get(a.date) ?? []), a]);
    return [...map.entries()];
  }, [appointments, tab, today]);

  return (
    <section className="ledger">
      <div className="section-head">
        <h2>Appointments</h2>
        <div className="tabs" role="tablist">
          {(["upcoming", "cancelled", "all"] as Tab[]).map((t) => (
            <button key={t} role="tab" aria-selected={tab === t} className={tab === t ? "on" : ""} onClick={() => setTab(t)}>
              {t[0].toUpperCase() + t.slice(1)} <span>{counts[t]}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="ledger__list">
        {groups.length === 0 && <p className="empty">Nothing here yet. Bookings made on a call show up instantly.</p>}
        {groups.map(([date, items]) => (
          <div key={date} className="group">
            <h3>{relativeDay(date, today)}</h3>
            {items.map((a) => (
              <article
                key={a.id}
                className={`appt appt--${a.status} ${flash?.id === a.id ? `appt--flash-${flash.kind}` : ""}`}
              >
                <div className="appt__time">
                  {clock(a.time)}
                  <small>{meridiem(a.time)}</small>
                </div>
                <div className="appt__body">
                  <div className="appt__who">{a.patient_name}</div>
                  <div className="appt__with">
                    {a.doctor_name.replace(/^Dr\.\s*\S+\s/, "Dr. ")} · {a.specialty}
                  </div>
                </div>
                <div className="appt__side">
                  <span className="appt__phone">{maskPhone(a.phone)}</span>
                  <span className="appt__ref">{a.status === "cancelled" ? "Cancelled" : `#${String(a.id).padStart(4, "0")}`}</span>
                </div>
              </article>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}
