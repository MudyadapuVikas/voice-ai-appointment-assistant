import { useEffect, useState } from "react";
import type { Schedule } from "../lib/api";
import type { Flash } from "../App";
import { clock, dayNum, initials, meridiem, relativeDay, weekday } from "../lib/format";

type Props = { schedule: Schedule | null; day: string | null; onDay: (d: string) => void; flash: Flash | null };

const STEP = 30;
const toMin = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));

export function Board({ schedule, day, onDay, flash }: Props) {
  const [nowMin, setNowMin] = useState(() => minutesNow());
  useEffect(() => {
    const id = window.setInterval(() => setNowMin(minutesNow()), 30_000);
    return () => window.clearInterval(id);
  }, []);

  if (!schedule || !day) return <section className="board board--empty">Loading schedule…</section>;

  // one shared axis for all doctors: earliest start to latest end
  const all = schedule.doctors.flatMap((d) => Object.values(d.slots).flat().map((s) => toMin(s.time)));
  const from = Math.floor(Math.min(...all) / 60) * 60;
  const to = Math.ceil((Math.max(...all) + STEP) / 60) * 60;
  const cols = (to - from) / STEP;
  const hours = Array.from({ length: (to - from) / 60 }, (_, i) => from + i * 60);

  const count = (d: string, state: string) =>
    schedule.doctors.reduce((n, doc) => n + (doc.slots[d] ?? []).filter((s) => s.state === state).length, 0);

  const isToday = day === schedule.today;
  const nowPos = isToday && nowMin >= from && nowMin <= to ? (nowMin - from) / (to - from) : null;

  return (
    <section className="board">
      <div className="section-head">
        <h2>Schedule</h2>
        <p className="figures">
          <span><b>{count(day, "free")}</b> open</span>
          <span><b>{count(day, "booked")}</b> booked</span>
          <span><b>{schedule.doctors.filter((d) => (d.slots[day] ?? []).length).length}</b> in clinic</span>
        </p>
      </div>

      <nav className="days" aria-label="Day">
        {schedule.days.map((d) => (
          <button key={d} className={`day ${d === day ? "day--on" : ""}`} onClick={() => onDay(d)}>
            <span className="day__wd">{d === schedule.today ? "Today" : weekday(d)}</span>
            <span className="day__n">{dayNum(d)}</span>
            <span className="day__free">{count(d, "free")}</span>
          </button>
        ))}
      </nav>

      <div className="grid-scroll">
        <div className="grid" style={{ ["--cols" as string]: cols }}>
          <div className="grid__axis">
            <span />
            <div className="axis">
              {hours.map((h) => (
                <span key={h} style={{ left: `${((h - from) / (to - from)) * 100}%` }}>
                  {clock(`${String(h / 60).padStart(2, "0")}:00`)}
                  <small>{h < 720 ? "am" : "pm"}</small>
                </span>
              ))}
            </div>
          </div>

          {schedule.doctors.map((doc) => {
            const slots = doc.slots[day] ?? [];
            return (
              <div className={`row ${slots.length ? "" : "row--off"}`} key={doc.id}>
                <div className="doc">
                  <span className="doc__av">{initials(doc.name)}</span>
                  <div>
                    <div className="doc__name">{doc.name}</div>
                    <div className="doc__meta">
                      {doc.specialty} · Rm {doc.room}
                    </div>
                  </div>
                </div>
                <div className="track">
                  {hours.map((h) => (
                    <i key={h} className="track__tick" style={{ left: `${((h - from) / (to - from)) * 100}%` }} />
                  ))}
                  {nowPos !== null && <i className="track__now" style={{ left: `${nowPos * 100}%` }} />}
                  {slots.length === 0 && <span className="track__off">Not in today</span>}
                  {slots.map((s) => {
                    const key = `${doc.id}|${day}|${s.time}`;
                    const hit = flash?.slot === key ? `slot--flash-${flash.kind}` : "";
                    return (
                      <span
                        key={s.time}
                        className={`slot slot--${s.state} ${hit}`}
                        style={{ gridColumn: `${(toMin(s.time) - from) / STEP + 1} / span 1` }}
                        title={`${clock(s.time)} ${meridiem(s.time)} · ${s.state}`}
                      >
                        {clock(s.time)}
                      </span>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <footer className="legend">
        <span><i className="slot slot--free" /> Open</span>
        <span><i className="slot slot--booked" /> Booked</span>
        <span><i className="slot slot--past" /> Passed</span>
        <span className="legend__day">{relativeDay(day, schedule.today)}</span>
      </footer>
    </section>
  );
}

function minutesNow() {
  const n = new Date();
  return n.getHours() * 60 + n.getMinutes();
}
