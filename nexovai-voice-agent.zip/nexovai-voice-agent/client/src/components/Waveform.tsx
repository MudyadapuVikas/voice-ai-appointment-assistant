import { useEffect, useRef } from "react";
import type { Call } from "../lib/useCall";

const BARS = 44;

/** Mirrored bar waveform fed by Web Audio analysers on the mic and the agent's audio track. */
export function Waveform({ analysers, active }: { analysers: Call["analysers"]; active: boolean }) {
  const canvas = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = canvas.current!;
    const g = c.getContext("2d")!;
    const levels = new Float32Array(BARS);
    const buf = new Uint8Array(128);
    let raf = 0;

    const sample = (node: AnalyserNode | undefined, out: Float32Array) => {
      out.fill(0);
      if (!node) return 0;
      node.getByteFrequencyData(buf);
      let sum = 0;
      for (let i = 0; i < BARS; i++) {
        // voice lives in the lower bins; spread bars over bins 2..60
        const v = buf[2 + Math.floor((i / BARS) * 58)] / 255;
        out[i] = v;
        sum += v;
      }
      return sum / BARS;
    };

    const mic = new Float32Array(BARS);
    const bot = new Float32Array(BARS);

    const draw = (t: number) => {
      const dpr = window.devicePixelRatio || 1;
      const w = c.clientWidth;
      const h = c.clientHeight;
      if (c.width !== w * dpr) {
        c.width = w * dpr;
        c.height = h * dpr;
      }
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
      g.clearRect(0, 0, w, h);

      const m = sample(analysers.current.mic, mic);
      const b = sample(analysers.current.bot, bot);
      const botLeads = b >= m;

      const gap = w / BARS;
      const bw = Math.max(2, gap * 0.42);
      for (let i = 0; i < BARS; i++) {
        // fold the spectrum so energy sits in the middle, like a voice memo
        const k = i < BARS / 2 ? BARS / 2 - 1 - i : i - BARS / 2;
        const target = Math.max(mic[k * 2] ?? 0, bot[k * 2] ?? 0);
        const idle = active ? 0.04 + 0.025 * Math.sin(t / 380 + i * 0.5) : 0.03;
        levels[i] += (Math.max(target, idle) - levels[i]) * 0.35;
        const bh = Math.max(2, levels[i] * h * 0.92);
        g.fillStyle = botLeads ? "rgba(242,239,231,0.92)" : "#7FC4A0";
        g.beginPath();
        g.roundRect(i * gap + (gap - bw) / 2, (h - bh) / 2, bw, bh, bw / 2);
        g.fill();
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [analysers, active]);

  return <canvas ref={canvas} className="wave" aria-hidden />;
}
