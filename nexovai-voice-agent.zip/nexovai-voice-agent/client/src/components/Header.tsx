import { useEffect, useState } from "react";
import type { Phase } from "../lib/useCall";
import { timer } from "../lib/format";

type Props = { phase: Phase; startedAt: number | null; offline: boolean; onReset: () => void };

export function Header({ phase, startedAt, offline, onReset }: Props) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const live = phase === "live" || phase === "ringing";
  const secs = startedAt ? Math.max(0, Math.floor((now.getTime() - startedAt) / 1000)) : 0;

  return (
    <header className="top">
      <div className="brand">
        <span className="brand__mark">Halcyon</span>
        <span className="brand__sub">Front desk</span>
      </div>

      <div className="top__right">
        <span className={`line ${live ? "line--live" : ""} ${offline ? "line--down" : ""}`}>
          <i />
          {offline ? "Agent offline" : phase === "ringing" ? "Connecting" : phase === "live" ? `On call ${timer(secs)}` : "Line open"}
        </span>
        <span className="top__date">
          {now.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })}
          <b>{now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })}</b>
        </span>
        <button className="ghost" onClick={onReset} title="Restore the demo data">
          Reset
        </button>
      </div>
    </header>
  );
}
