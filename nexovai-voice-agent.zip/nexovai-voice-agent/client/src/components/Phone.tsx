import { useEffect, useRef, useState } from "react";
import type { Call, Line, ServerEvent } from "../lib/useCall";
import { clock, longDate, meridiem, timer } from "../lib/format";
import { Waveform } from "./Waveform";

const TOOL_LABEL: Record<string, string> = {
  check_doctor_availability: "Checking the schedule",
  book_appointment: "Booking the slot",
  cancel_appointment: "Cancelling",
};

type Props = { call: Call; lastEvent: ServerEvent | null };

export function Phone({ call, lastEvent }: Props) {
  const { phase } = call;
  const open = phase !== "idle";
  const [now, setNow] = useState(Date.now());
  const [card, setCard] = useState<ServerEvent | null>(null);
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 500);
    return () => window.clearInterval(id);
  }, []);

  // confirmation card slides in on booking/cancel, then tucks away
  useEffect(() => {
    setCard(lastEvent);
    if (!lastEvent) return;
    const id = window.setTimeout(() => setCard(null), 7000);
    return () => window.clearTimeout(id);
  }, [lastEvent]);

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [call.lines]);

  useEffect(() => {
    if (phase !== "ended") return;
    const id = window.setTimeout(call.close, 6000);
    return () => window.clearTimeout(id);
  }, [phase, call.close]);

  const secs = call.startedAt ? Math.floor(((call.endedAt ?? now) - call.startedAt) / 1000) : 0;

  return (
    <div className={`phone-layer ${open ? "phone-layer--open" : ""}`} aria-hidden={!open}>
      <div className={`phone phone--${phase}`} role="dialog" aria-label="Call">
        <div className="phone__bar">
          <span>{new Date(now).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })}</span>
          <span className="phone__island" />
          <span className="phone__sig">
            <i /><i /><i /><i />
            <em />
          </span>
        </div>

        <div className="callee">
          <div className={`callee__av ${phase === "ringing" ? "is-ringing" : ""} ${call.speaking === "bot" ? "is-talking" : ""}`}>
            <span>H</span>
          </div>
          <div className="callee__name">Halcyon Clinic</div>
          <div className="callee__state">
            {phase === "ringing" && "Calling…"}
            {phase === "live" && <span className="mono">{timer(secs)}</span>}
            {phase === "ended" && <>Call ended · <span className="mono">{timer(secs)}</span></>}
            {phase === "error" && "Call failed"}
          </div>
        </div>

        {(phase === "live" || phase === "ended") && (
          <>
            <Waveform analysers={call.analysers} active={phase === "live"} />
            <div className={`tool ${call.tool ? "tool--on" : ""}`}>
              <i />
              {TOOL_LABEL[call.tool ?? ""] ?? "Working"}
            </div>
            {call.notice && <p className="phone__note">{call.notice}</p>}
            <div className="chat" ref={scroller}>
              {call.lines.length === 0 && <p className="chat__hint">Say hello. Ask for a doctor, a day, or to cancel.</p>}
              {call.lines.map((l) => (
                <Bubble key={l.id} line={l} />
              ))}
              {call.speaking === "user" && call.lines.at(-1)?.kind !== "user" && (
                <div className="bubble bubble--user bubble--typing"><span /><span /><span /></div>
              )}
            </div>
          </>
        )}

        {phase === "error" && <p className="phone__err">{call.error}</p>}

        {card && (
          <div className={`ticket ticket--${card.type === "appointment_booked" ? "ok" : "cx"}`} onClick={() => setCard(null)}>
            <div className="ticket__head">
              <span>{card.type === "appointment_booked" ? "Confirmed" : "Cancelled"}</span>
              <span className="mono">#{String(card.appointment.id).padStart(4, "0")}</span>
            </div>
            <div className="ticket__doc">{card.appointment.doctor_name}</div>
            <div className="ticket__row">
              <span>{longDate(card.appointment.date)}</span>
              <b className="mono">
                {clock(card.appointment.time)} {meridiem(card.appointment.time)}
              </b>
            </div>
            <div className="ticket__who">{card.appointment.patient_name}</div>
          </div>
        )}

        <div className="controls">
          {phase === "live" && (
            <button className={`ctl ${call.muted ? "ctl--on" : ""}`} onClick={call.toggleMute} aria-pressed={call.muted}>
              <MicIcon off={call.muted} />
              <span>{call.muted ? "Unmute" : "Mute"}</span>
            </button>
          )}
          {(phase === "ringing" || phase === "live") && (
            <button className="ctl ctl--end" onClick={call.end}>
              <HangupIcon />
              <span>End</span>
            </button>
          )}
          {(phase === "ended" || phase === "error") && (
            <>
              <button className="ctl" onClick={call.close}>
                <CloseIcon />
                <span>Close</span>
              </button>
              <button className="ctl ctl--call" onClick={call.start}>
                <HangupIcon up />
                <span>Call again</span>
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Bubble({ line }: { line: Line }) {
  if (line.kind === "user") {
    return (
      <div className="bubble bubble--user">
        {line.text}
        {line.interim && <span className="interim"> {line.interim}</span>}
      </div>
    );
  }
  return (
    <div className={`bubble bubble--bot ${line.cut ? "bubble--cut" : ""}`}>
      {line.segs.map((s) => (
        <span key={s.id}>
          <span className="said">{s.text.slice(0, s.spoken)}</span>
          <span className="unsaid">{s.text.slice(s.spoken)}</span>{" "}
        </span>
      ))}
    </div>
  );
}

const MicIcon = ({ off }: { off: boolean }) => (
  <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
    <rect x="9" y="3" width="6" height="11" rx="3" />
    <path d="M5.5 11a6.5 6.5 0 0 0 13 0M12 17.5V21" />
    {off && <path d="M4 4l16 16" />}
  </svg>
);

const HangupIcon = ({ up }: { up?: boolean }) => (
  <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" style={{ transform: up ? "rotate(-135deg)" : undefined }}>
    <path d="M12 9c-2.6 0-5 .6-7.2 1.7-.6.3-1 .9-1 1.6v2.2c0 .8.7 1.4 1.5 1.3l3-.5c.6-.1 1.1-.6 1.1-1.3v-1.6c1.7-.5 3.5-.5 5.2 0V14c0 .7.5 1.2 1.1 1.3l3 .5c.8.1 1.5-.5 1.5-1.3v-2.2c0-.7-.4-1.3-1-1.6C17 9.6 14.6 9 12 9z" />
  </svg>
);

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
    <path d="M6 6l12 12M18 6L6 18" />
  </svg>
);
